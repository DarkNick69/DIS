#!/usr/bin/python3

import rclpy
from rclpy.node import Node
import cv2, math
import numpy as np
import tf2_ros

from sensor_msgs.msg import Image, CameraInfo
from geometry_msgs.msg import PointStamped, Vector3, Pose, PoseStamped
from cv_bridge import CvBridge, CvBridgeError
from visualization_msgs.msg import Marker, MarkerArray
from std_msgs.msg import ColorRGBA, String
from rclpy.qos import QoSDurabilityPolicy, QoSHistoryPolicy
from rclpy.qos import QoSProfile, QoSReliabilityPolicy
from rclpy.duration import Duration as rclpyDuration
from rclpy.time import Time as rclpyTime
import tf2_geometry_msgs

qos_profile = QoSProfile(
          durability=QoSDurabilityPolicy.TRANSIENT_LOCAL,
          reliability=QoSReliabilityPolicy.RELIABLE,
          history=QoSHistoryPolicy.KEEP_LAST,
          depth=1)

class RingDetector(Node):
    def __init__(self):
        super().__init__('transform_point')

        timer_frequency = 5
        timer_period = 1/timer_frequency

        self.ecc_thr = 100
        self.ratio_thr = 1.5
        self.center_thr = 10

        self.bridge = CvBridge()

        self.image_sub = self.create_subscription(Image, "/oakd/rgb/preview/image_raw", self.image_callback, 1)
        self.depth_sub = self.create_subscription(Image, "/oakd/rgb/preview/depth", self.depth_callback, 1)

        self.latest_rgb = None

        cv2.namedWindow("Depth Edges", cv2.WINDOW_NORMAL)
        cv2.namedWindow("Detected rings", cv2.WINDOW_NORMAL)
        cv2.namedWindow("Depth window", cv2.WINDOW_NORMAL)

        self.camera_info = None
        self.camera_info_sub = self.create_subscription(
            CameraInfo, "/oakd/rgb/preview/camera_info", self.camera_info_callback, 1)

        self.tf_buffer = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)

        # Ring candidate tracking & deduplication
        self.ring_candidates = {}
        self.frame_counter = 0
        self.candidate_id_counter = 0
        self.CONFIRM_FRAMES = 3        # min sightings before publish
        self.CANDIDATE_PIXEL_DIST = 25 # px match tolerance
        self.CANDIDATE_MAP_DIST = 0.4  # m, map-level merge tolerance
        self.CANDIDATE_MAX_AGE = 60    # frames before pruning
        self.published_ring_map_positions = []  # (x, y, z, color)
        self.PUBLISHED_MAP_DIST = 0.35  # m, published dedup radius
        # Detection runs while the robot drives too, so a ring is seen from many
        # distances. Far sightings have large depth-projection error and drift
        # the map position past PUBLISHED_MAP_DIST → the same ring publishes
        # twice. Only accept close, reliable sightings.
        self.MAX_RING_RANGE_M = 2.5  # m — reject detections farther than this

        self.ring_marker_pub = self.create_publisher(Marker, '/detected_ring_marker', 10)
        self.detection_pub   = self.create_publisher(String, '/ring_detections', 10)

    def camera_info_callback(self, msg):
        self.camera_info = msg

    def image_callback(self, data):
        try:
            self.latest_rgb = self.bridge.imgmsg_to_cv2(data, "bgr8")
        except CvBridgeError as e:
            print(e)

    def depth_callback(self, data):

        try:
            depth_image = self.bridge.imgmsg_to_cv2(data, "32FC1")
        except CvBridgeError as e:
            print(e)
            return

        depth_image[depth_image==np.inf] = 0
        depth_image[np.isnan(depth_image)] = 0

        # Normalize for visualization
        image_1 = depth_image / 65536.0 * 255
        max_val = np.max(image_1)
        if max_val > 0:
            image_1 = image_1 / max_val * 255

        image_viz = np.array(image_1, dtype=np.uint8)
        cv2.imshow("Depth window", image_viz)

        blurred = cv2.GaussianBlur(image_viz, (5, 5), 0)
        edges = cv2.Canny(blurred, 30, 100)
        cv2.imshow("Depth Edges", edges)

        # Method 1: Hough circles
        circles = cv2.HoughCircles(
            blurred,
            cv2.HOUGH_GRADIENT,
            dp=1.2,
            minDist=20,
            param1=80,
            param2=40,
            minRadius=5,
            maxRadius=80
        )

        hough_candidates = []
        if circles is not None:
            circles = np.uint16(np.around(circles))
            for c in circles[0, :]:
                hough_candidates.append((int(c[0]), int(c[1]), int(c[2])))

        # Method 2: concentric ellipses
        contours, _ = cv2.findContours(edges, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)

        elps = []
        for cnt in contours:
            if cnt.shape[0] >= 8:
                ellipse = cv2.fitEllipse(cnt)
                e = ellipse[1]
                ecc1 = e[0]
                ecc2 = e[1]
                if ecc1 < 1 or ecc2 < 1:
                    continue
                ratio = ecc1 / ecc2 if ecc1 > ecc2 else ecc2 / ecc1
                if ratio <= 2.0 and ecc1 < self.ecc_thr and ecc2 < self.ecc_thr:
                    elps.append(ellipse)

        ellipse_candidates = []
        for n in range(len(elps)):
            for m in range(n + 1, len(elps)):
                e1 = elps[n]
                e2 = elps[m]
                dist = np.sqrt((e1[0][0] - e2[0][0]) ** 2 + (e1[0][1] - e2[0][1]) ** 2)

                if dist >= 15:
                    continue

                e1_minor, e1_major = e1[1][0], e1[1][1]
                e2_minor, e2_major = e2[1][0], e2[1][1]

                if e1_major >= e2_major and e1_minor >= e2_minor:
                    pass
                elif e2_major >= e1_major and e2_minor >= e1_minor:
                    pass
                else:
                    continue

                ellipse_candidates.append((e1, e2))

        # Confirm: Hough center within 20px of ellipse pair center
        confirmed = []
        for (cx, cy, r) in hough_candidates:
            for (e1, e2) in ellipse_candidates:
                ex, ey = e1[0][0], e1[0][1]
                dist = np.sqrt((cx - ex) ** 2 + (cy - ey) ** 2)
                if dist < 20:
                    confirmed.append((cx, cy, r, e1, e2))
                    break

        print(f"Depth processing: {len(hough_candidates)} Hough, {len(ellipse_candidates)} ellipse pairs, {len(confirmed)} confirmed rings")

        if self.latest_rgb is not None:
            display_img = self.latest_rgb.copy()
        else:
            display_img = cv2.cvtColor(image_viz, cv2.COLOR_GRAY2BGR)

        for (cx, cy, r, e1, e2) in confirmed:
            cv2.circle(display_img, (cx, cy), r, (255, 255, 0), 2)
            cv2.circle(display_img, (cx, cy), 2, (0, 0, 255), 3)
            cv2.ellipse(display_img, e1, (0, 255, 0), 2)
            cv2.ellipse(display_img, e2, (0, 255, 0), 2)

        self.frame_counter += 1
        self._accumulate_rings(confirmed, depth_image, data.header.stamp)

        cv2.imshow("Detected rings", display_img)
        cv2.waitKey(1)

    def _project_to_map(self, cx, cy, depth_image, depth_stamp):
        """Project pixel to map frame. Returns (x,y,z) or None."""
        if self.camera_info is None:
            return None
        dh, dw = depth_image.shape[:2]
        if cx < 0 or cx >= dw or cy < 0 or cy >= dh:
            return None

        depth = float(depth_image[cy, cx])
        if depth <= 0 or not np.isfinite(depth):
            margin = 5
            y0, y1 = max(0, cy - margin), min(dh, cy + margin + 1)
            x0, x1 = max(0, cx - margin), min(dw, cx + margin + 1)
            region = depth_image[y0:y1, x0:x1]
            valid = region[(region > 0) & np.isfinite(region)]
            if len(valid) == 0:
                return None
            depth = float(np.median(valid))

        if depth > self.MAX_RING_RANGE_M:
            return None

        fx = self.camera_info.k[0]
        fy = self.camera_info.k[4]
        cx0 = self.camera_info.k[2]
        cy0 = self.camera_info.k[5]
        if fx == 0 or fy == 0:
            return None

        x3d = (cx - cx0) * depth / fx
        y3d = (cy - cy0) * depth / fy
        z3d = depth

        point = PointStamped()
        point.header.frame_id = self.camera_info.header.frame_id
        point.header.stamp = rclpyTime().to_msg()  # Time(0) = use latest available TF
        point.point.x = float(x3d)
        point.point.y = float(y3d)
        point.point.z = float(z3d)

        try:
            point_map = self.tf_buffer.transform(point, 'map', timeout=rclpyDuration(seconds=0.5))
            return (point_map.point.x, point_map.point.y, point_map.point.z)
        except Exception:
            return None

    def _find_candidate_by_map(self, map_pt):
        """Find nearest candidate by map position."""
        if map_pt is None:
            return None
        best_id = None
        best_dist = self.CANDIDATE_MAP_DIST
        for cid, cand in self.ring_candidates.items():
            if not cand['map_points']:
                continue
            avg_x = np.mean([p[0] for p in cand['map_points']])
            avg_y = np.mean([p[1] for p in cand['map_points']])
            d = math.hypot(map_pt[0] - avg_x, map_pt[1] - avg_y)
            if d < best_dist:
                best_dist = d
                best_id = cid
        return best_id

    def _is_near_published(self, mx, my):
        """True if (mx,my) is near any published ring."""
        for px, py, _, _ in self.published_ring_map_positions:
            if math.hypot(mx - px, my - py) < self.PUBLISHED_MAP_DIST:
                return True
        return False

    def _accumulate_rings(self, confirmed, depth_image, depth_stamp):
        """Match detections to candidates; create new ones if needed."""
        matched_ids = set()

        for (cx, cy, r, e1, e2) in confirmed:
            # Pixel-level match
            best_id = None
            best_dist = self.CANDIDATE_PIXEL_DIST
            for cid, cand in self.ring_candidates.items():
                d = math.hypot(cx - cand['cx'], cy - cand['cy'])
                if d < best_dist:
                    best_dist = d
                    best_id = cid

            # Map-level match fallback
            map_pt = None
            if best_id is None:
                map_pt = self._project_to_map(int(round(cx)), int(round(cy)), depth_image, depth_stamp)
                if map_pt is not None:
                    if self._is_near_published(map_pt[0], map_pt[1]):
                        continue
                    best_id = self._find_candidate_by_map(map_pt)

            if best_id is not None:
                cand = self.ring_candidates[best_id]
                cand['cx'] = 0.7 * cand['cx'] + 0.3 * cx
                cand['cy'] = 0.7 * cand['cy'] + 0.3 * cy
                cand['r'] = 0.7 * cand['r'] + 0.3 * r
                cand['count'] += 1
                cand['last_seen_frame'] = self.frame_counter
                if map_pt is None:
                    map_pt = self._project_to_map(int(round(cx)), int(round(cy)), depth_image, depth_stamp)
                if map_pt is not None:
                    cand['map_points'].append(map_pt)
                matched_ids.add(best_id)
            else:
                if map_pt is None:
                    map_pt = self._project_to_map(int(round(cx)), int(round(cy)), depth_image, depth_stamp)
                cid = self.candidate_id_counter
                self.candidate_id_counter += 1
                self.ring_candidates[cid] = {
                    'cx': float(cx), 'cy': float(cy), 'r': float(r),
                    'count': 1,
                    'map_points': [map_pt] if map_pt is not None else [],
                    'last_seen_frame': self.frame_counter,
                    'published': False,
                }
                matched_ids.add(cid)

        # Publish candidates with enough sightings
        for cid, cand in list(self.ring_candidates.items()):
            if cand['published']:
                continue
            if cand['count'] >= self.CONFIRM_FRAMES and cand['last_seen_frame'] == self.frame_counter:
                self.get_logger().info(f'[RING] Attempting publish for candidate {cid}: '
                                       f'px=({cand["cx"]:.0f},{cand["cy"]:.0f}), '
                                       f'r={cand["r"]:.0f}, sightings={cand["count"]}, '
                                       f'map_pts={len(cand["map_points"])}')
                self._try_publish_ring(cand, depth_image, depth_stamp)

        stale = [cid for cid, c in self.ring_candidates.items()
                 if self.frame_counter - c['last_seen_frame'] > self.CANDIDATE_MAX_AGE]
        for cid in stale:
            del self.ring_candidates[cid]

    def _try_publish_ring(self, cand, depth_image, depth_stamp):
        """Project ring to 3D, deduplicate, and publish marker."""
        if self.camera_info is None:
            self.get_logger().warn('[RING] No camera_info yet, skipping publish')
            return
        if self.latest_rgb is None:
            self.get_logger().warn('[RING] No RGB image yet, skipping publish')
            return

        cx = int(round(cand['cx']))
        cy = int(round(cand['cy']))
        r = int(round(cand['r']))
        dh, dw = depth_image.shape[:2]

        if cx < 0 or cx >= dw or cy < 0 or cy >= dh:
            self.get_logger().warn(f'[RING] Ring center ({cx},{cy}) out of bounds ({dw}x{dh})')
            return

        # Discard 2D printed circles: a real 3D ring has a hole that either sees
        # through (invalid depth) or is farther than the ring material; a flat
        # printed circle is coplanar with its background.
        if not self._is_3d_ring(cx, cy, r, depth_image):
            self.get_logger().info(f'[RING] Rejected flat/2D circle at ({cx},{cy})')
            cand['published'] = True
            return

        # Sample depth from annulus (ring surface, not hole)
        inner_r = max(int(r * 0.4), 2)
        outer_r = max(int(r * 1.2), inner_r + 2)
        mask = np.zeros((dh, dw), dtype=np.uint8)
        cv2.circle(mask, (cx, cy), outer_r, 255, -1)
        cv2.circle(mask, (cx, cy), inner_r, 0, -1)
        ring_depths = depth_image[mask > 0]
        valid = ring_depths[(ring_depths > 0) & np.isfinite(ring_depths)]

        # Fallback: wider rectangular region
        if len(valid) == 0:
            margin = max(outer_r * 2, 20)
            y0 = max(0, cy - margin)
            y1 = min(dh, cy + margin + 1)
            x0 = max(0, cx - margin)
            x1 = min(dw, cx + margin + 1)
            region = depth_image[y0:y1, x0:x1]
            valid = region[(region > 0) & np.isfinite(region)]

        if len(valid) == 0:
            self.get_logger().warn(f'[RING] No valid depth near ({cx},{cy}), r={r}')
            return

        depth = float(np.median(valid))

        # Don't publish from a far, unreliable depth estimate — wait for a closer
        # sighting so the map position (and dedup) stays accurate.
        if depth > self.MAX_RING_RANGE_M:
            self.get_logger().info(f'[RING] Too far to localise ({depth:.2f} m), '
                                   f'deferring publish at ({cx},{cy})')
            return

        fx = self.camera_info.k[0]
        fy = self.camera_info.k[4]
        cx0 = self.camera_info.k[2]
        cy0 = self.camera_info.k[5]
        if fx == 0 or fy == 0:
            return

        x3d = (cx - cx0) * depth / fx
        y3d = (cy - cy0) * depth / fy
        z3d = depth

        point = PointStamped()
        point.header.frame_id = self.camera_info.header.frame_id
        point.header.stamp = rclpyTime().to_msg()  # Time(0) = use latest available TF
        point.point.x = float(x3d)
        point.point.y = float(y3d)
        point.point.z = float(z3d)

        try:
            point_map = self.tf_buffer.transform(point, 'map', timeout=rclpyDuration(seconds=1.0))
        except Exception as e:
            self.get_logger().warn(f'[RING] TF transform failed: {e}')
            return

        # Average map position from all sightings
        if cand['map_points']:
            all_pts = cand['map_points'] + [(point_map.point.x, point_map.point.y, point_map.point.z)]
            mx = float(np.median([p[0] for p in all_pts]))
            my = float(np.median([p[1] for p in all_pts]))
            mz = float(np.median([p[2] for p in all_pts]))
        else:
            mx, my, mz = point_map.point.x, point_map.point.y, point_map.point.z

        if self._is_near_published(mx, my):
            self.get_logger().info(f'[RING] Skipping duplicate at map=({mx:.2f}, {my:.2f})')
            cand['published'] = True
            return

        color_name = self.classify_ring_color(self.latest_rgb, cx, cy, r, dh, dw)

        color_map = {
            'red':    ColorRGBA(r=1.0, g=0.0, b=0.0, a=0.9),
            'green':  ColorRGBA(r=0.0, g=1.0, b=0.0, a=0.9),
            'blue':   ColorRGBA(r=0.0, g=0.0, b=1.0, a=0.9),
            'yellow': ColorRGBA(r=1.0, g=1.0, b=0.0, a=0.9),
            'orange': ColorRGBA(r=1.0, g=0.5, b=0.0, a=0.9),
            'black':  ColorRGBA(r=0.1, g=0.1, b=0.1, a=0.9),
            'white':  ColorRGBA(r=1.0, g=1.0, b=1.0, a=0.9),
            'purple': ColorRGBA(r=0.5, g=0.0, b=0.5, a=0.9),
            'gray':   ColorRGBA(r=0.5, g=0.5, b=0.5, a=0.9),
        }

        m = Marker()
        m.header.frame_id = 'map'
        m.header.stamp = point.header.stamp
        m.ns = 'detected_ring'
        m.id = len(self.published_ring_map_positions)
        m.type = Marker.CYLINDER
        m.action = Marker.ADD
        m.pose.position.x = mx
        m.pose.position.y = my
        m.pose.position.z = mz
        m.pose.orientation.w = 1.0
        m.scale.x = 0.3
        m.scale.y = 0.3
        m.scale.z = 0.05
        m.color = color_map.get(color_name, ColorRGBA(r=1.0, g=0.5, b=0.0, a=0.9))
        m.text = color_name
        m.lifetime.sec = 0
        self.ring_marker_pub.publish(m)

        cand['published'] = True
        self.published_ring_map_positions.append((mx, my, point_map.point.z, color_name))
        self.detection_pub.publish(String(
            data=f'[RING] color={color_name}  pos=({mx:.2f},{my:.2f})'))
        self.get_logger().info(f'[RING] Published #{m.id}: color={color_name}, '
                               f'map=({mx:.2f}, {my:.2f}), sightings={cand["count"]}')

    def _is_3d_ring(self, cx, cy, r, depth_image):
        """True if the candidate is a real 3D ring (has a hole), False if it is a
        flat 2D printed circle coplanar with its background."""
        dh, dw = depth_image.shape[:2]
        cx, cy, r = int(round(cx)), int(round(cy)), int(round(r))
        if r < 3:
            return False

        # Ring-material depth (annulus 0.5r..1.15r)
        inner = max(int(r * 0.50), 2)
        outer = max(int(r * 1.15), inner + 2)
        amask = np.zeros((dh, dw), np.uint8)
        cv2.circle(amask, (cx, cy), outer, 255, -1)
        cv2.circle(amask, (cx, cy), inner, 0, -1)
        ann = depth_image[amask > 0]
        ann_valid = ann[(ann > 0) & np.isfinite(ann)]
        if len(ann_valid) < 8:
            return False
        ann_d = float(np.median(ann_valid))

        # Hole (centre) depth
        hole_r = max(int(r * 0.35), 1)
        hmask = np.zeros((dh, dw), np.uint8)
        cv2.circle(hmask, (cx, cy), hole_r, 255, -1)
        hole = depth_image[hmask > 0]
        hole_total = int(np.count_nonzero(hmask))
        hole_valid = hole[(hole > 0) & np.isfinite(hole)]
        invalid_ratio = 1.0 - (len(hole_valid) / hole_total) if hole_total else 0.0

        # Real ring: hole mostly sees through (invalid) ...
        if invalid_ratio > 0.40:
            return True
        # ... or the hole is measurably farther than the ring material.
        if len(hole_valid) >= 4:
            hole_d = float(np.median(hole_valid))
            return (hole_d - ann_d) > 0.05   # coplanar (<=5cm) → flat 2D circle
        return True

    def classify_ring_color(self, rgb_image, cx, cy, r, depth_h, depth_w):
        """Classify ring color from HSV analysis of annulus pixels."""
        h, w = rgb_image.shape[:2]

        # Scale depth coords to RGB space
        scale_x = w / depth_w
        scale_y = h / depth_h
        cx_rgb = int(round(cx * scale_x))
        cy_rgb = int(round(cy * scale_y))
        r_rgb = max(int(round(r * (scale_x + scale_y) / 2)), 1)

        self.get_logger().info(f'[RING COLOR] depth=({depth_w}x{depth_h}), rgb=({w}x{h}), '
                               f'scale=({scale_x:.2f},{scale_y:.2f}), '
                               f'depth_px=({cx},{cy}) -> rgb_px=({cx_rgb},{cy_rgb}), '
                               f'r: {r} -> {r_rgb}')

        # Tight annulus on ring material (~0.55r to ~1.05r)
        inner_r = max(int(r_rgb * 0.55), 2)
        outer_r = max(int(r_rgb * 1.05), inner_r + 2)
        mask = np.zeros((h, w), dtype=np.uint8)
        cv2.circle(mask, (cx_rgb, cy_rgb), outer_r, 255, -1)
        cv2.circle(mask, (cx_rgb, cy_rgb), inner_r, 0, -1)

        hsv = cv2.cvtColor(rgb_image, cv2.COLOR_BGR2HSV)
        all_pixels = hsv[mask > 0]

        if len(all_pixels) == 0:
            return "unknown"

        saturations = all_pixels[:, 1]
        values = all_pixels[:, 2]

        # Achromatic check first (black/white)
        dark_ratio = np.sum(values < 60) / len(values)
        bright_unsat_ratio = np.sum((values > 180) & (saturations < 50)) / len(values)

        self.get_logger().info(f'[RING COLOR] px=({cx},{cy}) r={r}, '
                               f'total={len(all_pixels)}, '
                               f'dark_ratio={dark_ratio:.2f}, bright_unsat={bright_unsat_ratio:.2f}')

        if dark_ratio > 0.25:
            self.get_logger().info('[RING COLOR] -> black (significant dark pixels)')
            return "black"
        if bright_unsat_ratio > 0.25:
            self.get_logger().info('[RING COLOR] -> white (significant bright unsaturated)')
            return "white"

        # Chromatic: classify by hue
        chromatic = all_pixels[saturations >= 40]
        if len(chromatic) < len(all_pixels) * 0.10:
            mean_v = float(np.mean(values))
            if mean_v < 80:
                return "black"
            elif mean_v > 200:
                return "white"
            return "gray"

        mean_h = float(np.median(chromatic[:, 0]))
        mean_s = np.mean(chromatic[:, 1])
        mean_v = np.mean(chromatic[:, 2])

        self.get_logger().info(f'[RING COLOR] chromatic={len(chromatic)}, '
                               f'H={mean_h:.1f} S={mean_s:.1f} V={mean_v:.1f}')

        # Brown = dark/low-value orange-yellow
        if (8 <= mean_h <= 30) and mean_v < 120:
            return "brown"
        if mean_h < 10 or mean_h > 170:
            return "red"
        elif mean_h < 25:
            return "orange"
        elif mean_h < 35:
            return "yellow"
        elif mean_h < 85:
            return "green"
        elif mean_h < 130:
            return "blue"
        else:
            return "purple"


def main():

    rclpy.init(args=None)
    rd_node = RingDetector()

    rclpy.spin(rd_node)

    cv2.destroyAllWindows()


if __name__ == '__main__':
    main()