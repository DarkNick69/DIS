#!/usr/bin/env python3
"""Capture + AUTO-LABEL black barrels for YOLO retraining.

The trained barrel model never saw black barrels, so it misses them. Hand-
labeling is tedious, so this node does it for you: drive the robot around the
black barrels and whenever a black, barrel-shaped, barrel-sized 3D object is in
view it writes a ready-to-train sample:

    ~/barrel_dataset_black/images/black_XXXXX.jpg   the RGB frame
    ~/barrel_dataset_black/labels/black_XXXXX.txt   YOLO label(s): "<cls> cx cy w h"
    ~/barrel_dataset_black/preview/black_XXXXX.jpg  same frame with the box drawn

`cls` is 0=barrel_horizontal, 1=barrel_vertical (matches barrels_dataset/data.yaml).

Detection here is intentionally LIBERAL — we want lots of candidates. Afterwards
flip through the preview/ images and delete any wrong sample (the image, label
and preview share the same stem) before merging into barrels_dataset and
training. See the retrain steps printed by train_barrels_black.py.

    ros2 run dis_tutorial7 collect_barrel_data.py
"""

import os

import cv2
import numpy as np

import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data

from sensor_msgs.msg import Image, PointCloud2
from sensor_msgs_py import point_cloud2 as pc2
from cv_bridge import CvBridge, CvBridgeError

OUT      = os.path.expanduser('~/barrel_dataset_black')
EVERY_N  = 6        # process 1 of every N point-cloud frames

# Black barrel appearance (HSV: low value, any/low saturation).
BLACK_LO = np.array([0,   0,   0], np.uint8)
BLACK_HI = np.array([179, 90,  80], np.uint8)

MIN_AREA   = 1500   # px²  contour area
MIN_DIM    = 35     # px   both width and height
MIN_SOLID  = 0.40   # area / bbox area
HORIZ_RATIO = 1.20  # w/h ≥ → horizontal (class 0), else vertical (class 1)
MIN_3D_M   = 0.28   # m    largest real-world extent (rejects small dark blobs)
MIN_2ND_M  = 0.16   # m    2nd extent (a volume, not a flat dark patch)


class BarrelCollector(Node):
    def __init__(self):
        super().__init__('barrel_collector')
        for sub in ('images', 'labels', 'preview'):
            os.makedirs(os.path.join(OUT, sub), exist_ok=True)

        self.bridge  = CvBridge()
        self.rgb     = None
        self.counter = 0
        self.saved   = 0

        self.create_subscription(Image, '/oakd/rgb/preview/image_raw',
                                 self._rgb_cb, qos_profile_sensor_data)
        self.create_subscription(PointCloud2, '/oakd/rgb/preview/depth/points',
                                 self._pc_cb, qos_profile_sensor_data)
        self.get_logger().info(
            f'Collecting black-barrel samples to {OUT} — drive around the black '
            'barrels. Review preview/ and cull bad ones before training.')

    def _rgb_cb(self, msg):
        try:
            self.rgb = self.bridge.imgmsg_to_cv2(msg, 'bgr8')
        except CvBridgeError as e:
            self.get_logger().error(str(e))

    def _pc_cb(self, msg):
        self.counter += 1
        if self.counter % EVERY_N != 0 or self.rgb is None:
            return
        self._process(msg)

    def _process(self, pc_msg):
        rgb  = self.rgb.copy()
        h, w = rgb.shape[:2]
        hsv  = cv2.cvtColor(rgb, cv2.COLOR_BGR2HSV)

        mask = cv2.inRange(hsv, BLACK_LO, BLACK_HI)
        k    = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, k, iterations=2)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN,  k, iterations=1)

        pts = None
        if pc_msg.height > 0 and pc_msg.width > 0:
            pts = pc2.read_points_numpy(
                pc_msg, field_names=('x', 'y', 'z')).reshape(
                    (pc_msg.height, pc_msg.width, 3))

        labels, boxes = [], []
        for cnt in cv2.findContours(mask, cv2.RETR_EXTERNAL,
                                    cv2.CHAIN_APPROX_SIMPLE)[0]:
            x, y, bw, bh = cv2.boundingRect(cnt)
            area = cv2.contourArea(cnt)
            if area < MIN_AREA or bw < MIN_DIM or bh < MIN_DIM:
                continue
            if area / float(bw * bh) < MIN_SOLID:
                continue
            if not self._size_ok(x, y, bw, bh, pts, w, h):
                continue
            cls = 0 if (bw / bh) >= HORIZ_RATIO else 1
            labels.append(f'{cls} {(x + bw / 2) / w:.6f} {(y + bh / 2) / h:.6f} '
                          f'{bw / w:.6f} {bh / h:.6f}')
            boxes.append((x, y, bw, bh, cls))

        if not labels:
            return

        stem = f'black_{self.saved:05d}'
        cv2.imwrite(os.path.join(OUT, 'images', stem + '.jpg'), rgb)
        with open(os.path.join(OUT, 'labels', stem + '.txt'), 'w') as f:
            f.write('\n'.join(labels) + '\n')

        prev = rgb.copy()
        for (x, y, bw, bh, cls) in boxes:
            col = (0, 140, 255) if cls == 0 else (0, 200, 0)
            cv2.rectangle(prev, (x, y), (x + bw, y + bh), col, 2)
            cv2.putText(prev, 'horizontal' if cls == 0 else 'vertical',
                        (x, max(y - 5, 10)), cv2.FONT_HERSHEY_SIMPLEX, 0.5, col, 1)
        cv2.imwrite(os.path.join(OUT, 'preview', stem + '.jpg'), prev)

        self.saved += 1
        cv2.imshow('Collecting black barrels (press Q to quit)', prev)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            raise SystemExit
        if self.saved % 10 == 0:
            self.get_logger().info(f'{self.saved} labeled frames saved to {OUT}')

    def _size_ok(self, x, y, bw, bh, pts, img_w, img_h):
        """Reject dark blobs that are not barrel-sized in 3D (shadows, dark trim)."""
        if pts is None:
            return True
        pc_h, pc_w = pts.shape[:2]
        px0 = max(0, int(x * pc_w / img_w)); px1 = min(pc_w, int((x + bw) * pc_w / img_w))
        py0 = max(0, int(y * pc_h / img_h)); py1 = min(pc_h, int((y + bh) * pc_h / img_h))
        if px1 - px0 < 2 or py1 - py0 < 2:
            return True
        region = pts[py0:py1, px0:px1, :].reshape(-1, 3)
        valid = region[np.isfinite(region).all(axis=1) &
                       (np.abs(region).sum(axis=1) > 1e-6)]
        if len(valid) < 20:
            return True
        lo = np.percentile(valid, 5, axis=0)
        hi = np.percentile(valid, 95, axis=0)
        ext = np.sort(hi - lo)[::-1]
        return ext[0] >= MIN_3D_M and ext[1] >= MIN_2ND_M


def main():
    rclpy.init()
    node = BarrelCollector()
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, SystemExit):
        pass
    finally:
        cv2.destroyAllWindows()
        node.get_logger().info(f'Done. Saved {node.saved} samples to {OUT}.')
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
