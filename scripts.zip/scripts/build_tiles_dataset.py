#!/usr/bin/env python3
"""Build a YOLO *tile-detection* dataset from the RINS_AD tile crops.

Source: RINS_AD_dataset/{train,test}/images/*.png
        (flat 512x512 close-ups where the tile fills the whole frame)

Output: tiles_dataset_aug/{train,val}/{images,labels} + data.yaml
        with a single class: "tile".

The arm camera never sees a tile as a perfect head-on crop — it sees it a bit
from the side, smaller than the frame, and sitting on a background. So instead
of labelling every source image "0 0.5 0.5 1 1", we *composite* each tile onto
a synthetic background with a random perspective warp, scale and position, then
label the tight bounding box of the warped tile. That teaches YOLO to localise a
tile inside a cluttered scene rather than only recognise a full-frame crop.

Defect (okay vs damaged) is intentionally ignored here — this model only finds
*where the tiles are*. The damaged/okay classifier comes later.

Usage:
    python3 scripts/build_tiles_dataset.py            # 12 variants / tile
    python3 scripts/build_tiles_dataset.py --per 20
"""

import argparse
import os
import random
import shutil

import cv2
import numpy as np

CLASS_NAMES = ['tile']
CANVAS = 640          # output image size (matches training imgsz)


# ---------------------------------------------------------------------------
# Synthetic backgrounds (the tile gets pasted on top of one of these)
# ---------------------------------------------------------------------------

def bg_solid(h, w):
    c = np.random.randint(0, 256, 3)
    return np.full((h, w, 3), c, np.uint8)


def bg_gradient(h, w):
    c0 = np.random.randint(0, 256, 3).astype(np.float32)
    c1 = np.random.randint(0, 256, 3).astype(np.float32)
    if random.random() < 0.5:
        t = np.linspace(0, 1, w)[None, :, None]
    else:
        t = np.linspace(0, 1, h)[:, None, None]
    return (c0 * (1 - t) + c1 * t).astype(np.uint8)


def bg_noise(h, w):
    # Low-frequency blobby texture -> vaguely floor / surface like.
    small = np.random.randint(0, 256, (h // 16, w // 16, 3), np.uint8)
    big = cv2.resize(small, (w, h), interpolation=cv2.INTER_CUBIC)
    return cv2.GaussianBlur(big, (0, 0), 3)


def bg_clutter(h, w, distractor):
    # A heavily blurred, darkened other tile as background clutter so the model
    # learns the real tile is the sharp, well-lit object in the scene.
    d = cv2.resize(distractor, (w, h))
    d = cv2.GaussianBlur(d, (0, 0), 8)
    d = cv2.convertScaleAbs(d, alpha=random.uniform(0.3, 0.7), beta=-30)
    return d


def make_background(distractor):
    r = random.random()
    if r < 0.3:
        return bg_noise(CANVAS, CANVAS)
    if r < 0.55:
        return bg_gradient(CANVAS, CANVAS)
    if r < 0.75:
        return bg_solid(CANVAS, CANVAS)
    return bg_clutter(CANVAS, CANVAS, distractor)


# ---------------------------------------------------------------------------
# Photometric augmentation applied to the whole finished canvas
# ---------------------------------------------------------------------------

def photo_aug(img):
    if random.random() < 0.7:
        img = cv2.convertScaleAbs(img, alpha=random.uniform(0.7, 1.3),
                                  beta=random.uniform(-30, 30))
    if random.random() < 0.4:
        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV).astype(np.int16)
        hsv[..., 0] = (hsv[..., 0] + random.randint(-8, 8)) % 180
        hsv[..., 1] = np.clip(hsv[..., 1] + random.randint(-25, 25), 0, 255)
        img = cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2BGR)
    if random.random() < 0.5:
        k = random.choice([3, 5])
        img = cv2.GaussianBlur(img, (k, k), 0)
    if random.random() < 0.3:
        noise = np.random.normal(0, random.uniform(4, 12), img.shape)
        img = np.clip(img.astype(np.float32) + noise, 0, 255).astype(np.uint8)
    if random.random() < 0.5:
        q = random.randint(35, 80)
        ok, enc = cv2.imencode('.jpg', img, [cv2.IMWRITE_JPEG_QUALITY, q])
        if ok:
            img = cv2.imdecode(enc, cv2.IMREAD_COLOR)
    return img


# ---------------------------------------------------------------------------
# Composite one tile onto a background with a random perspective warp
# ---------------------------------------------------------------------------

def composite(tile, distractor):
    """Return (canvas_bgr, (cx, cy, w, h) normalized YOLO bbox)."""
    bg = make_background(distractor)

    th, tw = tile.shape[:2]
    src = np.float32([[0, 0], [tw, 0], [tw, th], [0, th]])

    # Pick a placement box inside the canvas with a margin, then jitter the four
    # corners to fake an off-axis (side) view.
    scale = random.uniform(0.35, 0.92)          # how much of the frame it fills
    side = int(CANVAS * scale)
    margin = CANVAS - side
    ox = random.randint(0, max(margin, 0))
    oy = random.randint(0, max(margin, 0))

    jit = side * random.uniform(0.0, 0.28)       # perspective skew strength
    def j():
        return random.uniform(-jit, jit)
    dst = np.float32([
        [ox + j(),        oy + j()],
        [ox + side + j(), oy + j()],
        [ox + side + j(), oy + side + j()],
        [ox + j(),        oy + side + j()],
    ])
    # Keep the quad inside the canvas so the box is always valid / fully visible.
    dst[:, 0] = np.clip(dst[:, 0], 0, CANVAS - 1)
    dst[:, 1] = np.clip(dst[:, 1], 0, CANVAS - 1)

    M = cv2.getPerspectiveTransform(src, dst)
    warped = cv2.warpPerspective(tile, M, (CANVAS, CANVAS))
    mask = cv2.warpPerspective(np.full((th, tw), 255, np.uint8), M,
                               (CANVAS, CANVAS))
    mask3 = mask[..., None] > 0
    canvas = np.where(mask3, warped, bg)

    xs, ys = dst[:, 0], dst[:, 1]
    x1, y1, x2, y2 = xs.min(), ys.min(), xs.max(), ys.max()
    cx = (x1 + x2) / 2 / CANVAS
    cy = (y1 + y2) / 2 / CANVAS
    w = (x2 - x1) / CANVAS
    h = (y2 - y1) / CANVAS
    return canvas.astype(np.uint8), (cx, cy, w, h)


# ---------------------------------------------------------------------------

def collect_sources(root):
    src_files = []
    for split in ('train', 'test'):
        d = os.path.join(root, 'RINS_AD_dataset', split, 'images')
        if os.path.isdir(d):
            src_files += [os.path.join(d, f) for f in os.listdir(d)
                          if f.lower().endswith('.png')]
    return sorted(src_files)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', default='tiles_dataset_aug')
    ap.add_argument('--per', type=int, default=12, help='variants per tile')
    ap.add_argument('--val', type=float, default=0.15, help='val fraction')
    ap.add_argument('--seed', type=int, default=0)
    args = ap.parse_args()

    random.seed(args.seed)
    np.random.seed(args.seed)

    here = os.path.dirname(os.path.abspath(__file__))
    root = os.path.dirname(here)
    out = os.path.join(root, args.out)

    sources = collect_sources(root)
    if not sources:
        raise SystemExit('No source tiles found under RINS_AD_dataset/*/images')
    print(f'{len(sources)} source tiles found')

    if os.path.exists(out):
        shutil.rmtree(out)
    for split in ('train', 'val'):
        os.makedirs(os.path.join(out, split, 'images'))
        os.makedirs(os.path.join(out, split, 'labels'))

    total = 0
    for idx, path in enumerate(sources):
        tile = cv2.imread(path)
        if tile is None:
            continue
        # A different tile used only as background clutter.
        distractor = cv2.imread(random.choice(sources))
        if distractor is None:
            distractor = tile

        for i in range(args.per):
            canvas, (cx, cy, w, h) = composite(tile, distractor)
            canvas = photo_aug(canvas)
            split = 'val' if random.random() < args.val else 'train'
            stem = f'tile_{idx:04d}_{i:02d}'
            cv2.imwrite(os.path.join(out, split, 'images', stem + '.jpg'), canvas)
            with open(os.path.join(out, split, 'labels', stem + '.txt'), 'w') as fh:
                fh.write(f'0 {cx:.6f} {cy:.6f} {w:.6f} {h:.6f}\n')
            total += 1
        if (idx + 1) % 100 == 0:
            print(f'  {idx + 1}/{len(sources)} tiles -> {total} images')

    names_block = '\n'.join(f'  {i}: {n}' for i, n in enumerate(CLASS_NAMES))
    with open(os.path.join(out, 'data.yaml'), 'w') as fh:
        fh.write(f'train: {os.path.join(out, "train", "images")}\n')
        fh.write(f'val:   {os.path.join(out, "val", "images")}\n\n')
        fh.write(f'nc: {len(CLASS_NAMES)}\n')
        fh.write(f'names:\n{names_block}\n')

    print(f'\nDone: {total} images -> {out}')
    print('Train with:')
    print(f'  /opt/ultralytics/bin/python3 scripts/train_tiles.py')


if __name__ == '__main__':
    main()
