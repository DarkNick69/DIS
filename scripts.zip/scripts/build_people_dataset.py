#!/usr/bin/env python3
"""Build an augmented people-recognition dataset from one portrait per person.

Source: personnel/<name>_..._....png  (one clean 512x512 portrait per person)
Output: people_dataset_aug/{train,val}/{images,labels} + data.yaml

The augmentations deliberately mimic how a face looks in the robot camera's
upscaled head crop (low resolution, blur, JPEG artifacts, varied lighting,
small rotation) so the model trains on something close to what it sees at
inference. The face is kept filling the frame, so every YOLO label is the
whole image: "<cls> 0.5 0.5 1 1".

Free, local, no image cap, no extra dependencies beyond OpenCV + NumPy.

Usage:
    python3 scripts/build_people_dataset.py            # 60 variants/person
    python3 scripts/build_people_dataset.py --per 100  # more variants
"""

import argparse
import os
import random
import shutil

import cv2
import numpy as np

# Keep the SAME class order as the existing people_dataset/data.yaml so the
# model's output names stay consistent with detect_people_recognition.py.
CLASS_ORDER = ['anita', 'anna', 'david', 'elena', 'felix', 'fred', 'luka',
               'sofia', 'jeff', 'laura', 'maria', 'robert', 'sara', 'victor']
NAME_TO_ID = {n: i for i, n in enumerate(CLASS_ORDER)}

OUT_SIZE = 416   # final image size (matches training imgsz)


# ---------------------------------------------------------------------------
# Individual augmentations (each takes/returns a BGR uint8 image)
# ---------------------------------------------------------------------------

def aug_rotate(img):
    h, w = img.shape[:2]
    ang = random.uniform(-15, 15)
    M = cv2.getRotationMatrix2D((w / 2, h / 2), ang, 1.0)
    return cv2.warpAffine(img, M, (w, h), borderMode=cv2.BORDER_REFLECT_101)


def aug_zoom(img):
    # Slight zoom-in keeps the face filling the frame (label stays 0.5 0.5 1 1).
    h, w = img.shape[:2]
    s = random.uniform(1.0, 1.25)
    nh, nw = int(h * s), int(w * s)
    big = cv2.resize(img, (nw, nh))
    y = random.randint(0, nh - h)
    x = random.randint(0, nw - w)
    return big[y:y + h, x:x + w]


def aug_brightness_contrast(img):
    alpha = random.uniform(0.7, 1.3)   # contrast
    beta = random.uniform(-30, 30)     # brightness
    return cv2.convertScaleAbs(img, alpha=alpha, beta=beta)


def aug_gamma(img):
    g = random.uniform(0.6, 1.6)
    lut = np.array([((i / 255.0) ** (1.0 / g)) * 255
                    for i in range(256)]).astype(np.uint8)
    return cv2.LUT(img, lut)


def aug_hue_sat(img):
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV).astype(np.int16)
    hsv[..., 0] = (hsv[..., 0] + random.randint(-10, 10)) % 180
    hsv[..., 1] = np.clip(hsv[..., 1] + random.randint(-25, 25), 0, 255)
    return cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2BGR)


def aug_blur(img):
    if random.random() < 0.5:                       # gaussian blur
        k = random.choice([3, 5, 7])
        return cv2.GaussianBlur(img, (k, k), 0)
    k = random.choice([5, 7, 9])                    # motion blur
    kernel = np.zeros((k, k))
    if random.random() < 0.5:
        kernel[k // 2, :] = 1.0
    else:
        kernel[:, k // 2] = 1.0
    return cv2.filter2D(img, -1, kernel / k)


def aug_downscale(img):
    # KEY: simulate a distant / low-res face — shrink hard, then scale back up.
    h, w = img.shape[:2]
    f = random.uniform(0.20, 0.55)
    small = cv2.resize(img, (max(1, int(w * f)), max(1, int(h * f))),
                       interpolation=cv2.INTER_AREA)
    return cv2.resize(small, (w, h), interpolation=cv2.INTER_LINEAR)


def aug_jpeg(img):
    q = random.randint(25, 75)
    ok, enc = cv2.imencode('.jpg', img, [cv2.IMWRITE_JPEG_QUALITY, q])
    return cv2.imdecode(enc, cv2.IMREAD_COLOR) if ok else img


def aug_noise(img):
    noise = np.random.normal(0, random.uniform(4, 14), img.shape)
    return np.clip(img.astype(np.float32) + noise, 0, 255).astype(np.uint8)


def aug_flip(img):
    return cv2.flip(img, 1)


# (function, probability)
PIPELINE = [
    (aug_flip,               0.5),
    (aug_rotate,             0.7),
    (aug_zoom,               0.5),
    (aug_brightness_contrast, 0.7),
    (aug_gamma,              0.4),
    (aug_hue_sat,            0.5),
    (aug_downscale,          0.7),   # distance / low-res
    (aug_blur,               0.6),
    (aug_jpeg,               0.6),
    (aug_noise,              0.3),
]


def augment(img):
    for fn, p in PIPELINE:
        if random.random() < p:
            img = fn(img)
    return img


# ---------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--src', default='personnel')
    ap.add_argument('--out', default='people_dataset_aug')
    ap.add_argument('--per', type=int, default=60, help='variants per person')
    ap.add_argument('--val', type=float, default=0.15, help='val fraction')
    ap.add_argument('--seed', type=int, default=0)
    args = ap.parse_args()

    random.seed(args.seed)
    np.random.seed(args.seed)

    here = os.path.dirname(os.path.abspath(__file__))
    root = os.path.dirname(here)
    src = os.path.join(root, args.src)
    out = os.path.join(root, args.out)

    if os.path.exists(out):
        shutil.rmtree(out)
    for split in ('train', 'val'):
        os.makedirs(os.path.join(out, split, 'images'))
        os.makedirs(os.path.join(out, split, 'labels'))

    files = sorted(f for f in os.listdir(src)
                   if f.lower().endswith(('.png', '.jpg', '.jpeg')))
    total = 0
    for f in files:
        name = f.split('_')[0].lower()
        if name not in NAME_TO_ID:
            print(f'  ! skip {f}: "{name}" not in CLASS_ORDER')
            continue
        cls = NAME_TO_ID[name]
        img0 = cv2.imread(os.path.join(src, f))
        if img0 is None:
            print(f'  ! could not read {f}')
            continue

        for i in range(args.per):
            img = augment(img0.copy())
            img = cv2.resize(img, (OUT_SIZE, OUT_SIZE))
            split = 'val' if random.random() < args.val else 'train'
            stem = f'{name}_{i:03d}'
            cv2.imwrite(os.path.join(out, split, 'images', stem + '.jpg'), img)
            with open(os.path.join(out, split, 'labels', stem + '.txt'), 'w') as fh:
                fh.write(f'{cls} 0.5 0.5 1 1\n')   # face fills the frame
            total += 1
        print(f'  {name:8s} (cls {cls:2d}): {args.per} variants')

    names_block = '\n'.join(f'  {i}: {n}' for i, n in enumerate(CLASS_ORDER))
    with open(os.path.join(out, 'data.yaml'), 'w') as fh:
        fh.write(f'train: {os.path.join(out, "train", "images")}\n')
        fh.write(f'val:   {os.path.join(out, "val", "images")}\n\n')
        fh.write(f'nc: {len(CLASS_ORDER)}\n')
        fh.write(f'names:\n{names_block}\n')

    print(f'\nDone: {total} images -> {out}')
    print(f'data.yaml written. Train with:')
    print(f'  yolo detect train model=yolov8n.pt data={out}/data.yaml '
          f'imgsz={OUT_SIZE} epochs=120 name=people_recognition_aug')


if __name__ == '__main__':
    main()
