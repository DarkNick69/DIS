#! /usr/bin/env python3
"""robot_commander.py — the single mission brain for Task 2.

(Merged: this file now also contains what used to live in mission_control.py.)

High-level behaviour
--------------------
1. Wait for Nav2, undock, point the arm down (enables blue-line detection).
2. Patrol the waypoints from waypoints.txt.
3. When a person (face) is detected, drive up to them and **read the QR code**
   beside them. The QR payload names the task to perform; we search it for a
   keyword:
       "ring"        → ring inspection
       "barrel"      → barrel inspection
       "red belt"    → red-belt inspection   (placeholder — schoolmate's task)
       "green belt"  → green-belt inspection (placeholder — schoolmate's task)
       "visitor"     → no task, skip the person
4. Perform the task. Every task is **self-enclosed**: the commander calls it,
   waits for it to finish, then carries on.
       - ring / barrel inspection → drive through all waypoints *except the
         last* (the last one initialises blue-line following) while the
         detectors accumulate detections + orientation.
       - belt inspection → trigger the (placeholder) belt node and wait.
5. After any task, drive **back to the person who assigned it** and generate a
   PDF report (`/generate_report`).
6. Resume the patrol, detect new people, run their tasks — until the robot
   reaches the blue line, after which it just follows the line.
"""

import math
import os
import time
from enum import Enum

from pkg_paths import p

from action_msgs.msg import GoalStatus
from geometry_msgs.msg import Quaternion, PoseStamped, PoseWithCovarianceStamped, TwistStamped
from lifecycle_msgs.srv import GetState
from nav2_msgs.action import NavigateToPose
from turtle_tf2_py.turtle_tf2_broadcaster import quaternion_from_euler
from irobot_create_msgs.action import Undock
from irobot_create_msgs.msg import DockStatus
from std_msgs.msg import Bool, Empty, Float64, Int32, String
from visualization_msgs.msg import Marker

import rclpy
from rclpy.action import ActionClient
from rclpy.duration import Duration as rclpyDuration
from rclpy.node import Node
from rclpy.qos import (
    QoSDurabilityPolicy, QoSHistoryPolicy,
    QoSProfile, QoSReliabilityPolicy, qos_profile_sensor_data,
)

import tf2_ros
import tf2_geometry_msgs  # noqa: F401  (registers PoseStamped transform support)


WAYPOINTS_FILE = p('waypoints.txt')

# When framing a person to read their task, aim this far to the robot's LEFT of
# the face. The QR is mounted on the wall just left of the face, so a small left
# offset keeps BOTH the face and the whole QR inside the (narrow 320x240) frame.
QR_FRAME_OFFSET = 0.25   # m

# QR keyword → internal task code.
TASK_RINGS      = 'rings'
TASK_BARRELS    = 'barrels'
TASK_RED_BELT   = 'red_belt'
TASK_GREEN_BELT = 'green_belt'
TASK_VISITOR    = 'visitor'

# Internal task code → report section code understood by report_generator
# (it maps these to the PDF section headings via SECTION_OF).
REPORT_CODE = {
    TASK_RINGS:      'ring_count',
    TASK_BARRELS:    'barrel_inspection',
    TASK_RED_BELT:   'anomaly_red',
    TASK_GREEN_BELT: 'anomaly_green',
}


def parse_qr_task(text):
    """Map a QR payload to a task code, or None if no keyword is present."""
    t = (text or '').lower()
    if not t:
        return None
    if 'red belt' in t or 'red_belt' in t:
        return TASK_RED_BELT
    if 'green belt' in t or 'green_belt' in t:
        return TASK_GREEN_BELT
    if 'belt' in t:                      # belt named without an explicit colour
        if 'red' in t:
            return TASK_RED_BELT
        if 'green' in t:
            return TASK_GREEN_BELT
    if 'ring' in t:
        return TASK_RINGS
    if 'barrel' in t:
        return TASK_BARRELS
    if 'visitor' in t:
        return TASK_VISITOR
    return None


class TaskResult(Enum):
    UNKNOWN   = 0
    SUCCEEDED = 1
    CANCELED  = 2
    FAILED    = 3


class Mode(Enum):
    WAYPOINTS       = 0
    LINE_FOLLOW     = 1
    TURNING_AROUND  = 2   # spinning 180° at a dead end
    APPROACH_PERSON = 3   # driving up to a detected person


amcl_qos = QoSProfile(
    durability=QoSDurabilityPolicy.TRANSIENT_LOCAL,
    reliability=QoSReliabilityPolicy.RELIABLE,
    history=QoSHistoryPolicy.KEEP_LAST,
    depth=1,
)


# ── helpers ───────────────────────────────────────────────────────────────────

def wait_for_task(node):
    """Spin until the current nav task finishes."""
    while rclpy.ok() and not node.isTaskComplete():
        rclpy.spin_once(node, timeout_sec=0.05)


def load_waypoints(path):
    """Parse a `ros2 topic echo /clicked_point` dump into [(x, y), ...]."""
    if not os.path.isfile(path):
        return []
    pts = []
    x = y = None
    in_point = False
    with open(path) as f:
        for line in f:
            s = line.strip()
            if s.startswith('point:'):
                in_point, x, y = True, None, None
            elif in_point and s.startswith('x:'):
                x = float(s.split(':', 1)[1])
            elif in_point and s.startswith('y:'):
                y = float(s.split(':', 1)[1])
            elif in_point and s.startswith('z:'):
                if x is not None and y is not None:
                    pts.append((x, y))
                in_point = False
    return pts


# ── robot commander ───────────────────────────────────────────────────────────

class RobotCommander(Node):

    def __init__(self, node_name='robot_commander', namespace=''):
        super().__init__(node_name=node_name, namespace=namespace)

        self.pose_frame_id         = 'map'
        self.goal_handle           = None
        self.result_future         = None
        self.feedback              = None
        self.status                = None
        self.initial_pose_received = False
        self.is_docked             = None
        self.current_pose          = None

        self.mode = Mode.WAYPOINTS   # callbacks gate detections on this

        # Blue line state (top/hand camera, arm looking down)
        self.blue_detected  = False
        self.blue_count     = 0
        self.blue_cx_left   = -1.0
        self.blue_cx_right  = -1.0
        self.blue_ahead     = True   # assume line continues until told otherwise

        # Person detection state (detection only — no recognition needed for tasks)
        self.pending_detection = None   # (mx, my) person to approach
        self.last_person_xy    = None   # (mx, my) most recent sighting of the target
        self.approach_target   = None   # (mx, my) person currently being approached
        self.handled_people    = []     # (mx, my) people already visited
        self.visited_count     = 0      # for unique marker ids
        self.HANDLED_DIST      = 1.5    # m — don't re-approach someone already handled
        self.TRACK_DIST        = 1.5    # m — sightings within this of the target count

        # Recognition state — identities published by detect_people_recognition
        # on /identified_people (name|role|gender|mx|my|mz). Used only to label
        # the person and the report's "Requested by" line.
        self.identities        = []     # (name, role, gender, mx, my)
        self.current_person    = None   # (name, role, gender, recv_time) — live

        # Latest QR payload seen by detect_qr (on the forward camera). `latest_qr`
        # is reset before each fresh read; `approach_qr` persists every code seen
        # since the current approach began (reset when a new approach starts) so a
        # code glimpsed mid-approach can be used even if the QR is partly out of
        # frame once the robot is squared up on the face.
        self.latest_qr  = None
        self.approach_qr = None
        self.last_qr_time     = 0.0   # wall-clock of the most recent /qr_code msg
        self.last_person_time = 0.0   # wall-clock of the most recent target sighting

        # Task completion flags — set when each self-enclosed task node publishes
        # on its <task>_done topic.
        self.task_done = {
            TASK_RINGS:      False,
            TASK_BARRELS:    False,
            TASK_RED_BELT:   False,
            TASK_GREEN_BELT: False,
        }

        # TF for transforming detected person poses into the map frame
        self.tf_buffer   = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)

        # ── subscriptions ──────────────────────────────────────────────────
        self.create_subscription(DockStatus,
                                 'dock_status', self._dock_cb,
                                 qos_profile_sensor_data)
        self.create_subscription(PoseWithCovarianceStamped,
                                 'amcl_pose', self._amcl_cb, amcl_qos)
        self.create_subscription(Bool,
                                 '/blue_line_detected', self._blue_detected_cb, 10)
        self.create_subscription(Int32,
                                 '/blue_line_count', self._blue_count_cb, 10)
        self.create_subscription(Float64,
                                 '/blue_line_cx_left', self._blue_cx_left_cb, 10)
        self.create_subscription(Float64,
                                 '/blue_line_cx_right', self._blue_cx_right_cb, 10)
        self.create_subscription(Bool,
                                 '/blue_line_ahead', self._blue_ahead_cb, 10)
        self.create_subscription(PoseStamped,
                                 '/detected_people_pose', self._detected_cb, 10)
        self.create_subscription(String,
                                 '/identified_people', self._identity_cb, 10)
        self.create_subscription(String,
                                 '/recognized_person', self._recognized_cb, 10)
        self.create_subscription(String, '/qr_code', self._qr_cb, 10)
        self.create_subscription(Empty, '/rings_done',
                                 lambda m: self._task_done_cb(TASK_RINGS), 10)
        self.create_subscription(Empty, '/barrels_done',
                                 lambda m: self._task_done_cb(TASK_BARRELS), 10)
        self.create_subscription(Empty, '/red_belt_done',
                                 lambda m: self._task_done_cb(TASK_RED_BELT), 10)
        self.create_subscription(Empty, '/green_belt_done',
                                 lambda m: self._task_done_cb(TASK_GREEN_BELT), 10)

        # ── publishers / clients ───────────────────────────────────────────
        self.initial_pose_pub = self.create_publisher(
            PoseWithCovarianceStamped, 'initialpose', 10)
        self.say_pub = self.create_publisher(String, '/robot_say', 10)
        self.arm_pub = self.create_publisher(String, '/arm_command', 10)

        # Orchestration publishers: report + a start trigger per self-enclosed task.
        self.report_pub = self.create_publisher(String, '/generate_report',  1)
        self.assign_pub = self.create_publisher(String, '/dialogue_result', 10)
        self.task_start_pubs = {
            TASK_RINGS:      self.create_publisher(Empty, '/inspect_rings',      10),
            TASK_BARRELS:    self.create_publisher(Empty, '/inspect_barrels',    10),
            TASK_RED_BELT:   self.create_publisher(Empty, '/inspect_red_belt',   10),
            TASK_GREEN_BELT: self.create_publisher(Empty, '/inspect_green_belt', 10),
        }

        # Markers for visited people — reliable + transient-local so they persist
        # and are seen by RViz displays that connect later.
        marker_qos = QoSProfile(
            durability=QoSDurabilityPolicy.TRANSIENT_LOCAL,
            reliability=QoSReliabilityPolicy.RELIABLE,
            history=QoSHistoryPolicy.KEEP_LAST,
            depth=20,
        )
        self.people_marker_pub = self.create_publisher(
            Marker, '/people_marker', marker_qos)

        self.nav_client    = ActionClient(self, NavigateToPose, 'navigate_to_pose')
        self.undock_client = ActionClient(self, Undock, 'undock')
        self.cmd_vel_pub   = self.create_publisher(TwistStamped, 'cmd_vel', 10)

        self.info('RobotCommander initialised.')

    def destroyNode(self):
        self.nav_client.destroy()
        super().destroy_node()

    # ── Nav2 ─────────────────────────────────────────────────────────────────

    def goToPose(self, pose, behavior_tree=''):
        while not self.nav_client.wait_for_server(timeout_sec=1.0):
            self.info("'NavigateToPose' server not available, waiting...")
        goal = NavigateToPose.Goal()
        goal.pose = pose
        goal.behavior_tree = behavior_tree
        self.info(f'Nav → ({pose.pose.position.x:.2f}, {pose.pose.position.y:.2f})')
        future = self.nav_client.send_goal_async(goal, self._feedback_cb)
        rclpy.spin_until_future_complete(self, future)
        self.goal_handle = future.result()
        if not self.goal_handle.accepted:
            self.error('Goal rejected.')
            return False
        self.result_future = self.goal_handle.get_result_async()
        return True

    def cancelTask(self):
        self.info('Cancelling task.')
        if self.result_future:
            future = self.goal_handle.cancel_goal_async()
            rclpy.spin_until_future_complete(self, future)

    def isTaskComplete(self):
        if not self.result_future:
            return True
        rclpy.spin_until_future_complete(self, self.result_future, timeout_sec=0.10)
        if self.result_future.result():
            self.status = self.result_future.result().status
            return self.status not in (GoalStatus.STATUS_ACCEPTED,
                                       GoalStatus.STATUS_EXECUTING)
        return False

    def getResult(self):
        if self.status == GoalStatus.STATUS_SUCCEEDED:
            return TaskResult.SUCCEEDED
        if self.status == GoalStatus.STATUS_ABORTED:
            return TaskResult.FAILED
        if self.status == GoalStatus.STATUS_CANCELED:
            return TaskResult.CANCELED
        return TaskResult.UNKNOWN

    def navTo(self, pose, label=''):
        """Blocking navigation: send the goal and spin until it finishes."""
        if not self.goToPose(pose):
            self.warn(f'[NAV] Goal rejected: {label}')
            return False
        wait_for_task(self)
        ok = self.getResult() == TaskResult.SUCCEEDED
        if not ok:
            self.warn(f'[NAV] {label} ended: {self.getResult().name}')
        return ok

    def waitUntilNav2Active(self, navigator='bt_navigator', localizer='amcl'):
        self._waitForNode(localizer)
        if not self.initial_pose_received:
            time.sleep(1)
        self._waitForNode(navigator)
        self.info('Nav2 ready.')

    def _waitForNode(self, node_name):
        svc    = f'{node_name}/get_state'
        client = self.create_client(GetState, svc)
        while not client.wait_for_service(timeout_sec=1.0):
            self.info(f'{svc} not available, waiting...')
        req   = GetState.Request()
        state = 'unknown'
        while state != 'active':
            future = client.call_async(req)
            rclpy.spin_until_future_complete(self, future)
            if future.result() is not None:
                state = future.result().current_state.label
            time.sleep(2)

    def undock(self):
        self.info('Undocking...')
        self.undock_client.wait_for_server()
        future = self.undock_client.send_goal_async(Undock.Goal())
        rclpy.spin_until_future_complete(self, future)
        handle = future.result()
        if not handle or not handle.accepted:
            self.error('Undock rejected.')
            return
        result_future = handle.get_result_async()
        while not result_future.done():
            rclpy.spin_once(self, timeout_sec=0.1)
        self.info('Undocked.')

    # ── velocity / arm helpers ────────────────────────────────────────────────

    def publishVelocity(self, linear_x, angular_z):
        msg = TwistStamped()
        msg.header.stamp    = self.get_clock().now().to_msg()
        msg.twist.linear.x  = float(linear_x)
        msg.twist.angular.z = float(angular_z)
        self.cmd_vel_pub.publish(msg)

    def stopRobot(self):
        self.publishVelocity(0.0, 0.0)

    def setArm(self, pose_name):
        self.arm_pub.publish(String(data=pose_name))
        self.info(f'[ARM] → {pose_name}')

    def spinFor(self, seconds):
        """Spin the node for a fixed duration (lets callbacks/detectors run)."""
        end = time.time() + seconds
        while rclpy.ok() and time.time() < end:
            rclpy.spin_once(self, timeout_sec=0.05)

    def scan360(self, seconds=20.0, rate=0.9):
        """Spin anti-clockwise in place for `seconds` at `rate` rad/s so the
        always-on detectors (rings, barrels, faces) get a view all around before
        moving to the next waypoint. Keeps the node spinning so callbacks/
        detectors run during the turn."""
        self.info(f'[SCAN] anti-clockwise spin ({seconds:.0f}s @ {rate:.1f} rad/s).')
        end = time.time() + seconds
        while rclpy.ok() and time.time() < end:
            self.publishVelocity(0.0, rate)   # +z = anti-clockwise (REP-103)
            rclpy.spin_once(self, timeout_sec=0.05)
        self.stopRobot()

    # ── speech / pose helpers ─────────────────────────────────────────────────

    def say(self, text):
        self.info(f'[SAY] {text}')
        self.say_pub.publish(String(data=text))

    def markPerson(self, x, y, name=None):
        """Drop a persistent RViz marker at a visited person's location."""
        self.visited_count += 1
        n = self.visited_count

        m = Marker()
        m.header.frame_id    = 'map'
        m.header.stamp       = self.get_clock().now().to_msg()
        m.ns                 = 'visited_person'
        m.id                 = n
        m.type               = Marker.SPHERE
        m.action             = Marker.ADD
        m.scale.x = m.scale.y = m.scale.z = 0.4
        m.color.r, m.color.g, m.color.b, m.color.a = 1.0, 0.0, 0.0, 1.0
        m.pose.position.x    = float(x)
        m.pose.position.y    = float(y)
        m.pose.position.z    = 0.3
        m.pose.orientation.w = 1.0
        self.people_marker_pub.publish(m)

        t = Marker()
        t.header             = m.header
        t.ns                 = 'visited_person_label'
        t.id                 = n
        t.type               = Marker.TEXT_VIEW_FACING
        t.action             = Marker.ADD
        t.scale.z            = 0.25
        t.color.r = t.color.g = t.color.b = t.color.a = 1.0
        t.pose.position.x    = float(x)
        t.pose.position.y    = float(y)
        t.pose.position.z    = 0.8
        t.pose.orientation.w = 1.0
        t.text               = name.capitalize() if name else f'Person {n}'
        self.people_marker_pub.publish(t)
        self.info(f'[PERSON] Marked person {n} at ({x:.2f}, {y:.2f}).')

    def approachPose(self, px, py, standoff=0.8):
        """Pose `standoff` metres short of (px, py), facing the person."""
        rx = self.current_pose.position.x if self.current_pose else 0.0
        ry = self.current_pose.position.y if self.current_pose else 0.0
        dx, dy = px - rx, py - ry
        dist   = math.hypot(dx, dy)
        yaw    = math.atan2(dy, dx)
        if dist <= standoff:
            return self.buildPose(rx, ry, yaw)
        f = (dist - standoff) / dist
        return self.buildPose(rx + dx * f, ry + dy * f, yaw)

    def framePoint(self, px, py):
        """A point QR_FRAME_OFFSET metres to the robot's LEFT of (px, py).

        Aiming the camera here (rather than straight at the face) keeps both the
        face and the wall QR — which sits just left of the face — inside the
        narrow forward frame while reading the task."""
        rx = self.current_pose.position.x if self.current_pose else 0.0
        ry = self.current_pose.position.y if self.current_pose else 0.0
        yaw = math.atan2(py - ry, px - rx)
        left = yaw + math.pi / 2.0      # robot's left, perpendicular to approach
        return (px + QR_FRAME_OFFSET * math.cos(left),
                py + QR_FRAME_OFFSET * math.sin(left))

    def buildPose(self, x, y, yaw=0.0, orientation=None):
        pose = PoseStamped()
        pose.header.frame_id  = self.pose_frame_id
        pose.header.stamp     = self.get_clock().now().to_msg()
        pose.pose.position.x  = float(x)
        pose.pose.position.y  = float(y)
        pose.pose.orientation = orientation if orientation is not None else self._yaw_to_quat(yaw)
        return pose

    def _yaw_to_quat(self, yaw):
        q = quaternion_from_euler(0, 0, yaw)
        return Quaternion(x=q[0], y=q[1], z=q[2], w=q[3])

    @staticmethod
    def _quat_to_yaw(q):
        return math.atan2(2.0 * (q.w * q.z + q.x * q.y),
                          1.0 - 2.0 * (q.y * q.y + q.z * q.z))

    @staticmethod
    def _norm_angle(a):
        return math.atan2(math.sin(a), math.cos(a))

    def _to_map_xy(self, ps):
        """Transform a PoseStamped into map-frame (x, y). None on failure."""
        if ps.header.frame_id in ('map', ''):
            return ps.pose.position.x, ps.pose.position.y
        try:
            t = self.tf_buffer.transform(ps, 'map', timeout=rclpyDuration(seconds=0.3))
            return t.pose.position.x, t.pose.position.y
        except Exception:
            return None

    def _is_handled(self, mx, my):
        return any(math.hypot(mx - hx, my - hy) < self.HANDLED_DIST
                   for hx, hy in self.handled_people)

    # ── QR reading ──────────────────────────────────────────────────────────

    def readQR(self, timeout=6.0):
        """Wait for detect_qr to report a QR payload on /qr_code. Returns the
        decoded text or None. The QR is on the wall left of the person and is
        seen by the same forward camera, so no arm movement is needed."""
        self.latest_qr = None     # discard anything stale; want a fresh sighting
        deadline = time.time() + timeout
        while rclpy.ok() and time.time() < deadline:
            rclpy.spin_once(self, timeout_sec=0.1)
            if self.latest_qr is not None:
                self.info(f'[QR] read: "{self.latest_qr}"')
                return self.latest_qr
        # No fresh read (often because the QR got chopped once we squared up on
        # the face). Fall back to anything seen earlier in THIS approach.
        if self.approach_qr is not None:
            self.warn(f'[QR] no fresh code; using one seen during approach: '
                      f'"{self.approach_qr}".')
            return self.approach_qr
        self.warn('[QR] no code read before timeout.')
        return None

    # ── self-enclosed tasks ───────────────────────────────────────────────────

    def runTask(self, task, timeout=600.0):
        """Run a self-enclosed task node: publish its start trigger and block
        until it reports done (or we time out). Each task node owns its own
        behaviour (driving, detecting), so the commander just waits here."""
        self.task_done[task] = False
        self.task_start_pubs[task].publish(Empty())
        self.info(f'[TASK] triggered {task}; waiting for completion.')
        deadline = time.time() + timeout
        while rclpy.ok() and not self.task_done[task] and time.time() < deadline:
            rclpy.spin_once(self, timeout_sec=0.1)
        if not self.task_done[task]:
            self.warn(f'[TASK] {task} timed out after {timeout:.0f}s.')
        else:
            self.info(f'[TASK] {task} finished.')

    def recognizePerson(self, tx, ty, timeout=4.0):
        """Layer 2: hold still in front of the person and wait for face
        recognition to identify them. Prefers the live identity of whoever is in
        view (/recognized_person), falling back to a position-matched
        /identified_people announcement. Returns (name, role, gender) or None."""
        deadline = time.time() + timeout
        while rclpy.ok() and time.time() < deadline:
            rclpy.spin_once(self, timeout_sec=0.1)
            if self.current_person is not None and \
                    time.time() - self.current_person[3] < 1.0:
                return self.current_person[:3]
        return self.lookupIdentity(tx, ty, 1.5)

    def handlePersonTask(self, tx, ty):
        """Recognise the person (layer 2), read the QR beside them, run the
        assigned task, return to the person and generate the report. Returns the
        task code performed (or 'visitor'/None when nothing was done)."""
        # Layer 2: recognise the face before doing anything else.
        self.say('Let me see who you are.')
        ident = self.recognizePerson(tx, ty)
        if ident is not None:
            name, role, gender = ident
            self.say(f'Hello {name}. You are the {role}.')
            self.info(f'[RECOG] Identified {name} ({role}, {gender}).')
        else:
            name = 'visitor'
            self.warn('[RECOG] Could not recognise this person.')
            self.say('I could not recognise you.')

        # The QR is on the wall left of the person, in view of the same forward
        # camera — no arm movement needed. Just wait for detect_qr to read it.
        self.say('Reading the task QR code.')
        qr = self.readQR()
        task = parse_qr_task(qr)

        if task is None:
            self.say('I could not read a task. Skipping this person.')
            return None
        if task == TASK_VISITOR:
            self.say('This is a visitor. No task to perform.')
            return TASK_VISITOR

        self.say(f'The task is {task.replace("_", " ")}.')

        # Belt tasks are placeholders (shorter timeout); sweeps may take a while.
        timeout = 120.0 if task in (TASK_RED_BELT, TASK_GREEN_BELT) else 600.0
        self.runTask(task, timeout=timeout)

        self.generateReport(task, name)
        return task

    def generateReport(self, task, name):
        """Tell the report generator who requested which task, then trigger the
        PDF. report_generator writes a cumulative report each time."""
        code = REPORT_CODE.get(task)
        if not code:
            return
        self.assign_pub.publish(String(data=f'{code}|{name}'))
        self.spinFor(0.3)
        # Tell the generator which task's report to write (per-task PDF).
        self.report_pub.publish(String(data=code))
        self.spinFor(2.0)
        self.say('The inspection report has been generated.')

    # ── callbacks ─────────────────────────────────────────────────────────────

    def _amcl_cb(self, msg):
        self.initial_pose_received = True
        self.current_pose = msg.pose.pose

    def _feedback_cb(self, msg):
        self.feedback = msg.feedback

    def _dock_cb(self, msg):
        self.is_docked = msg.is_docked

    def _blue_detected_cb(self, msg):  self.blue_detected = msg.data
    def _blue_count_cb(self, msg):     self.blue_count    = msg.data
    def _blue_cx_left_cb(self, msg):   self.blue_cx_left  = msg.data
    def _blue_cx_right_cb(self, msg):  self.blue_cx_right = msg.data
    def _blue_ahead_cb(self, msg):     self.blue_ahead    = msg.data

    def _qr_cb(self, msg):
        payload = msg.data.strip()
        if payload:
            self.latest_qr     = payload
            self.approach_qr   = payload
            self.last_qr_time  = time.time()

    def _task_done_cb(self, task):
        self.task_done[task] = True

    def _detected_cb(self, msg):
        xy = self._to_map_xy(msg)
        if xy is None:
            return
        mx, my = xy

        # While approaching someone, only track sightings of THAT person — ignore
        # any other people that come into view.
        if self.mode == Mode.APPROACH_PERSON:
            if self.approach_target is not None and \
                    math.hypot(mx - self.approach_target[0],
                               my - self.approach_target[1]) <= self.TRACK_DIST:
                self.last_person_xy   = (mx, my)
                self.last_person_time = time.time()
            return

        # While following the blue line, ignore people entirely.
        if self.mode in (Mode.LINE_FOLLOW, Mode.TURNING_AROUND):
            return
        if self.pending_detection is not None:
            return
        if self._is_handled(mx, my):
            return
        self.info(f'[PERSON] Detected at map ({mx:.2f}, {my:.2f}) — will approach.')
        self.last_person_xy    = (mx, my)
        self.pending_detection = (mx, my)

    def _identity_cb(self, msg):
        """Cache an identity announced by detect_people_recognition."""
        parts = msg.data.split('|')
        if len(parts) < 5:
            return
        name, role, gender = parts[0], parts[1], parts[2]
        try:
            mx, my = float(parts[3]), float(parts[4])
        except ValueError:
            return
        self.identities.append((name, role, gender, mx, my))
        self.info(f'[RECOG] Heard identity {name} ({role}, {gender}) '
                  f'at ({mx:.2f}, {my:.2f}).')

    def _recognized_cb(self, msg):
        """Live identity of whoever is currently in view (depth-independent)."""
        parts = msg.data.split('|')
        if len(parts) < 3:
            return
        self.current_person = (parts[0], parts[1], parts[2], time.time())

    def lookupIdentity(self, tx, ty, max_dist):
        """Nearest cached identity to (tx, ty); (name, role, gender) or None."""
        best, best_d = None, max_dist
        for name, role, gender, mx, my in self.identities:
            d = math.hypot(mx - tx, my - ty)
            if d < best_d:
                best, best_d = (name, role, gender), d
        return best

    # ── logging ───────────────────────────────────────────────────────────────

    def info(self, msg):  self.get_logger().info(msg)
    def warn(self, msg):  self.get_logger().warn(msg)
    def error(self, msg): self.get_logger().error(msg)
    def debug(self, msg): self.get_logger().debug(msg)


# ── main ──────────────────────────────────────────────────────────────────────

def main(args=None):
    rclpy.init(args=args)
    rc = RobotCommander()

    rc.waitUntilNav2Active()

    while rc.is_docked is None:
        rclpy.spin_once(rc, timeout_sec=0.5)
    if rc.is_docked:
        rc.undock()

    # Hand camera looks down: enables blue-line detection and general patrol.
    time.sleep(1.0)
    rc.setArm('look_down')
    time.sleep(0.5)
    rc.setArm('look_down')

    waypoints_xy = load_waypoints(WAYPOINTS_FILE)
    if not waypoints_xy:
        rc.error(f'No waypoints found in {WAYPOINTS_FILE}. Aborting.')
        rc.destroyNode()
        rclpy.shutdown()
        return
    rc.info(f'Loaded {len(waypoints_xy)} waypoints from {WAYPOINTS_FILE}.')

    # Face each waypoint toward the next one for smoother motion.
    waypoints = []
    n = len(waypoints_xy)
    for i, (x, y) in enumerate(waypoints_xy):
        nx, ny = waypoints_xy[(i + 1) % n]
        yaw = math.atan2(ny - y, nx - x) if n > 1 else 0.0
        waypoints.append(rc.buildPose(x, y, yaw))

    # ── tuning constants ──────────────────────────────────────────────────────
    LINE_SPEED      = 0.15
    LINE_KP         = 1.5
    TURN_SPEED      = 0.5
    TURN_SETTLE     = 1.0
    MAX_TURN_TIME   = (2 * math.pi / TURN_SPEED) + 1.0
    AT_START_DIST   = 0.6
    DEPARTED_DIST   = 1.2
    ALIGN_KP         = 3.0   # steering gain while aligning onto a sharp branch
    ALIGN_GIVEUP_ANG = math.radians(120)  # rotated this far, still no line ahead → tip
    BRANCH_END_TIME  = 4.0   # s fallback (centred tip barely rotates) → it's a tip
    BRANCH_TURN_ANG  = math.pi        # rad — turn this much (measured by yaw)
    BRANCH_TURN_MAXT = 20.0           # s — hard cap so a frozen pose can't spin forever

    # Person approach: Nav2 to a coarse standoff, then creep in close and head-on.
    NAV_STANDOFF    = 0.7    # m — Nav2 brings us roughly this far from the person
    CREEP_SPEED     = 0.08   # m/s — slow forward creep with cmd_vel
    CREEP_STOP_DIST = 0.50   # m — robot-centre to person; stop creeping here
    CREEP_MAX_TIME  = 5.0    # s — safety cap on the creep phase
    CREEP_KP_ANG    = 1.2    # steering gain to stay pointed at the person
    CREEP_MAX_ANG   = 0.8    # rad/s — angular speed clamp
    ALIGN_ANG       = 0.35   # rad — rotate in place if heading error exceeds this
    CO_VIS_WINDOW   = 0.7    # s — QR and person count as "same frame" if both
                             #     detectors published within this of each other

    # ── state ─────────────────────────────────────────────────────────────────
    wp_index    = 0
    goal_active = False

    # approach
    approach_target = None
    approach_phase  = 'nav'   # 'nav' → 'creep' → 'handle'
    creep_deadline  = 0.0

    # blue line
    return_pose     = None
    departed        = False
    turn_start      = 0.0
    resume_until    = 0.0
    branch_end_t0   = 0.0
    turn_accum      = 0.0     # rad rotated so far in the current committed turn
    turn_prev_yaw   = 0.0
    stagnation_t0   = 0.0
    stagnation_x    = 0.0
    stagnation_y    = 0.0
    stagnation_turn = False

    rc.mode = Mode.WAYPOINTS
    rc.info('Starting waypoint patrol.')

    while rclpy.ok():
        rclpy.spin_once(rc, timeout_sec=0.05)
        now = time.time()

        # Only honour blue-line detection once we have reached the end of the
        # patrol route (the final waypoint that initialises line following). A
        # spilled blue barrel leaves blue marks on the floor earlier in the
        # route; ignoring blue until here keeps those from triggering a false
        # switch to line following.
        blue_listen = wp_index >= len(waypoints) - 1

        # ── WAYPOINTS → LINE_FOLLOW ───────────────────────────────────────────
        if rc.mode == Mode.WAYPOINTS and rc.blue_detected and blue_listen:
            rc.info('[BLUE] Blue line detected — switching to line following.')
            if goal_active:
                rc.cancelTask()
                wait_for_task(rc)
                goal_active = False
            return_pose   = rc.current_pose
            departed      = False
            resume_until  = now + 2.0
            stagnation_t0 = now
            if rc.current_pose:
                stagnation_x = rc.current_pose.position.x
                stagnation_y = rc.current_pose.position.y
            rc.mode = Mode.LINE_FOLLOW
            continue

        # ── WAYPOINTS → APPROACH_PERSON ──────────────────────────────────────
        if rc.mode == Mode.WAYPOINTS and rc.pending_detection is not None:
            approach_target = rc.pending_detection
            rc.approach_target = approach_target   # gate other-person sightings
            rc.pending_detection = None
            rc.approach_qr = None                  # forget any prior person's QR
            px, py = approach_target
            rc.info(f'[PERSON] Approaching ({px:.2f}, {py:.2f}).')
            if goal_active:
                rc.cancelTask()
                wait_for_task(rc)
                goal_active = False
                wp_index = max(wp_index - 1, 0)   # re-send the interrupted waypoint
            approach_phase = 'nav'
            if rc.goToPose(rc.approachPose(px, py, NAV_STANDOFF)):
                rc.mode = Mode.APPROACH_PERSON
            else:
                rc.warn('[PERSON] Approach goal rejected.')
                rc.markPerson(px, py)
                rc.handled_people.append(approach_target)
                approach_target = None
                rc.approach_target = None
            continue

        # ── APPROACH_PERSON ──────────────────────────────────────────────────
        if rc.mode == Mode.APPROACH_PERSON:
            # A blue line takes priority — abandon the person and follow it.
            # Gated the same way (only near the end of the route) so a barrel
            # spill mid-route doesn't abort a person approach.
            if rc.blue_detected and blue_listen:
                rc.info('[BLUE] Blue line during approach — abandoning person.')
                if not rc.isTaskComplete():
                    rc.cancelTask()
                    wait_for_task(rc)
                rc.stopRobot()
                approach_target = None
                rc.approach_target = None
                return_pose   = rc.current_pose
                departed      = False
                resume_until  = now + 2.0
                stagnation_t0 = now
                if rc.current_pose:
                    stagnation_x = rc.current_pose.position.x
                    stagnation_y = rc.current_pose.position.y
                rc.mode = Mode.LINE_FOLLOW
                continue

            # Aim at the freshest sighting if we have one, else the original target.
            tx, ty = rc.last_person_xy if rc.last_person_xy is not None else approach_target

            # Phase 1: Nav2 brings us to the coarse standoff.
            if approach_phase == 'nav':
                if rc.isTaskComplete():
                    rc.info('[PERSON] At standoff — creeping in close and straight.')
                    approach_phase = 'creep'
                    creep_deadline = now + CREEP_MAX_TIME
                continue

            # Phase 2: creep in close, aiming between the face and the wall QR
            # (offset to the robot's left) so both share the camera frame.
            if approach_phase == 'creep':
                if rc.current_pose is None:
                    continue
                fx, fy = rc.framePoint(tx, ty)
                rx = rc.current_pose.position.x
                ry = rc.current_pose.position.y
                ryaw = rc._quat_to_yaw(rc.current_pose.orientation)
                dx, dy = fx - rx, fy - ry
                dist = math.hypot(dx, dy)
                yaw_err = rc._norm_angle(math.atan2(dy, dx) - ryaw)

                # Ideal stop: the QR and the person are visible in the SAME frame
                # right now (both detectors publishing concurrently). That is
                # exactly the view we need to read the task, so stop and handle.
                co_visible = ((now - rc.last_qr_time)     < CO_VIS_WINDOW and
                              (now - rc.last_person_time) < CO_VIS_WINDOW)

                if co_visible:
                    rc.stopRobot()
                    rc.info(f'[PERSON] QR + person co-visible (dist={dist:.2f} m) '
                            '— stopping to read the task.')
                    approach_phase = 'handle'
                elif dist <= CREEP_STOP_DIST or now > creep_deadline:
                    rc.stopRobot()
                    rc.info(f'[PERSON] Reached person (dist={dist:.2f} m) — no '
                            'co-visible QR; handling anyway.')
                    approach_phase = 'handle'
                else:
                    ang = max(-CREEP_MAX_ANG, min(CREEP_MAX_ANG, CREEP_KP_ANG * yaw_err))
                    # Rotate in place if badly off heading, otherwise creep forward.
                    fwd = 0.0 if abs(yaw_err) > ALIGN_ANG else CREEP_SPEED
                    rc.publishVelocity(fwd, ang)
                continue

            # Phase 3: read the QR, run the assigned task, return + report.
            # This is a blocking, self-enclosed sequence.
            if approach_phase == 'handle':
                rc.stopRobot()
                task = rc.handlePersonTask(tx, ty)
                rc.markPerson(tx, ty,
                              name=(rc.lookupIdentity(tx, ty, 1.5) or [None])[0])
                rc.handled_people.append((tx, ty))
                approach_target = None
                rc.approach_target = None

                # Resume the patrol from where it was interrupted (wp_index was
                # rewound to the cancelled waypoint when we left to approach this
                # person). Do NOT jump to the last waypoint — that skipped the
                # whole route. The patrol continues, finds any further people,
                # and reaches the blue line naturally at the final waypoint.
                goal_active = False
                rc.mode = Mode.WAYPOINTS
                continue
            continue

        # ── LINE_FOLLOW ───────────────────────────────────────────────────────
        if rc.mode == Mode.LINE_FOLLOW:
            if not departed and return_pose and rc.current_pose:
                dx = rc.current_pose.position.x - return_pose.position.x
                dy = rc.current_pose.position.y - return_pose.position.y
                if math.sqrt(dx * dx + dy * dy) > DEPARTED_DIST:
                    departed = True

            if departed and return_pose and rc.current_pose:
                dx = rc.current_pose.position.x - return_pose.position.x
                dy = rc.current_pose.position.y - return_pose.position.y
                if math.sqrt(dx * dx + dy * dy) < AT_START_DIST:
                    rc.info('[BLUE] Back at start — resuming waypoints.')
                    rc.stopRobot()
                    rc.mode = Mode.WAYPOINTS
                    continue

            # Line is detected but not continuing ahead. It is either a real dead
            # tip, or a branch that heads off sharply — even a bit backward (which
            # used to be mistaken for a tip). Rotate in place TOWARD the line to
            # try to bring it into the forward view: if a line then appears ahead
            # it was a real branch → keep following; if we rotate a lot (or wait,
            # for a centred tip that barely rotates) with nothing ever ahead, it
            # is a true tip → commit a 180°. A curve always keeps a line ahead, so
            # this never fires on curves.
            if rc.blue_detected and not rc.blue_ahead and now > resume_until:
                yaw_now = (rc._quat_to_yaw(rc.current_pose.orientation)
                           if rc.current_pose else 0.0)
                if branch_end_t0 == 0.0:
                    branch_end_t0 = now
                    turn_accum    = 0.0
                    turn_prev_yaw = yaw_now
                else:
                    turn_accum   += abs(rc._norm_angle(yaw_now - turn_prev_yaw))
                    turn_prev_yaw = yaw_now
                cx  = rc.blue_cx_left if rc.blue_cx_left >= 0.0 else 0.5
                ang = max(-TURN_SPEED, min(TURN_SPEED, ALIGN_KP * (0.5 - cx)))
                rc.publishVelocity(0.0, ang)   # rotate in place toward the line
                if turn_accum > ALIGN_GIVEUP_ANG or \
                        now - branch_end_t0 > BRANCH_END_TIME:
                    rc.info('[BLUE] Branch end — committing to 180° turn.')
                    turn_start      = now
                    stagnation_turn = True
                    branch_end_t0   = 0.0
                    turn_accum      = 0.0
                    turn_prev_yaw   = yaw_now
                    rc.mode = Mode.TURNING_AROUND
                continue
            else:
                branch_end_t0 = 0.0

            if rc.blue_detected:
                cx = rc.blue_cx_left if rc.blue_cx_left >= 0.0 else 0.5
                if rc.blue_count >= 2:
                    rc.info(f'[BLUE] Fork — going left (cx={cx:.2f}).')
                rc.publishVelocity(LINE_SPEED, LINE_KP * (0.5 - cx))
            elif now > resume_until:
                rc.info('[BLUE] Dead end — turning around.')
                rc.stopRobot()
                turn_start      = now
                stagnation_turn = False
                rc.mode = Mode.TURNING_AROUND
            continue

        # ── TURNING_AROUND ────────────────────────────────────────────────────
        if rc.mode == Mode.TURNING_AROUND:
            elapsed = now - turn_start

            if stagnation_turn:
                # Closed-loop on yaw: open-loop timing badly under-rotated because
                # the robot doesn't reach the commanded angular rate. Accumulate
                # the actual rotation from the pose and stop at BRANCH_TURN_ANG,
                # with a hard time cap as a safety net.
                if rc.current_pose is not None:
                    yaw = rc._quat_to_yaw(rc.current_pose.orientation)
                    turn_accum += abs(rc._norm_angle(yaw - turn_prev_yaw))
                    turn_prev_yaw = yaw
                if turn_accum < BRANCH_TURN_ANG and elapsed < BRANCH_TURN_MAXT:
                    rc.publishVelocity(0.0, -TURN_SPEED)
                else:
                    rc.info(f'[BLUE] Turn done ({math.degrees(turn_accum):.0f}°) — '
                            f'resuming line follow.')
                    rc.stopRobot()
                    stagnation_turn = False
                    resume_until = now + 2.0
                    rc.mode = Mode.LINE_FOLLOW
            else:
                if elapsed < TURN_SETTLE:
                    rc.publishVelocity(0.0, -TURN_SPEED)
                elif rc.blue_detected:
                    rc.info('[BLUE] Line found during turn — resuming follow.')
                    rc.stopRobot()
                    resume_until = now + 1.5
                    rc.mode = Mode.LINE_FOLLOW
                elif elapsed < MAX_TURN_TIME:
                    rc.publishVelocity(0.0, -TURN_SPEED)
                else:
                    rc.info('[BLUE] No line after full rotation — resuming waypoints.')
                    rc.stopRobot()
                    rc.mode = Mode.WAYPOINTS
            continue

        # ── WAYPOINTS navigation (single pass, yellow ignored) ────────────────
        if not goal_active:
            if wp_index >= len(waypoints):
                rc.info('[MAIN] All waypoints completed. Mission done.')
                break
            current_wp = waypoints[wp_index]
            rc.info(f'[MAIN] Waypoint {wp_index}: '
                    f'({current_wp.pose.position.x:.2f}, '
                    f'{current_wp.pose.position.y:.2f})')
            if rc.goToPose(current_wp):
                goal_active = True
                wp_index   += 1
            else:
                rc.warn(f'[MAIN] Waypoint {wp_index} rejected, skipping.')
                wp_index += 1
        elif rc.isTaskComplete():
            result = rc.getResult()
            rc.info(f'[MAIN] Waypoint {wp_index - 1} done ({result.name}).')
            goal_active = False
            # Spin a full 360° at the waypoint so the detectors see all around
            # before driving on. Skip the final stretch (blue_listen): that is
            # where blue-line following begins, and a spin there would disorient
            # the robot right at the handoff. Also skip if a person is pending.
            if rc.pending_detection is None and not blue_listen:
                rc.scan360()

    rc.stopRobot()
    rc.destroyNode()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
