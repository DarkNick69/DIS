#!/usr/bin/env python3
"""Manual capture + label tool for barrels (YOLO training data).

Drive the robot, then in the live window press C to capture the current frame.
You are then asked, in the terminal:
    - colour:      black / yellow / blue / green / red
    - orientation: horizontal / vertical
    - leaking:     yes / no

The box is found automatically from the colour you gave (reliable, since the
colour is known); if it looks wrong you can draw it yourself with the mouse.

Saves to ~/barrel_dataset_manual/:
    images/<stem>.jpg     the RGB frame
    labels/<stem>.txt     YOLO label "<cls> cx cy w h"  (cls 0=horizontal, 1=vertical)
    preview/<stem>.jpg    the frame with the box + attributes drawn
    metadata.csv          stem,colour,orientation,leaking,cx,cy,w,h

Then merge + train:
    /opt/ultralytics/bin/python3 scripts/train_barrels_black.py --merge
    /opt/ultralytics/bin/python3 scripts/train_barrels_black.py

    ros2 run dis_tutorial7 capture_barrel.py
"""

import csv
import os
import time

import cv2
import numpy as np

import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data

from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError

OUT = os.path.expanduser('~/barrel_dataset_manual')
WIN = 'Capture barrel  —  [C] capture   [Q] quit'

# HSV colour ranges (OpenCV H 0-179). Red wraps, so two ranges.
COLOR_RANGES = {
    'black':  [((0,   0,   0), (179, 90,  80))],
    'yellow': [((20,  120, 100), (35,  255, 255))],
    'blue':   [((95,  100, 60), (130, 255, 255))],
    'green':  [((40,  100, 60), (85,  255, 255))],
    'red':    [((0,   120, 70), (10,  255, 255)), ((168, 120, 70), (179, 255, 255))],
}
# orientation name -> YOLO class id (matches barrels_dataset/data.yaml)
ORIENT_CLS = {'horizontal': 0, 'vertical': 1}


class BarrelCapture(Node):
    def __init__(self):
        super().__init__('barrel_capture')
        for sub in ('images', 'labels', 'preview'):
            os.makedirs(os.path.join(OUT, sub), exist_ok=True)
        self.meta_path = os.path.join(OUT, 'metadata.csv')
        if not os.path.isfile(self.meta_path):
            with open(self.meta_path, 'w', newline='') as f:
                csv.writer(f).writerow(
                    ['stem', 'colour', 'orientation', 'leaking',
                     'cx', 'cy', 'w', 'h'])

        self.bridge = CvBridge()
        self.latest_rgb = None
        self.saved = 0
        self.create_subscription(Image, '/oakd/rgb/preview/image_raw',
                                 self._rgb_cb, qos_profile_sensor_data)
        self.get_logger().info(f'Ready. Saving to {OUT}. '
                               'Drive, then press C in the window to capture.')

    def _rgb_cb(self, msg):
        try:
            self.latest_rgb = self.bridge.imgmsg_to_cv2(msg, 'bgr8')
        except CvBridgeError as e:
            self.get_logger().error(str(e))

    # ── colour-guided / manual box ────────────────────────────────────────────

    def _auto_box(self, bgr, color):
        """Largest blob of `color` → (x, y, w, h), or None."""
        hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
        mask = np.zeros(hsv.shape[:2], np.uint8)
        for lo, hi in COLOR_RANGES[color]:
            mask |= cv2.inRange(hsv, np.array(lo, np.uint8), np.array(hi, np.uint8))
        k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, k, iterations=2)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, k, iterations=1)
        cnts = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[0]
        if not cnts:
            return None
        c = max(cnts, key=cv2.contourArea)
        if cv2.contourArea(c) < 400:
            return None
        return cv2.boundingRect(c)

    def _draw_box(self, bgr):
        """Let the user drag a box with the mouse. Returns (x,y,w,h) or None."""
        state = {'p0': None, 'p1': None, 'done': False}

        def on_mouse(event, mx, my, flags, _):
            if event == cv2.EVENT_LBUTTONDOWN:
                state['p0'], state['p1'] = (mx, my), (mx, my)
            elif event == cv2.EVENT_MOUSEMOVE and state['p0'] and not state['done']:
                state['p1'] = (mx, my)
            elif event == cv2.EVENT_LBUTTONUP:
                state['p1'], state['done'] = (mx, my), True

        cv2.setMouseCallback(WIN, on_mouse)
        print('  Draw the box with the mouse (drag), then press ENTER. ESC to cancel.')
        while rclpy.ok():
            disp = bgr.copy()
            if state['p0'] and state['p1']:
                cv2.rectangle(disp, state['p0'], state['p1'], (0, 255, 255), 2)
            cv2.imshow(WIN, disp)
            key = cv2.waitKey(20) & 0xFF
            if key in (13, 10):                      # ENTER
                break
            if key == 27:                            # ESC
                return None
        if not state['p0'] or not state['p1']:
            return None
        (x0, y0), (x1, y1) = state['p0'], state['p1']
        x, y = min(x0, x1), min(y0, y1)
        w, h = abs(x1 - x0), abs(y1 - y0)
        return (x, y, w, h) if w > 5 and h > 5 else None

    # ── one capture/label cycle ────────────────────────────────────────────────

    def capture(self, frame):
        ih, iw = frame.shape[:2]

        color = ask('Colour', list(COLOR_RANGES.keys()))
        if color is None:
            print('  cancelled.')
            return

        box = self._auto_box(frame, color)
        if box:
            x, y, w, h = box
            prev = frame.copy()
            cv2.rectangle(prev, (x, y), (x + w, y + h), (0, 255, 255), 2)
            cv2.imshow(WIN, prev)
            cv2.waitKey(1)
            print(f'  auto box from {color}: ({x},{y},{w},{h}).')
            if not yes_no('  Accept this box', default=True):
                box = self._draw_box(frame)
        else:
            print(f'  no {color} blob found — draw the box.')
            box = self._draw_box(frame)
        if not box:
            print('  no box — skipped.')
            return
        x, y, w, h = box

        suggest = 'horizontal' if w >= h else 'vertical'
        orient = ask(f'Orientation (suggest: {suggest})',
                     list(ORIENT_CLS.keys()), default=suggest)
        if orient is None:
            print('  cancelled.')
            return
        leaking = yes_no('Leaking', default=False)

        stem = f'barrel_{time.strftime("%Y%m%d_%H%M%S")}_{self.saved:03d}'
        cv2.imwrite(os.path.join(OUT, 'images', stem + '.jpg'), frame)
        cls = ORIENT_CLS[orient]
        cx, cy = (x + w / 2) / iw, (y + h / 2) / ih
        nw, nh = w / iw, h / ih
        with open(os.path.join(OUT, 'labels', stem + '.txt'), 'w') as f:
            f.write(f'{cls} {cx:.6f} {cy:.6f} {nw:.6f} {nh:.6f}\n')

        col = (0, 0, 255) if leaking else (0, 200, 0) if orient == 'vertical' else (0, 140, 255)
        prev = frame.copy()
        cv2.rectangle(prev, (x, y), (x + w, y + h), col, 2)
        cv2.putText(prev, f'{color} {orient}' + (' LEAK' if leaking else ''),
                    (x, max(y - 6, 12)), cv2.FONT_HERSHEY_SIMPLEX, 0.5, col, 1)
        cv2.imwrite(os.path.join(OUT, 'preview', stem + '.jpg'), prev)

        with open(self.meta_path, 'a', newline='') as f:
            csv.writer(f).writerow([stem, color, orient, int(leaking),
                                    f'{cx:.4f}', f'{cy:.4f}', f'{nw:.4f}', f'{nh:.4f}'])
        self.saved += 1
        print(f'  saved {stem}  ({color}, {orient}, leak={leaking}). '
              f'Total this session: {self.saved}.\n')


def ask(prompt, options, default=None):
    """Prompt until the answer matches an option (exact or unique prefix)."""
    hint = '/'.join(options) + (f'  [{default}]' if default else '')
    while True:
        try:
            raw = input(f'{prompt} ({hint}): ').strip().lower()
        except EOFError:
            return None
        if not raw and default:
            return default
        if raw in ('q', 'cancel'):
            return None
        if raw in options:
            return raw
        matches = [o for o in options if o.startswith(raw)]
        if len(matches) == 1:
            return matches[0]
        print('   ? type one of: ' + ', '.join(options) + " (or 'q' to cancel)")


def yes_no(prompt, default=False):
    d = 'Y/n' if default else 'y/N'
    while True:
        try:
            raw = input(f'{prompt}? ({d}): ').strip().lower()
        except EOFError:
            return default
        if not raw:
            return default
        if raw in ('y', 'yes'):
            return True
        if raw in ('n', 'no'):
            return False


def main():
    rclpy.init()
    node = BarrelCapture()
    cv2.namedWindow(WIN, cv2.WINDOW_NORMAL)
    try:
        while rclpy.ok():
            rclpy.spin_once(node, timeout_sec=0.05)
            if node.latest_rgb is None:
                continue
            disp = node.latest_rgb.copy()
            cv2.putText(disp, '[C] capture   [Q] quit', (8, 20),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
            cv2.imshow(WIN, disp)
            key = cv2.waitKey(30) & 0xFF
            if key in (ord('q'), 27):
                break
            if key in (ord('c'), 32):       # C or SPACE
                node.capture(node.latest_rgb.copy())
    except (KeyboardInterrupt, SystemExit):
        pass
    finally:
        cv2.destroyAllWindows()
        node.get_logger().info(f'Done. Saved {node.saved} samples to {OUT}.')
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
