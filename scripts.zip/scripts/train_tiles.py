#!/usr/bin/env python3
"""Train YOLOv8n to DETECT tiles (single class) on the composited tile dataset.

Build the dataset first:
    /opt/ultralytics/bin/python3 scripts/build_tiles_dataset.py

Then train:
    /opt/ultralytics/bin/python3 scripts/train_tiles.py

Output weights: runs/detect/tiles/weights/best.pt
"""

import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pkg_paths import PKG_ROOT

from ultralytics import YOLO

DATA = os.path.join(PKG_ROOT, 'tiles_dataset_aug', 'data.yaml')
OUT  = os.path.join(PKG_ROOT, 'runs', 'detect')

model = YOLO('yolov8n.pt')
results = model.train(
    data=DATA,
    epochs=60,
    imgsz=640,
    batch=16,
    project=OUT,
    name='tiles',
    exist_ok=True,
    verbose=True,
)

print(f'\nDone — weights: {OUT}/tiles/weights/best.pt')
