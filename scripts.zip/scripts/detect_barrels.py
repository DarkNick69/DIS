#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from rclpy.qos import (qos_profile_sensor_data, QoSProfile, QoSDurabilityPolicy,
                       QoSReliabilityPolicy, QoSHistoryPolicy)
from rclpy.duration import Duration as rclpyDuration
from rclpy.time import Time as rclpyTime

import cv2
import numpy as np
import math
import os
import tf2_ros
from collections import Counter

from sensor_msgs.msg import Image, PointCloud2
from sensor_msgs_py import point_cloud2 as pc2
from geometry_msgs.msg import PointStamped
from visualization_msgs.msg import Marker, MarkerArray
from std_msgs.msg import ColorRGBA, String
from cv_bridge import CvBridge, CvBridgeError

# ---------------------------------------------------------------------------
# YOLOv8 model path — updated to best.pt after training completes
# ---------------------------------------------------------------------------
from pkg_paths import p
YOLO_WEIGHTS = p('barrels_dataset/barrel_run_black/weights/best.pt')
IMAGES_DIR   = p('inspection_images')
YOLO_CONF    = 0.30   # lowered from 0.55 to catch yellow + black barrels
YOLO_CLASSES = {0: 'barrel_horizontal', 1: 'barrel_vertical'}

# ---------------------------------------------------------------------------
# HSV colour ranges  (OpenCV: H 0-179, S/V 0-255)
# ---------------------------------------------------------------------------
BARREL_COLORS = {
    'red':    [(np.array([0,   120,  70], np.uint8), np.array([10,  255, 255], np.uint8)),
               (np.array([168, 120,  70], np.uint8), np.array([179, 255, 255], np.uint8))],
    'green':  [(np.array([40,  100,  60], np.uint8), np.array([85,  255, 255], np.uint8))],
    'blue':   [(np.array([95,  100,  60], np.uint8), np.array([130, 255, 255], np.uint8))],
    'yellow': [(np.array([20,  120, 100], np.uint8), np.array([35,  255, 255], np.uint8))],
    'orange': [(np.array([10,  130, 100], np.uint8), np.array([20,  255, 255], np.uint8))],
    'purple': [(np.array([130,  70,  50], np.uint8), np.array([160, 255, 255], np.uint8))],
    'brown':  [(np.array([5,    70,  30], np.uint8), np.array([22,  220, 160], np.uint8))],
    'black':  [(np.array([0,     0,   0], np.uint8), np.array([179,  60,  60], np.uint8))],
}

COLOR_RGBA = {
    'red':    ColorRGBA(r=1.0,  g=0.0,  b=0.0,  a=0.9),
    'green':  ColorRGBA(r=0.0,  g=0.9,  b=0.0,  a=0.9),
    'blue':   ColorRGBA(r=0.0,  g=0.0,  b=1.0,  a=0.9),
    'yellow': ColorRGBA(r=1.0,  g=1.0,  b=0.0,  a=0.9),
    'orange': ColorRGBA(r=1.0,  g=0.5,  b=0.0,  a=0.9),
    'purple': ColorRGBA(r=0.5,  g=0.0,  b=0.8,  a=0.9),
    'brown':  ColorRGBA(r=0.5,  g=0.25, b=0.0,  a=0.9),
    'black':  ColorRGBA(r=0.05, g=0.05, b=0.05, a=0.9),
}

# ---------------------------------------------------------------------------
# Thresholds
# ---------------------------------------------------------------------------
MIN_BARREL_AREA = 1800   # px²
MIN_BARREL_DIM  = 40     # px  — both width AND height
MIN_SOLIDITY    = 0.35   # area / bbox_area
HORIZ_RATIO     = 1.20   # width/height >  → horizontal
HORIZ_MAX       = 4.0    # width/height <  (floor lines are >> 4)
VERT_RATIO      = 0.83   # width/height <  → vertical
PROTRUSION_M    = 0.04   # m — min depth difference vs left/right background
MIN_BARREL_Z    = 0.12   # m — barrels are always above this height in map frame
DEDUP_DIST      = 0.40   # m — map-frame dedup radius. Below a barrel diameter
                         # (~0.45 m) so two adjacent barrels stay distinct, but
                         # large enough to absorb position jitter on re-sighting.
CONFIRM_FRAMES   = 3     # sightings required before a barrel is published
CANDIDATE_MAX_AGE = 45   # frames an unconfirmed candidate survives without a hit
# Detection is always on (also while the robot drives between waypoints), so a
# barrel is seen from many distances. Far sightings have large depth-projection
# error: the same barrel then lands >DEDUP_DIST away and is published twice.
# Only let close, reliable sightings anchor a candidate's map position.
MAX_DETECT_RANGE_M = 2.5  # m — reject sightings farther than this from the camera

# Real-world size gate (from the depth pointcloud) — rejects small non-barrel
# objects such as QR codes and most rings, which are far smaller than a barrel.
MIN_BARREL_3D_M = 0.28   # m — the larger of (3D width, 3D height) must exceed this
MIN_BARREL_2ND_M = 0.16  # m — the 2nd-largest 3D extent (so it is a volume, not a flat disc/sheet)

# Leak (spill pool) detection below a barrel — the spill is matched against the
# barrel's OWN colour (see _check_leak), so this is just the area threshold.
MIN_SPILL_RATIO = 0.06   # fraction of below-barrel ROI that must be spill


class BarrelDetector(Node):
    def __init__(self):
        super().__init__('barrel_detector')

        self.bridge       = CvBridge()
        self.latest_rgb   = None
        self.latest_depth = None
        self.latest_pc    = None

        self.tf_buffer   = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)

        # Barrel candidates: accumulate sightings, vote on colour/orientation,
        # take the median position, and only publish once confirmed. Mirrors the
        # ring detector — robust against split detections, jitter and one-frame
        # misclassifications (e.g. a horizontal barrel briefly seen as vertical).
        self.candidates      = []
        self.frame_counter   = 0
        self.published_count = 0

        # --- YOLO model (optional — graceful fallback to HSV-only if absent) ---
        self.yolo = None
        weights = os.path.realpath(YOLO_WEIGHTS)
        if os.path.isfile(weights):
            try:
                from ultralytics import YOLO
                self.yolo = YOLO(weights)
                self.get_logger().info(f'YOLO model loaded: {weights}')
            except Exception as e:
                self.get_logger().warn(f'YOLO load failed ({e}), using HSV-only mode.')
        else:
            self.get_logger().warn(
                f'YOLO weights not found at {weights} — using HSV-only mode. '
                'Run training first.')

        self.rgb_sub = self.create_subscription(
            Image, '/oakd/rgb/preview/image_raw',
            self.rgb_callback, qos_profile_sensor_data)
        self.depth_sub = self.create_subscription(
            Image, '/oakd/rgb/preview/depth',
            self.depth_callback, qos_profile_sensor_data)
        self.pc_sub = self.create_subscription(
            PointCloud2, '/oakd/rgb/preview/depth/points',
            self.pc_callback, qos_profile_sensor_data)

        # Transient-local so every detected barrel persists in RViz (and is seen
        # by displays that connect later). We publish the FULL set each time a
        # new barrel is found, with lifetime 0, so markers never expire.
        marker_qos = QoSProfile(
            durability=QoSDurabilityPolicy.TRANSIENT_LOCAL,
            reliability=QoSReliabilityPolicy.RELIABLE,
            history=QoSHistoryPolicy.KEEP_LAST,
            depth=1)
        self.marker_pub    = self.create_publisher(MarkerArray, '/barrel_markers', marker_qos)
        self.detection_pub = self.create_publisher(String, '/barrel_detections', 10)
        self.say_pub       = self.create_publisher(String, '/robot_say', 10)

        cv2.namedWindow('Barrel Detection', cv2.WINDOW_NORMAL)
        self.get_logger().info('BarrelDetector ready.')

    # ------------------------------------------------------------------
    # Callbacks
    # ------------------------------------------------------------------

    def rgb_callback(self, msg):
        try:
            self.latest_rgb = self.bridge.imgmsg_to_cv2(msg, 'bgr8')
        except CvBridgeError as e:
            self.get_logger().error(str(e))

    def depth_callback(self, msg):
        try:
            d = self.bridge.imgmsg_to_cv2(msg, '32FC1')
            d[~np.isfinite(d)] = 0.0
            self.latest_depth = d
        except CvBridgeError as e:
            self.get_logger().error(str(e))

    def pc_callback(self, msg):
        self.latest_pc = msg
        if self.latest_rgb is not None:
            self.process_frame()

    # ------------------------------------------------------------------
    # Main pipeline
    # ------------------------------------------------------------------

    def process_frame(self):
        rgb    = self.latest_rgb.copy()
        depth  = self.latest_depth
        pc_msg = self.latest_pc
        h, w   = rgb.shape[:2]
        hsv    = cv2.cvtColor(rgb, cv2.COLOR_BGR2HSV)

        pts = None
        if pc_msg.height > 0 and pc_msg.width > 0:
            pts = pc2.read_points_numpy(pc_msg, field_names=('x', 'y', 'z'))
            pts = pts.reshape((pc_msg.height, pc_msg.width, 3))

        display          = rgb.copy()
        frame_detections = []

        # The trained YOLO model is the reliable barrel detector. The HSV-colour
        # and depth-foreground passes catch any coloured/foreground blob and were
        # the source of false positives (rings, QR codes), so they are used ONLY
        # as a fallback when the model is unavailable.
        if self.yolo is not None:
            candidates = self._yolo_candidates(rgb, hsv, depth, h, w)
        else:
            hsv_candidates = self._color_candidates(hsv, depth, h, w)
            depth_candidates = []
            if depth is not None:
                for dc in self._depth_candidates(depth, hsv, h, w):
                    if not self._overlaps_any(dc, hsv_candidates):
                        depth_candidates.append(dc)
            candidates = list(hsv_candidates)
            for c in depth_candidates:
                if not self._overlaps_any(c, candidates):
                    candidates.append(c)

        screen_detections = []  # mirrors exactly what is drawn on the window

        for (x, y, bw, bh, color_name, cnt, orient_hint) in candidates:
            # Orientation from the bounding-box aspect ratio — geometry is more
            # reliable than the 2-class model head. A barrel silhouette is ~1.5:1:
            # wider-than-tall lying down (horizontal), taller-than-wide standing
            # up (vertical).
            orientation = self._classify_orientation(cnt, bw, bh)
            if orientation == 'unknown':
                cv2.rectangle(display, (x, y), (x+bw, y+bh), (80, 80, 80), 1)
                cv2.putText(display, f'{color_name}?', (x, max(y-5, 10)),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.4, (80, 80, 80), 1)
                screen_detections.append(f'{color_name} unknown')
                continue

            # Real-world size gate: reject objects far smaller than a barrel
            # (QR codes, small/flat rings).
            if not self._size_ok(x, y, bw, bh, pts, pc_msg.height, pc_msg.width, w, h):
                continue

            pos3d, in_map = self._center_to_map(x, y, bw, bh, pts,
                                                pc_msg.height, pc_msg.width,
                                                w, h, pc_msg.header)

            if in_map and pos3d[2] < MIN_BARREL_Z:
                self.get_logger().debug(
                    f'[FLOOR] rejected {color_name} at Z={pos3d[2]:.2f}m')
                continue

            # Check for a spill of the barrel's own colour on the floor below it.
            # Run it on any wide-enough box (a horizontal barrel can look square
            # up close), not only ones already classified horizontal — the
            # candidate vote decides the final orientation.
            leaking = (bw >= bh and
                       self._check_leak(hsv, x, y, bw, bh, h, w, color_name))

            frame_detections.append({
                'color': color_name, 'orientation': orientation,
                'pos3d': pos3d, 'leaking': leaking,
                'crop': rgb[y:y + bh, x:x + bw].copy(),
            })

            box_col = (0, 0, 255) if leaking else \
                      (0, 200, 0) if orientation == 'vertical' else (0, 140, 255)
            label = f'{color_name} {orientation}' + (' LEAKING' if leaking else '')
            cv2.rectangle(display, (x, y), (x+bw, y+bh), box_col, 2)
            cv2.putText(display, label, (x, max(y-6, 10)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, box_col, 1, cv2.LINE_AA)
            screen_detections.append(label)

        self._update_and_publish(frame_detections, pc_msg.header.stamp)
        cv2.imshow('Barrel Detection', display)
        cv2.waitKey(1)

        for label in screen_detections:
            print(f'[SCREEN] {label} detected')

    # ------------------------------------------------------------------
    # Pass 0 – YOLO-based
    # ------------------------------------------------------------------

    def _yolo_candidates(self, rgb, hsv, depth, h, w):
        results_yolo = self.yolo.predict(rgb, conf=YOLO_CONF, verbose=False)
        candidates   = []
        for r in results_yolo:
            for box in r.boxes:
                cls_id = int(box.cls[0])
                x1, y1, x2, y2 = map(int, box.xyxy[0])
                bw = x2 - x1
                bh = y2 - y1
                if bw < MIN_BARREL_DIM or bh < MIN_BARREL_DIM:
                    continue
                if not self._is_protruding(depth, x1, y1, bw, bh, h, w):
                    continue

                # Derive class-encoded orientation from YOLO class, then
                # use a synthetic contour for downstream orientation logic.
                cnt = np.array([[x1, y1], [x2, y1], [x2, y2], [x1, y2]],
                               dtype=np.int32).reshape(-1, 1, 2)
                color_name = self._classify_blob_color(hsv, cnt)
                if color_name is None:
                    # Fall back: horizontal barrel → orange, vertical → green
                    color_name = 'orange' if cls_id == 0 else 'green'

                # Trust the YOLO class for orientation (0=horizontal, 1=vertical)
                orient = 'horizontal' if cls_id == 0 else 'vertical'
                candidates.append((x1, y1, bw, bh, color_name, cnt, orient))
        return candidates

    # ------------------------------------------------------------------
    # Pass 1 – colour-based
    # ------------------------------------------------------------------

    def _color_candidates(self, hsv, depth, h, w):
        results = []
        for color_name, ranges in BARREL_COLORS.items():
            mask = np.zeros((h, w), dtype=np.uint8)
            for lo, hi in ranges:
                mask |= cv2.inRange(hsv, lo, hi)

            k    = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
            mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, k, iterations=2)
            mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN,  k, iterations=1)

            for cnt in cv2.findContours(mask, cv2.RETR_EXTERNAL,
                                        cv2.CHAIN_APPROX_SIMPLE)[0]:
                x, y, bw, bh = cv2.boundingRect(cnt)
                if not self._passes_shape(cnt, bw, bh):
                    continue
                if not self._is_protruding(depth, x, y, bw, bh, h, w):
                    continue
                results.append((x, y, bw, bh, color_name, cnt, None))
        return results

    # ------------------------------------------------------------------
    # Pass 2 – depth foreground (dark barrels)
    # ------------------------------------------------------------------

    def _depth_candidates(self, depth, hsv, img_h, img_w):
        """
        Build a foreground mask by comparing each pixel's depth to the
        local background estimated with a large dilation (= local max depth).
        Dark barrels that escape the colour pass are caught here.
        The height check in process_frame filters any remaining floor objects.
        """
        dh, dw = depth.shape
        valid = depth[(depth > 0.05) & np.isfinite(depth)]
        if len(valid) == 0:
            return []
        scene_max = float(np.percentile(valid, 97))
        if scene_max < 0.1:
            return []

        d_filled = depth.copy()
        d_filled[~((depth > 0.05) & np.isfinite(depth))] = scene_max
        d_u8  = np.clip(d_filled / scene_max * 255, 0, 255).astype(np.uint8)
        bg_u8 = cv2.dilate(d_u8, np.ones((71, 71), np.uint8))

        diff = bg_u8.astype(np.int16) - d_u8.astype(np.int16)
        fg   = (diff > 30).astype(np.uint8) * 255

        k  = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
        fg = cv2.morphologyEx(fg, cv2.MORPH_CLOSE, k, iterations=2)
        fg = cv2.morphologyEx(fg, cv2.MORPH_OPEN,  k, iterations=1)

        if dh != img_h or dw != img_w:
            fg = cv2.resize(fg, (img_w, img_h), interpolation=cv2.INTER_NEAREST)

        results = []
        for cnt in cv2.findContours(fg, cv2.RETR_EXTERNAL,
                                    cv2.CHAIN_APPROX_SIMPLE)[0]:
            x, y, bw, bh = cv2.boundingRect(cnt)
            if not self._passes_shape(cnt, bw, bh):
                continue
            color_name = self._classify_blob_color(hsv, cnt)
            if color_name is None:
                continue
            results.append((x, y, bw, bh, color_name, cnt, None))
        return results

    # ------------------------------------------------------------------
    # Shape / colour helpers
    # ------------------------------------------------------------------

    def _passes_shape(self, cnt, bw, bh):
        area = cv2.contourArea(cnt)
        if area < MIN_BARREL_AREA:
            return False
        if bw < MIN_BARREL_DIM or bh < MIN_BARREL_DIM:
            return False
        solidity = area / (bw * bh) if bw * bh > 0 else 0
        return solidity >= MIN_SOLIDITY

    def _classify_orientation(self, cnt, bw, bh):
        """Orientation purely from the bounding-box aspect ratio (width/height).

        A barrel is ~1.5:1, so wider-than-tall → horizontal, taller-than-wide →
        vertical. Only near-square boxes use the ellipse tiebreaker, and even
        then the ratio sign decides — never returns 'unknown' for a real barrel
        (only very long floor lines, ratio > HORIZ_MAX, are rejected).
        """
        ratio = bw / bh if bh > 0 else 1.0
        if ratio >= HORIZ_MAX:
            return 'unknown'                       # floor line, not a barrel
        if ratio >= HORIZ_RATIO:
            return 'horizontal'
        if ratio <= VERT_RATIO:
            return 'vertical'
        # Near-square: prefer the fitted-ellipse major axis, else the ratio sign.
        if len(cnt) >= 5:
            try:
                (_, _), (ma, mb), angle = cv2.fitEllipse(cnt)
                if min(ma, mb) > 0 and max(ma, mb) / min(ma, mb) > 1.12:
                    return 'horizontal' if 55 <= angle <= 125 else 'vertical'
            except cv2.error:
                pass
        return 'horizontal' if ratio >= 1.0 else 'vertical'

    def _size_ok(self, x, y, bw, bh, pts, pc_h, pc_w, img_w, img_h):
        """True if the candidate's real-world extent is barrel-sized.

        Estimates the 3D bounding extents from the depth pointcloud inside the
        box. Rejects small objects (QR codes) and thin/flat ones (most rings),
        which are far smaller than a barrel in at least one dimension.
        """
        if pts is None:
            return True   # no depth → don't block (height check still applies)
        px0 = max(0, int(x * pc_w / img_w));        px1 = min(pc_w, int((x + bw) * pc_w / img_w))
        py0 = max(0, int(y * pc_h / img_h));        py1 = min(pc_h, int((y + bh) * pc_h / img_h))
        if px1 - px0 < 2 or py1 - py0 < 2:
            return True
        region = pts[py0:py1, px0:px1, :].reshape(-1, 3)
        valid = region[np.isfinite(region).all(axis=1) &
                       (np.abs(region).sum(axis=1) > 1e-6)]
        if len(valid) < 20:
            return True   # not enough depth to judge → defer to other checks
        lo = np.percentile(valid, 5, axis=0)
        hi = np.percentile(valid, 95, axis=0)
        ext = np.sort(hi - lo)[::-1]   # 3D extents, largest first (metres)
        if ext[0] < MIN_BARREL_3D_M or ext[1] < MIN_BARREL_2ND_M:
            self.get_logger().debug(
                f'[SIZE REJECT] extents={ext.round(2).tolist()} m')
            return False
        return True

    def _classify_blob_color(self, hsv, cnt):
        """Dominant barrel colour inside a contour (for depth-pass blobs)."""
        mask = np.zeros(hsv.shape[:2], dtype=np.uint8)
        cv2.drawContours(mask, [cnt], -1, 255, -1)
        n = int(np.sum(mask > 0))
        if n == 0:
            return None
        best_name, best_ratio = None, 0.20
        for cname, ranges in BARREL_COLORS.items():
            cm = np.zeros(hsv.shape[:2], dtype=np.uint8)
            for lo, hi in ranges:
                cm |= cv2.inRange(hsv, lo, hi)
            r = int(np.sum((mask > 0) & (cm > 0))) / n
            if r > best_ratio:
                best_ratio, best_name = r, cname
        if best_name is None:
            pixels = hsv[mask > 0]
            if len(pixels) > 0 and float(np.mean(pixels[:, 2])) < 70:
                best_name = 'black'
        return best_name

    def _check_leak(self, hsv, x, y, bw, bh, img_h, img_w, color_name):
        """Spill pool of the barrel's OWN colour on the floor below it.

        A leaking barrel's spill is the same colour as the barrel (e.g. a blue
        barrel leaves a blue mark), so we look for that colour — not a fixed
        green — in the strip directly below the box."""
        ranges = BARREL_COLORS.get(color_name)
        if not ranges:
            return False
        r0 = min(img_h, y + bh)
        r1 = min(img_h, y + bh + max(12, int(bh * 0.6)))
        c0 = max(0, x - int(bw * 0.25))
        c1 = min(img_w, x + bw + int(bw * 0.25))
        if r1 - r0 < 4 or c1 - c0 < 4:
            return False
        roi = hsv[r0:r1, c0:c1]
        mask = np.zeros(roi.shape[:2], dtype=np.uint8)
        for lo, hi in ranges:
            mask |= cv2.inRange(roi, lo, hi)
        ratio = float(np.count_nonzero(mask)) / float(mask.size)
        return ratio >= MIN_SPILL_RATIO

    def _overlaps_any(self, cand, existing):
        x1, y1, w1, h1 = cand[0], cand[1], cand[2], cand[3]
        for (x2, y2, w2, h2, *_) in existing:
            ox = max(0, min(x1+w1, x2+w2) - max(x1, x2))
            oy = max(0, min(y1+h1, y2+h2) - max(y1, y2))
            if ox * oy > 0.3 * min(w1*h1, w2*h2):
                return True
        return False

    # ------------------------------------------------------------------
    # Protrusion check — LEFT + RIGHT strips only
    # ------------------------------------------------------------------

    def _is_protruding(self, depth, x, y, bw, bh, img_h, img_w):
        """
        Samples depth to the LEFT and RIGHT of the bounding box only.

        Floor lines run left-right → their left/right neighbours are also
        floor at the same depth → difference ≈ 0 → rejected.

        Sampling ABOVE would reach the wall (much farther) and produce a
        false protrusion reading for anything near a corner.

        A real 3D barrel has open space / scene background to its sides
        which is farther away → difference > PROTRUSION_M → accepted.
        """
        if depth is None:
            return True

        dh, dw = depth.shape
        sx = dw / img_w
        sy = dh / img_h
        dx0 = max(0, int(x * sx));       dy0 = max(0, int(y * sy))
        dx1 = min(dw, int((x+bw) * sx)); dy1 = min(dh, int((y+bh) * sy))
        cx  = (dx0 + dx1) // 2;          cy  = (dy0 + dy1) // 2

        # Centre depth
        m   = 5
        roi = depth[max(0, cy-m):min(dh, cy+m+1),
                    max(0, cx-m):min(dw, cx+m+1)]
        vc  = roi[(roi > 0.05) & np.isfinite(roi)]
        if len(vc) == 0:
            return True
        centre_d = float(np.median(vc))

        pad   = max(int((dx1 - dx0) * 0.5), 15)
        left  = depth[dy0:dy1, max(0, dx0 - pad):dx0]
        right = depth[dy0:dy1, dx1:min(dw, dx1 + pad)]
        bg    = np.concatenate([left.ravel(), right.ravel()])
        vbg   = bg[(bg > 0.05) & np.isfinite(bg)]
        if len(vbg) < 6:
            return True

        bg_d = float(np.median(vbg))
        ok   = (bg_d - centre_d) > PROTRUSION_M
        if not ok:
            self.get_logger().debug(
                f'[PROTRUSION REJECT] centre={centre_d:.2f} bg={bg_d:.2f}')
        return ok

    # ------------------------------------------------------------------
    # 3-D projection — returns (pos, in_map_frame)
    # ------------------------------------------------------------------

    def _center_to_map(self, x, y, bw, bh, pts, pc_h, pc_w, img_w, img_h, header):
        """3-D position from the BOX CENTRE — stable for both orientations.

        Samples a small window around the box centre (the barrel's middle)
        rather than the whole box, so the estimate does NOT wander along the
        length of a long horizontal barrel (which split one barrel into several
        before). Expands the window modestly only if the centre lacks depth.
        Returns ((x, y, z), in_map) or (None, False)."""
        if pts is None:
            return None, False
        cx = x + bw / 2.0
        cy = y + bh / 2.0
        pcx = int(round(cx * pc_w / img_w))
        pcy = int(round(cy * pc_h / img_h))

        med = None
        for frac in (0.12, 0.22, 0.35):     # window = fraction of the box, centred
            hw = max(2, int(bw * frac * 0.5 * pc_w / img_w))
            hh = max(2, int(bh * frac * 0.5 * pc_h / img_h))
            region = pts[max(0, pcy-hh):min(pc_h, pcy+hh+1),
                         max(0, pcx-hw):min(pc_w, pcx+hw+1), :].reshape(-1, 3)
            valid = region[np.isfinite(region).all(axis=1) &
                           (np.abs(region).sum(axis=1) > 1e-6)]
            if len(valid) >= 8:
                med = np.median(valid, axis=0)
                break
        if med is None:
            return None, False

        # Range gate: drop far sightings whose depth projection is unreliable, so
        # they cannot anchor a candidate at a drifted position (which would later
        # publish as a duplicate of the same barrel seen up close).
        if float(np.linalg.norm(med)) > MAX_DETECT_RANGE_M:
            return None, False

        pt              = PointStamped()
        pt.header       = header
        pt.header.stamp = rclpyTime().to_msg()
        pt.point.x      = float(med[0])
        pt.point.y      = float(med[1])
        pt.point.z      = float(med[2])
        try:
            pm = self.tf_buffer.transform(pt, 'map', timeout=rclpyDuration(seconds=0.3))
            return (pm.point.x, pm.point.y, pm.point.z), True
        except Exception:
            return (float(med[0]), float(med[1]), float(med[2])), False

    # ------------------------------------------------------------------
    # Dedup + RViz
    # ------------------------------------------------------------------

    def _update_and_publish(self, frame_dets, stamp):
        self.frame_counter += 1
        new_publish = False

        for det in frame_dets:
            pos = det['pos3d']
            if pos is None:
                continue

            # Match to the nearest candidate (published or pending) in range.
            nearest, ndist = None, DEDUP_DIST
            for c in self.candidates:
                d = math.hypot(pos[0]-c['pos'][0], pos[1]-c['pos'][1])
                if d < ndist:
                    nearest, ndist = c, d

            if nearest is None:
                nearest = {
                    'samples': [], 'pos': pos,
                    'orient': Counter(), 'colors': Counter(),
                    'leaking': False, 'crop': None, 'crop_area': 0,
                    'count': 0, 'last_frame': 0, 'published': False,
                    'color': det['color'], 'orientation': det['orientation'],
                    'image': None,
                }
                self.candidates.append(nearest)

            # Accumulate the sighting. The stored position is the MEDIAN of all
            # sightings (robust to outlier frames — no drift), orientation and
            # colour are decided by majority vote, and leaking is sticky.
            nearest['samples'].append(pos)
            if len(nearest['samples']) > 40:
                nearest['samples'].pop(0)
            med = np.median(np.array(nearest['samples']), axis=0)
            nearest['pos'] = (float(med[0]), float(med[1]), float(med[2]))
            nearest['orient'][det['orientation']] += 1
            nearest['colors'][det['color']] += 1
            if det['leaking']:
                nearest['leaking'] = True
            crop = det.get('crop')
            if crop is not None and crop.size > nearest['crop_area']:
                nearest['crop'], nearest['crop_area'] = crop, crop.size
            nearest['count'] += 1
            nearest['last_frame'] = self.frame_counter

        # Publish candidates that have been confirmed by enough sightings.
        for c in self.candidates:
            if not c['published'] and c['count'] >= CONFIRM_FRAMES:
                self._publish_candidate(c)
                new_publish = True

        # Drop pending candidates that haven't been seen recently (noise).
        self.candidates = [c for c in self.candidates if c['published'] or
                           (self.frame_counter - c['last_frame']) <= CANDIDATE_MAX_AGE]

        # Republish the full (persistent) marker set whenever something is added.
        if new_publish:
            self._publish_all_markers(stamp)

    def _publish_candidate(self, c):
        """Confirm a candidate: decide colour/orientation by vote, save its
        crop, log + publish the detection, and warn on a leak."""
        color  = c['colors'].most_common(1)[0][0]
        orient = c['orient'].most_common(1)[0][0]
        # A leak means the barrel is lying down → it must be horizontal.
        if c['leaking']:
            orient = 'horizontal'
        c['color'], c['orientation'], c['published'] = color, orient, True

        self.published_count += 1
        img_path = None
        if c['crop'] is not None and c['crop'].size:
            os.makedirs(IMAGES_DIR, exist_ok=True)
            img_path = os.path.join(IMAGES_DIR, f'barrel_{self.published_count}.png')
            cv2.imwrite(img_path, c['crop'])
        c['image'] = img_path

        pos = c['pos']
        msg = (f"[BARREL] color={color}  orientation={orient}  "
               f"leaking={c['leaking']}  "
               f"pos=({pos[0]:.2f},{pos[1]:.2f},{pos[2]:.2f})"
               + (f"  image={img_path}" if img_path else ""))
        self.get_logger().info(msg)
        self.detection_pub.publish(String(data=msg))
        if c['leaking']:
            self.say_pub.publish(String(
                data=f"Alert! Alert! The {color} barrel is leaking!"))

    def _publish_all_markers(self, stamp):
        markers = MarkerArray()
        i = -1
        for k in self.candidates:
            if not k['published']:
                continue
            i += 1
            pos = k['pos']
            m                    = Marker()
            m.header.frame_id    = 'map'
            m.header.stamp       = stamp
            m.ns                 = 'barrel'
            m.id                 = i
            m.type               = Marker.CYLINDER
            m.action             = Marker.ADD
            m.scale.x = m.scale.y = 0.45
            m.scale.z            = 0.70
            m.color              = COLOR_RGBA.get(k['color'],
                                                  ColorRGBA(r=0.5, g=0.5, b=0.5, a=0.9))
            m.pose.position.x    = pos[0]
            m.pose.position.y    = pos[1]
            m.pose.position.z    = pos[2]
            m.lifetime.sec       = 0   # persistent
            if k['orientation'] == 'horizontal':
                m.pose.orientation.y = 0.7071068
                m.pose.orientation.w = 0.7071068
            else:
                m.pose.orientation.w = 1.0
            markers.markers.append(m)

            t                    = Marker()
            t.header             = m.header
            t.ns                 = 'barrel_label'
            t.id                 = i
            t.type               = Marker.TEXT_VIEW_FACING
            t.action             = Marker.ADD
            t.scale.z            = 0.18
            t.color              = ColorRGBA(r=1.0, g=1.0, b=1.0, a=1.0)
            t.pose.position.x    = pos[0]
            t.pose.position.y    = pos[1]
            t.pose.position.z    = pos[2] + 0.55
            t.pose.orientation.w = 1.0
            t.text               = f"{k['color']}\n{k['orientation']}" + \
                                   ('\nLEAKING' if k['leaking'] else '')
            t.lifetime.sec       = 0   # persistent
            markers.markers.append(t)

        if markers.markers:
            self.marker_pub.publish(markers)


def main():
    rclpy.init(args=None)
    node = BarrelDetector()
    try:
        rclpy.spin(node)
    finally:
        cv2.destroyAllWindows()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
