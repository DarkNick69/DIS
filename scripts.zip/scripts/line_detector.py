#!/usr/bin/env python3

import cv2
import numpy as np
import message_filters

import rclpy
from rclpy.duration import Duration
from rclpy.node import Node
from rclpy.qos import (
    QoSDurabilityPolicy, QoSHistoryPolicy,
    QoSProfile, QoSReliabilityPolicy, qos_profile_sensor_data,
)
from rclpy.time import Time as rclpyTime

from sensor_msgs.msg import Image, CameraInfo
from nav_msgs.msg import OccupancyGrid
from geometry_msgs.msg import PointStamped, Point
from std_msgs.msg import Bool, Float64, Int32
from visualization_msgs.msg import Marker
from cv_bridge import CvBridge, CvBridgeError

import tf2_ros
import tf2_geometry_msgs


# Yellow in HSV (OpenCV: H 0-179, S/V 0-255)
YELLOW_LOW  = np.array([18,  80,  80], dtype=np.uint8)
YELLOW_HIGH = np.array([40, 255, 255], dtype=np.uint8)

# Light cyan-blue in HSV — moderate saturation, very high brightness only
BLUE_LOW  = np.array([ 85,  60, 190], dtype=np.uint8)
BLUE_HIGH = np.array([115, 210, 255], dtype=np.uint8)

# Red wraps the hue circle, so it needs two ranges
RED_LOW1  = np.array([  0, 100,  80], dtype=np.uint8)
RED_HIGH1 = np.array([ 10, 255, 255], dtype=np.uint8)
RED_LOW2  = np.array([170, 100,  80], dtype=np.uint8)
RED_HIGH2 = np.array([179, 255, 255], dtype=np.uint8)

# Green in HSV (kept clear of the yellow band, which ends at H≈40)
GREEN_LOW  = np.array([ 45,  70,  60], dtype=np.uint8)
GREEN_HIGH = np.array([ 85, 255, 255], dtype=np.uint8)


class LineDetector(Node):
    def __init__(self):
        super().__init__('line_detector')

        self.declare_parameters('', [
            ('image_topic',       '/top_camera/rgb/preview/image_raw'),
            ('depth_topic',       '/top_camera/rgb/preview/depth'),
            ('camera_info_topic', '/top_camera/rgb/preview/camera_info'),
            ('map_topic',         '/map'),
            ('costmap_topic',     '/yellow_line_costmap'),
            ('map_frame',         'map'),
            ('obstacle_radius_m', 0.0),
            ('mark_cost',         80),
            ('min_yellow_ratio',  0.005),
            ('max_depth_m',       4.0),
            ('sample_step',       4),
            ('show_debug',        True),
        ])

        self.map_frame         = self.get_parameter('map_frame').value
        self.obstacle_radius_m = float(self.get_parameter('obstacle_radius_m').value)
        self.mark_cost         = int(self.get_parameter('mark_cost').value)
        self.min_yellow_ratio  = float(self.get_parameter('min_yellow_ratio').value)
        self.max_depth_m       = float(self.get_parameter('max_depth_m').value)
        self.sample_step       = int(self.get_parameter('sample_step').value)
        self.show_debug        = bool(self.get_parameter('show_debug').value)

        image_topic       = self.get_parameter('image_topic').value
        depth_topic       = self.get_parameter('depth_topic').value
        camera_info_topic = self.get_parameter('camera_info_topic').value
        map_topic         = self.get_parameter('map_topic').value
        costmap_topic     = self.get_parameter('costmap_topic').value

        self.camera_info   = None
        self.map_info      = None
        self.costmap_data  = None
        self._last_tf_warn = None
        self._last_det_log = None
        self._color_log_t  = {}
        self.marker_res    = 0.05
        self._color_pts    = {'red': set(), 'green': set()}

        self.tf_buffer   = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)
        self.bridge      = CvBridge()

        map_qos = QoSProfile(
            durability=QoSDurabilityPolicy.TRANSIENT_LOCAL,
            reliability=QoSReliabilityPolicy.RELIABLE,
            history=QoSHistoryPolicy.KEEP_LAST,
            depth=1,
        )

        self.create_subscription(CameraInfo, camera_info_topic, self._camera_info_cb, 1)
        self.create_subscription(OccupancyGrid, map_topic, self._map_cb, map_qos)

        # Synchronise RGB + depth so they correspond to the same instant
        rgb_sub   = message_filters.Subscriber(self, Image, image_topic,
                                               qos_profile=qos_profile_sensor_data)
        depth_sub = message_filters.Subscriber(self, Image, depth_topic,
                                               qos_profile=qos_profile_sensor_data)
        self._sync = message_filters.ApproximateTimeSynchronizer(
            [rgb_sub, depth_sub], queue_size=5, slop=0.1)
        self._sync.registerCallback(self._image_cb)

        self.costmap_pub  = self.create_publisher(OccupancyGrid, costmap_topic, map_qos)
        self.detected_pub = self.create_publisher(Bool, '/yellow_line_detected', 10)
        # Normalized horizontal centroid of yellow pixels (0=left, 1=right, -1=none)
        self.cx_pub            = self.create_publisher(Float64, '/yellow_line_cx', 10)
        self.blue_detected_pub  = self.create_publisher(Bool,    '/blue_line_detected',  10)
        # Number of distinct blue branches visible (1=single, 2=fork)
        self.blue_count_pub     = self.create_publisher(Int32,   '/blue_line_count',     10)
        # Normalised cx of leftmost branch (0=left, 1=right, -1=none)
        self.blue_cx_left_pub   = self.create_publisher(Float64, '/blue_line_cx_left',   10)
        # Normalised cx of rightmost branch (-1 if only one branch)
        self.blue_cx_right_pub  = self.create_publisher(Float64, '/blue_line_cx_right',  10)
        # True while the line continues into the FAR/forward part of the view.
        # Goes False at a branch tip (line only beneath the robot, none ahead),
        # which lets the commander commit to a 180° turn instead of oscillating.
        self.blue_ahead_pub     = self.create_publisher(Bool,    '/blue_line_ahead',     10)

        # Red / green line: Bool detected + RViz markers placed in the map frame
        self.red_detected_pub   = self.create_publisher(Bool, '/red_line_detected',   10)
        self.green_detected_pub = self.create_publisher(Bool, '/green_line_detected', 10)
        self.red_marker_pub     = self.create_publisher(Marker, '/red_line_marker',   map_qos)
        self.green_marker_pub   = self.create_publisher(Marker, '/green_line_marker', map_qos)
        # Normalised horizontal centroid of red/green pixels (0=left,1=right,-1=none)
        self.red_cx_pub         = self.create_publisher(Float64, '/red_line_cx',   10)
        self.green_cx_pub       = self.create_publisher(Float64, '/green_line_cx', 10)

        self.get_logger().info(f'RGB: {image_topic}  depth: {depth_topic}')
        self.get_logger().info(f'Costmap → {costmap_topic}  frame={self.map_frame}')

    # ── callbacks ───────────────────────────────────────────────────────────

    def _camera_info_cb(self, msg):
        self.camera_info = msg

    def _map_cb(self, msg):
        self.map_info = msg.info
        h, w = msg.info.height, msg.info.width
        if self.costmap_data is None or self.costmap_data.shape != (h, w):
            self.costmap_data = np.zeros((h, w), dtype=np.int8)
            self.get_logger().info(
                f'Costmap ready: {w}x{h} @ {msg.info.resolution:.3f} m/px')
            self._publish_costmap()

    def _image_cb(self, rgb_msg, depth_msg):
        if self.camera_info is None:
            return

        try:
            bgr   = self.bridge.imgmsg_to_cv2(rgb_msg, 'bgr8')
            depth = self.bridge.imgmsg_to_cv2(depth_msg, desired_encoding='passthrough')
        except CvBridgeError as e:
            self.get_logger().warn(f'CvBridge: {e}')
            return

        # Gazebo depth is float32 metres; uint16 images are millimetres
        if depth.dtype == np.uint16:
            depth = depth.astype(np.float32) / 1000.0
        else:
            depth = depth.astype(np.float32)

        hsv  = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(hsv, YELLOW_LOW, YELLOW_HIGH)

        # Remove small noise blobs
        kernel = np.ones((3, 3), np.uint8)
        mask   = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)

        ratio    = float(np.count_nonzero(mask)) / float(mask.size)
        detected = ratio >= self.min_yellow_ratio
        self.detected_pub.publish(Bool(data=detected))

        # Publish normalised horizontal centroid so robot_commander can tell
        # whether the line is in front (centre) or only on a side.
        if detected:
            _, xs_m = np.where(mask > 0)
            cx_norm = float(np.mean(xs_m)) / float(mask.shape[1])
        else:
            cx_norm = -1.0
        self.cx_pub.publish(Float64(data=cx_norm))

        if detected and self.map_info is not None:
            self._project_to_costmap(mask, depth, rgb_msg.header.frame_id)

        # ── Red / green line detection ───────────────────────────────────────
        frame_id = rgb_msg.header.frame_id
        red_mask = cv2.inRange(hsv, RED_LOW1, RED_HIGH1) | \
                   cv2.inRange(hsv, RED_LOW2, RED_HIGH2)
        self._handle_color(red_mask, kernel, depth, frame_id, 'red',
                           (1.0, 0.0, 0.0), self.red_detected_pub,
                           self.red_marker_pub, self.red_cx_pub)

        green_mask = cv2.inRange(hsv, GREEN_LOW, GREEN_HIGH)
        self._handle_color(green_mask, kernel, depth, frame_id, 'green',
                           (0.0, 1.0, 0.0), self.green_detected_pub,
                           self.green_marker_pub, self.green_cx_pub)

        # ── Blue line detection ──────────────────────────────────────────────
        blue_mask = cv2.inRange(hsv, BLUE_LOW, BLUE_HIGH)
        blue_mask = cv2.morphologyEx(blue_mask, cv2.MORPH_OPEN, kernel)

        # Crop to the immediate floor region in front of the robot:
        #   • discard top 55 % of rows  – walls / map-edge appear there
        #   • discard outer 15 % of cols – lateral edges of the world
        #   • discard depth > 0.8 m     – floor line is 0.2-0.6 m; map walls
        #                                  further away are rejected
        h, w = blue_mask.shape[:2]
        row_cut = int(h * 0.55)
        col_cut = int(w * 0.15)
        blue_mask[:row_cut, :]        = 0   # far / wall region
        blue_mask[:, :col_cut]        = 0   # left margin
        blue_mask[:, w - col_cut:]    = 0   # right margin
        near = np.isfinite(depth) & (depth > 0.02) & (depth < 0.5)
        blue_mask[~near] = 0
        blue_ratio    = float(np.count_nonzero(blue_mask)) / float(blue_mask.size)
        blue_detected = blue_ratio >= self.min_yellow_ratio

        # "Line ahead" = blue present in the far/forward 40 % of the cropped band
        # (the rows just below row_cut are the farthest floor still in view). On a
        # curve the line keeps reaching this region; at a branch tip it does not.
        ahead_end   = row_cut + max(1, int((h - row_cut) * 0.40))
        ahead_sub   = blue_mask[row_cut:ahead_end, :]
        ahead_ratio = float(np.count_nonzero(ahead_sub)) / float(ahead_sub.size)
        blue_ahead  = blue_detected and ahead_ratio >= self.min_yellow_ratio
        self.blue_ahead_pub.publish(Bool(data=bool(blue_ahead)))

        def _contour_cx(c, W):
            M = cv2.moments(c)
            return (M['m10'] / M['m00']) / W if M['m00'] > 0 else float('inf')

        def _region_cx(mask, r1, r2, c1, c2, W, col_offset=0):
            sub = mask[r1:r2, c1:c2]
            ys, xs = np.where(sub > 0)
            if len(xs) == 0:
                return None
            return (float(np.mean(xs)) + col_offset) / W

        if blue_detected:
            W_f     = float(w)
            valid_h = h - row_cut

            # ── Zone 1: upper 45 % of valid region — forward branches ────────
            upper_end = row_cut + int(valid_h * 0.45)
            upper_sub = blue_mask[row_cut:upper_end, :]
            up_cntrs, _ = cv2.findContours(
                upper_sub, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            up_min = max(20.0, upper_sub.size * 0.015)
            up_sig = sorted([c for c in up_cntrs if cv2.contourArea(c) >= up_min],
                            key=lambda c: _contour_cx(c, W_f))

            branches = []   # list of (rightness_score, cx)

            if len(up_sig) >= 2:
                M_l = cv2.moments(up_sig[0])
                M_r = cv2.moments(up_sig[-1])
                if M_l['m00'] > 0:
                    branches.append((1, (M_l['m10'] / M_l['m00']) / W_f))
                if M_r['m00'] > 0:
                    branches.append((2, (M_r['m10'] / M_r['m00']) / W_f))
            elif len(up_sig) == 1:
                M = cv2.moments(up_sig[0])
                if M['m00'] > 0:
                    branches.append((1, (M['m10'] / M['m00']) / W_f))

            # ── Zone 2: lower-right — back-right branch ───────────────────────
            # A sharp right turn (branch going backward-right) appears in the
            # near, right portion of the image that the upper zone misses.
            lr_r1   = row_cut + int(valid_h * 0.55)   # lower 45 % of valid rows
            lr_c1   = w // 2                           # right half of image
            lr_min  = max(25, int(blue_mask[lr_r1:h, lr_c1:w].size * 0.06))
            lr_cx   = _region_cx(blue_mask, lr_r1, h, lr_c1, w, W_f, col_offset=lr_c1)

            if lr_cx is not None and np.count_nonzero(
                    blue_mask[lr_r1:h, lr_c1:w]) >= lr_min:
                # Only count as separate branch if noticeably right of anything seen so far
                existing_max = max((cx for _, cx in branches), default=-1.0)
                if lr_cx > existing_max + 0.12 or not branches:
                    branches.append((3, lr_cx))   # score 3 = furthest right

            # ── Zone 2L: lower-left — back-left branch (mirror of Zone 2) ──────
            # A sharp LEFT turn (branch going backward-left) appears in the near,
            # left portion of the image that the upper zone misses. Without this
            # the detector was right-biased and "follow left branch" could pick a
            # right-of-centre branch.
            ll_r1  = row_cut + int(valid_h * 0.55)   # lower 45 % of valid rows
            ll_c2  = w // 2                           # left half of image
            ll_min = max(25, int(blue_mask[ll_r1:h, col_cut:ll_c2].size * 0.06))
            ll_cx  = _region_cx(blue_mask, ll_r1, h, col_cut, ll_c2, W_f,
                                col_offset=col_cut)

            if ll_cx is not None and np.count_nonzero(
                    blue_mask[ll_r1:h, col_cut:ll_c2]) >= ll_min:
                # Only count as separate branch if noticeably left of anything seen so far
                existing_min = min((cx for _, cx in branches), default=2.0)
                if ll_cx < existing_min - 0.12 or not branches:
                    branches.append((0, ll_cx))   # score 0 = furthest left

            # ── Resolve branches → cx_left / cx_right ────────────────────────
            if not branches:
                # Full-mask fallback
                contours, _ = cv2.findContours(
                    blue_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
                min_area = max(200.0, blue_mask.size * 0.005)
                sig = sorted([c for c in contours if cv2.contourArea(c) >= min_area],
                             key=lambda c: _contour_cx(c, W_f))
                if sig:
                    M_l = cv2.moments(sig[0])
                    M_r = cv2.moments(sig[-1])
                    cx_left  = (M_l['m10'] / M_l['m00']) / W_f if M_l['m00'] > 0 else -1.0
                    cx_right = (M_r['m10'] / M_r['m00']) / W_f if M_r['m00'] > 0 else -1.0
                    count    = len(sig)
                else:
                    blue_detected = False
                    cx_left = cx_right = -1.0
                    count   = 0
            else:
                branches.sort(key=lambda b: b[0])
                count    = len(branches)
                cx_left  = branches[0][1]   # lowest score = furthest left
                cx_right = branches[-1][1]  # highest score = furthest right
        else:
            cx_left = cx_right = -1.0
            count   = 0

        self.blue_detected_pub.publish(Bool(data=blue_detected))
        self.blue_count_pub.publish(Int32(data=count))
        self.blue_cx_left_pub.publish(Float64(data=cx_left))
        self.blue_cx_right_pub.publish(Float64(data=cx_right))

        if self.show_debug:
            cv2.imshow('Top Camera', bgr)
            cv2.imshow('Yellow Mask', mask)
            cv2.imshow('Blue Mask',  blue_mask)
            cv2.waitKey(1)

    # ── red / green colour lines ──────────────────────────────────────────────

    def _handle_color(self, raw_mask, kernel, depth, frame_id,
                      name, rgb, det_pub, marker_pub, cx_pub):
        mask  = cv2.morphologyEx(raw_mask, cv2.MORPH_OPEN, kernel)
        ratio = float(np.count_nonzero(mask)) / float(mask.size)
        detected = ratio >= self.min_yellow_ratio
        det_pub.publish(Bool(data=detected))

        if detected:
            _, xs = np.where(mask > 0)
            cx_pub.publish(Float64(data=float(np.mean(xs)) / float(mask.shape[1])))
        else:
            cx_pub.publish(Float64(data=-1.0))

        if not detected:
            return

        self._color_log(name, f'{name.upper()} line detected (ratio={ratio:.3f})')

        pts = self._project_points(mask, depth, frame_id)
        if not pts:
            return
        res = self.marker_res
        acc = self._color_pts[name]
        for mx, my in pts:
            acc.add((int(round(mx / res)), int(round(my / res))))
        world = [(gx * res, gy * res) for gx, gy in acc]
        self._publish_line_marker(world, marker_pub, rgb, f'{name}_line')

    def _project_points(self, mask, depth, frame_id):
        if self.camera_info is None:
            return []
        fx = self.camera_info.k[0]
        fy = self.camera_info.k[4]
        cx = self.camera_info.k[2]
        cy = self.camera_info.k[5]
        if fx == 0.0 or fy == 0.0:
            return []

        try:
            tf_stamped = self.tf_buffer.lookup_transform(
                self.map_frame, frame_id,
                rclpyTime(seconds=0),
                timeout=Duration(seconds=0.0),
            )
        except Exception:
            self._throttled_warn(
                f'No TF: {frame_id} → {self.map_frame}. '
                'Waiting for AMCL and arm joint states...')
            return []

        ys, xs = np.where(mask > 0)
        if len(xs) == 0:
            return []
        step = self.sample_step
        xs, ys = xs[::step], ys[::step]

        pts = []
        for u, v in zip(xs.tolist(), ys.tolist()):
            d = float(depth[v, u])
            if not (np.isfinite(d) and 0.05 < d <= self.max_depth_m):
                continue
            p = PointStamped()
            p.header.frame_id = frame_id
            p.header.stamp    = rclpyTime(seconds=0).to_msg()
            p.point.x =  d
            p.point.y = -(float(u) - cx) * d / fx
            p.point.z = -(float(v) - cy) * d / fy
            try:
                pm = tf2_geometry_msgs.do_transform_point(p, tf_stamped)
            except Exception:
                continue
            pts.append((pm.point.x, pm.point.y))
        return pts

    def _publish_line_marker(self, points, pub, rgb, ns):
        m = Marker()
        m.header.frame_id    = self.map_frame
        m.header.stamp       = self.get_clock().now().to_msg()
        m.ns                 = ns
        m.id                 = 0
        m.type               = Marker.POINTS
        m.action             = Marker.ADD
        m.scale.x = m.scale.y = 0.05
        m.color.r, m.color.g, m.color.b = rgb
        m.color.a            = 1.0
        m.points = [Point(x=float(mx), y=float(my), z=0.0) for mx, my in points]
        pub.publish(m)

    def _color_log(self, key, text, period_ns=1_000_000_000):
        now  = self.get_clock().now()
        last = self._color_log_t.get(key)
        if last is None or (now - last).nanoseconds > period_ns:
            self._color_log_t[key] = now
            self.get_logger().info(text)

    # ── projection ──────────────────────────────────────────────────────────

    def _project_to_costmap(self, mask, depth, frame_id):
        fx = self.camera_info.k[0]
        fy = self.camera_info.k[4]
        cx = self.camera_info.k[2]
        cy = self.camera_info.k[5]
        if fx == 0.0 or fy == 0.0:
            return

        # Look up TF once per frame (time=0 → latest available, non-blocking)
        try:
            tf_stamped = self.tf_buffer.lookup_transform(
                self.map_frame, frame_id,
                rclpyTime(seconds=0),
                timeout=Duration(seconds=0.0),
            )
        except Exception:
            self._throttled_warn(
                f'No TF: {frame_id} → {self.map_frame}. '
                'Waiting for AMCL and arm joint states...')
            return

        ys, xs = np.where(mask > 0)
        if len(xs) == 0:
            return

        step = self.sample_step
        xs, ys = xs[::step], ys[::step]

        updated = False
        for u, v in zip(xs.tolist(), ys.tolist()):
            d = float(depth[v, u])
            if not (np.isfinite(d) and 0.05 < d <= self.max_depth_m):
                continue

            # Back-project pixel to 3-D point.
            # The optical frame in the URDF has identity rotation relative to the
            # camera link (missing the standard rpy="-pi/2 0 -pi/2"), so we must
            # express the point in camera LINK convention (x-forward, y-left, z-up)
            # rather than optical convention (x-right, y-down, z-forward):
            #   x_link =  z_opt = d
            #   y_link = -x_opt = -(u - cx)*d/fx
            #   z_link = -y_opt = -(v - cy)*d/fy
            pt = PointStamped()
            pt.header.frame_id = frame_id
            pt.header.stamp    = rclpyTime(seconds=0).to_msg()
            pt.point.x =  d
            pt.point.y = -(float(u) - cx) * d / fx
            pt.point.z = -(float(v) - cy) * d / fy

            try:

                pt_map = tf2_geometry_msgs.do_transform_point(pt, tf_stamped)
            except Exception:
                continue

            if self._mark_cell(pt_map.point.x, pt_map.point.y):
                updated = True

        if updated:
            self._publish_costmap()
            self._throttled_det_log()

    def _mark_cell(self, mx, my):
        if self.map_info is None or self.costmap_data is None:
            return False
        res    = self.map_info.resolution
        origin = self.map_info.origin.position
        gx = int((mx - origin.x) / res)
        gy = int((my - origin.y) / res)
        h, w = self.costmap_data.shape
        if not (0 <= gx < w and 0 <= gy < h):
            return False
        # Mark a THIN trace (single cell when obstacle_radius_m == 0) with a
        # sub-lethal cost so the global planner is biased away from the line
        # without treating it as an impassable wall (which closed off narrow
        # halls once the inflation layer expanded the lethal cells).
        r  = max(0, int(round(self.obstacle_radius_m / res)))
        x0 = max(0, gx - r);  x1 = min(w - 1, gx + r)
        y0 = max(0, gy - r);  y1 = min(h - 1, gy + r)
        before = self.costmap_data[y0:y1+1, x0:x1+1].copy()
        self.costmap_data[y0:y1+1, x0:x1+1] = self.mark_cost
        return not np.array_equal(before, self.costmap_data[y0:y1+1, x0:x1+1])

    def _publish_costmap(self):
        if self.map_info is None or self.costmap_data is None:
            return
        msg = OccupancyGrid()
        msg.header.frame_id = self.map_frame
        msg.header.stamp    = self.get_clock().now().to_msg()
        msg.info            = self.map_info
        msg.data            = self.costmap_data.flatten().tolist()
        self.costmap_pub.publish(msg)

    # ── helpers ─────────────────────────────────────────────────────────────

    def _throttled_warn(self, text):
        now = self.get_clock().now()
        if (self._last_tf_warn is None or
                (now - self._last_tf_warn).nanoseconds > 2_000_000_000):
            self._last_tf_warn = now
            self.get_logger().warn(text)

    def _throttled_det_log(self):
        now = self.get_clock().now()
        if (self._last_det_log is None or
                (now - self._last_det_log).nanoseconds > 2_000_000_000):
            self._last_det_log = now
            self.get_logger().info('Yellow line marked on costmap')


def main(args=None):
    rclpy.init(args=args)
    node = LineDetector()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()
        cv2.destroyAllWindows()


if __name__ == '__main__':
    main()
