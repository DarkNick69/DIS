#!/usr/bin/env python3
"""Retrain the barrel YOLO model to also detect BLACK barrels.

Workflow (run with the ultralytics venv: /opt/ultralytics/bin/python3):

  1. Collect + auto-label black barrels (drive around them in the sim):
         ros2 run dis_tutorial7 collect_barrel_data.py
     → ~/barrel_dataset_black/{images,labels,preview}

  2. Review ~/barrel_dataset_black/preview/*.jpg and DELETE any wrong sample
     (delete the image, label and preview that share the same stem).

  3. Merge the reviewed samples into barrels_dataset and retrain:
         /opt/ultralytics/bin/python3 scripts/train_barrels_black.py --merge
         /opt/ultralytics/bin/python3 scripts/train_barrels_black.py

  4. Point detect_barrels.py YOLO_WEIGHTS at the new weights printed at the end,
     then restart detect_barrels.

This trains on the RAW (now black-augmented) dataset with Ultralytics' DEFAULT
online augmentation — matching the original `barrel_run` that scored mAP50 0.99.
The heavy OFFLINE augmentation in train_barrels.py collapsed barrel recall, so it
is deliberately NOT used here.
"""

import argparse
import os
import random
import shutil

ROOT     = '/home/xi/colcon_ws/src/task2-new'
DATA     = os.path.join(ROOT, 'barrels_dataset', 'data.yaml')
DST      = os.path.join(ROOT, 'barrels_dataset')
# Sources of captured samples (manual capture_barrel.py and/or the collector).
SRCS     = [os.path.expanduser('~/barrel_dataset_manual'),
            os.path.expanduser('~/barrel_dataset_black')]
VAL_FRAC = 0.15   # fraction of the new samples to put in valid/


def merge():
    """Copy reviewed captured samples into barrels_dataset/{train,valid}."""
    pairs = []   # (src_dir, stem)
    for src in SRCS:
        img_src = os.path.join(src, 'images')
        if not os.path.isdir(img_src):
            continue
        for f in os.listdir(img_src):
            if f.endswith('.jpg') and os.path.isfile(
                    os.path.join(src, 'labels', os.path.splitext(f)[0] + '.txt')):
                pairs.append((src, os.path.splitext(f)[0]))
    if not pairs:
        raise SystemExit('No captured samples found. Run capture_barrel.py first.')

    random.shuffle(pairs)
    n_val = int(len(pairs) * VAL_FRAC)
    for i, (src, stem) in enumerate(pairs):
        split = 'valid' if i < n_val else 'train'
        for sub, ext in (('images', '.jpg'), ('labels', '.txt')):
            os.makedirs(os.path.join(DST, split, sub), exist_ok=True)
            shutil.copy(os.path.join(src, sub, stem + ext),
                        os.path.join(DST, split, sub, stem + ext))
    print(f'Merged {len(pairs)} samples into barrels_dataset '
          f'({n_val} to valid, {len(pairs) - n_val} to train).')


def train():
    from ultralytics import YOLO
    model = YOLO('yolov8n.pt')
    model.train(
        data=DATA, epochs=120, imgsz=640, batch=16, patience=50,
        project=DST, name='barrel_run_black', exist_ok=True, verbose=True,
    )
    out = os.path.join(DST, 'barrel_run_black', 'weights', 'best.pt')
    print(f'\nDone — new weights: {out}')
    print("Update detect_barrels.py:  YOLO_WEIGHTS = p('barrels_dataset/"
          "barrel_run_black/weights/best.pt')  and restart detect_barrels.")


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--merge', action='store_true',
                    help='merge collected black samples into barrels_dataset, then exit')
    args = ap.parse_args()
    if args.merge:
        merge()
    else:
        train()
