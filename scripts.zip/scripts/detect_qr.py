#!/usr/bin/env python3
"""QR-code detector.

The task QR codes are mounted on the walls to the **left of each person's face**,
so they are visible to the same forward camera that detects the people
(`/oakd/rgb/preview/image_raw`, 320x240) — *not* the arm camera. This node
therefore runs on the oakd stream and needs no arm movement.

Decoding uses OpenCV's built-in `cv2.QRCodeDetector` (no external system library
required). Because the preview stream is small, each frame is also tried
upscaled 2x/3x, which is what lets a QR a metre away on the wall decode. If
`pyzbar` happens to be installed it is used as an extra fallback, but it is not
required (it needs `libzbar0`, which is often missing).

Publishes the decoded payload on `/qr_code` (String). `robot_commander` reads
the latest payload while standing in front of a person to learn the task.
"""

import cv2
import numpy as np

import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data

from sensor_msgs.msg import Image
from std_msgs.msg import String
from cv_bridge import CvBridge, CvBridgeError

# Scales at which to attempt decoding (the small 320x240 preview needs upscaling).
DECODE_SCALES = (1.0, 2.0, 3.0)


class QRDetector(Node):
    def __init__(self):
        super().__init__('qr_detector')

        self.bridge = CvBridge()
        self.qr = cv2.QRCodeDetector()

        # Optional extra decoder; not required.
        self._pyzbar = None
        try:
            from pyzbar.pyzbar import decode as _pyzbar_decode
            self._pyzbar = _pyzbar_decode
            self.get_logger().info('pyzbar available (extra fallback).')
        except Exception:
            self.get_logger().info('pyzbar not available — using cv2.QRCodeDetector only.')

        self.create_subscription(
            Image, '/oakd/rgb/preview/image_raw',
            self._img_cb, qos_profile_sensor_data)
        self.qr_pub = self.create_publisher(String, '/qr_code', 10)

        self._last_payload = None

        cv2.namedWindow('QR Detection', cv2.WINDOW_NORMAL)
        self.get_logger().info('QRDetector ready.')

    # ── decoding ────────────────────────────────────────────────────────────

    def _decode(self, bgr):
        """Return (payload, points) for the first QR decoded, else (None, None).
        `points` is an Nx2 int array of corners in the ORIGINAL image, or None."""
        gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
        for scale in DECODE_SCALES:
            img = gray if scale == 1.0 else cv2.resize(
                gray, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
            try:
                ok, infos, points, _ = self.qr.detectAndDecodeMulti(img)
            except cv2.error:
                ok, infos, points = False, [], None
            if ok and points is not None:
                for payload, pts in zip(infos, points):
                    if payload:
                        return payload.strip(), (np.asarray(pts) / scale).astype(int)
        # pyzbar fallback (only if installed)
        if self._pyzbar is not None:
            try:
                for d in self._pyzbar(bgr):
                    payload = d.data.decode('utf-8', 'ignore').strip()
                    if payload:
                        x, y, w, h = d.rect.left, d.rect.top, d.rect.width, d.rect.height
                        pts = np.array([[x, y], [x + w, y], [x + w, y + h], [x, y + h]])
                        return payload, pts
            except Exception:
                pass
        return None, None

    # ── callback ────────────────────────────────────────────────────────────

    def _img_cb(self, msg):
        try:
            bgr = self.bridge.imgmsg_to_cv2(msg, 'bgr8')
        except CvBridgeError as e:
            self.get_logger().error(str(e))
            return

        payload, pts = self._decode(bgr)

        if payload is not None:
            if pts is not None and len(pts) >= 4:
                cv2.polylines(bgr, [pts.reshape(-1, 1, 2)], True, (0, 255, 0), 2)
                cv2.putText(bgr, payload, (int(pts[0][0]), max(int(pts[0][1]) - 8, 12)),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2, cv2.LINE_AA)
            self.qr_pub.publish(String(data=payload))
            if payload != self._last_payload:
                self.get_logger().info(f'[QR] read: "{payload}"')
                self._last_payload = payload
        else:
            self._last_payload = None   # allow re-logging when a code reappears

        cv2.imshow('QR Detection', bgr)
        cv2.waitKey(1)


def main(args=None):
    rclpy.init(args=args)
    node = QRDetector()
    try:
        rclpy.spin(node)
    finally:
        cv2.destroyAllWindows()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
