#!/usr/bin/env python3
"""Keyboard teleop that publishes TwistStamped to /cmd_vel.

The standard `teleop_twist_keyboard` publishes plain `Twist`, but this robot's
diff-drive (and Nav2 `enable_stamped_cmd_vel`) expects **TwistStamped**, so it
would not move. This node fixes that.

Run (sim must be up; do NOT run mission_control/robot_commander at the same time,
they also publish /cmd_vel):

    ros2 run dis_tutorial7 teleop_keyboard.py

Keys:
    w / s : forward / backward
    a / d : turn left / right
    space : stop
    + / - : increase / decrease speed
    q     : quit
Hold nothing — each key press sends one motion that persists until the next key
(press space to halt). Arrow-free, works over SSH.
"""

import sys
import termios
import tty
import select

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import TwistStamped

HELP = __doc__

BINDINGS = {
    'w': (1.0,  0.0),
    's': (-1.0, 0.0),
    'a': (0.0,  1.0),
    'd': (0.0, -1.0),
    ' ': (0.0,  0.0),
}


class TeleopKeyboard(Node):
    def __init__(self):
        super().__init__('teleop_keyboard')
        self.pub = self.create_publisher(TwistStamped, 'cmd_vel', 10)
        self.lin = 0.25   # m/s
        self.ang = 0.8    # rad/s
        self.get_logger().info('Teleop ready. Focus this terminal and use w/a/s/d, space=stop, +/-, q=quit.')

    def send(self, lx, az):
        msg = TwistStamped()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.twist.linear.x = float(lx)
        msg.twist.angular.z = float(az)
        self.pub.publish(msg)


def get_key(timeout=0.1):
    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        r, _, _ = select.select([sys.stdin], [], [], timeout)
        return sys.stdin.read(1) if r else ''
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)


def main():
    rclpy.init()
    node = TeleopKeyboard()
    print(HELP)
    cur_lx, cur_az = 0.0, 0.0
    try:
        while rclpy.ok():
            key = get_key()
            if key == 'q':
                break
            elif key in ('+', '='):
                node.lin = min(node.lin + 0.05, 1.0)
                node.ang = min(node.ang + 0.1, 2.0)
                print(f'\rspeed: lin={node.lin:.2f} ang={node.ang:.2f}        ')
            elif key in ('-', '_'):
                node.lin = max(node.lin - 0.05, 0.05)
                node.ang = max(node.ang - 0.1, 0.1)
                print(f'\rspeed: lin={node.lin:.2f} ang={node.ang:.2f}        ')
            elif key in BINDINGS:
                fl, fa = BINDINGS[key]
                cur_lx = fl * node.lin
                cur_az = fa * node.ang
            # republish continuously so the controller keeps the command alive
            node.send(cur_lx, cur_az)
            rclpy.spin_once(node, timeout_sec=0.0)
    except KeyboardInterrupt:
        pass
    finally:
        node.send(0.0, 0.0)   # stop on exit
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
