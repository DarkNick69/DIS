#!/usr/bin/env python3
"""PatchCore-lite surface-anomaly detector (detection + segmentation).

Trained on *normal* tiles only (unsupervised): a memory bank of normal patch
features (ResNet18 layer2+layer3) is stored; at inference each patch's nearest-
neighbour distance to the bank gives a per-pixel anomaly heatmap, the image score
is the max patch distance.

Used by both `train_anomaly.py` (to build the bank + thresholds) and the ROS
`belt_inspector.py` node (to classify tiles). Runs on GPU if available.
"""

import os
import cv2
import numpy as np
import torch
import torch.nn.functional as F
import torchvision

IMG_SIZE = 256

_MEAN = torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1)
_STD  = torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1)


class _Backbone(torch.nn.Module):
    """Frozen ImageNet ResNet18 truncated after layer3."""

    def __init__(self):
        super().__init__()
        net = torchvision.models.resnet18(
            weights=torchvision.models.ResNet18_Weights.IMAGENET1K_V1)
        self.stem   = torch.nn.Sequential(net.conv1, net.bn1, net.relu, net.maxpool)
        self.layer1 = net.layer1
        self.layer2 = net.layer2
        self.layer3 = net.layer3
        self.eval()
        for prm in self.parameters():
            prm.requires_grad_(False)

    def forward(self, x):
        x  = self.stem(x)
        x  = self.layer1(x)
        f2 = self.layer2(x)
        f3 = self.layer3(f2)
        return f2, f3


class AnomalyDetector:
    def __init__(self, model_path=None, device=None):
        self.device = device or ('cuda' if torch.cuda.is_available() else 'cpu')
        self.backbone = _Backbone().to(self.device)
        self.mean = _MEAN.to(self.device)
        self.std  = _STD.to(self.device)

        self.bank = None            # (M, C) normal patch features on device
        self.fmap = None            # (h, w) feature-map size
        self.img_threshold   = None # image-level score → OK/NOK
        self.pix_threshold   = None # per-pixel heatmap → segmentation mask

        if model_path and os.path.isfile(model_path):
            self.load(model_path)

    # ── feature extraction ────────────────────────────────────────────────────

    def _preprocess(self, bgr):
        rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
        rgb = cv2.resize(rgb, (IMG_SIZE, IMG_SIZE))
        t = torch.from_numpy(rgb).float().permute(2, 0, 1).unsqueeze(0) / 255.0
        return (t.to(self.device) - self.mean) / self.std

    @torch.no_grad()
    def _embed(self, bgr):
        """Return (N=h*w, C) patch features and the (h, w) map size."""
        f2, f3 = self.backbone(self._preprocess(bgr))
        h, w = f2.shape[-2:]
        f3u = F.interpolate(f3, size=(h, w), mode='bilinear', align_corners=False)
        feat = torch.cat([f2, f3u], dim=1)              # (1, C, h, w)
        emb = feat.permute(0, 2, 3, 1).reshape(-1, feat.shape[1])
        return emb, (h, w)

    # ── training (memory bank) ────────────────────────────────────────────────

    def build_bank(self, normal_bgrs, subsample=16000, seed=0):
        feats = []
        for bgr in normal_bgrs:
            emb, hw = self._embed(bgr)
            feats.append(emb.cpu())
            self.fmap = hw
        allf = torch.cat(feats, 0)
        if allf.shape[0] > subsample:
            g = torch.Generator().manual_seed(seed)
            idx = torch.randperm(allf.shape[0], generator=g)[:subsample]
            allf = allf[idx]
        self.bank = allf.to(self.device)
        return self

    # ── inference ─────────────────────────────────────────────────────────────

    @torch.no_grad()
    def anomaly_map(self, bgr):
        """Raw per-patch NN-distance map at feature resolution (h, w)."""
        emb, hw = self._embed(bgr)
        # chunked cdist to bound memory
        nn = torch.empty(emb.shape[0], device=self.device)
        step = 4096
        for i in range(0, emb.shape[0], step):
            d = torch.cdist(emb[i:i + step], self.bank)
            nn[i:i + step] = d.min(dim=1).values
        return nn.reshape(hw).cpu().numpy()

    @torch.no_grad()
    def infer(self, bgr):
        """Return (is_nok: bool, score: float, mask: uint8 HxW, heat: float HxW)."""
        amap = self.anomaly_map(bgr)
        score = float(amap.max())
        H, W = bgr.shape[:2]
        heat = cv2.resize(amap, (W, H))
        heat = cv2.GaussianBlur(heat, (0, 0), sigmaX=4)
        is_nok = (self.img_threshold is not None) and (score >= self.img_threshold)
        if self.pix_threshold is not None:
            mask = (heat >= self.pix_threshold).astype(np.uint8) * 255
        else:
            mask = np.zeros((H, W), np.uint8)
        return is_nok, score, mask, heat

    # ── persistence ───────────────────────────────────────────────────────────

    def save(self, path):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        torch.save({
            'bank': self.bank.cpu(),
            'fmap': self.fmap,
            'img_threshold': self.img_threshold,
            'pix_threshold': self.pix_threshold,
        }, path)

    def load(self, path):
        d = torch.load(path, map_location=self.device)
        self.bank = d['bank'].to(self.device)
        self.fmap = d['fmap']
        self.img_threshold = d['img_threshold']
        self.pix_threshold = d['pix_threshold']
        return self
