#!/usr/bin/env python3

import queue
import subprocess
import threading

import rclpy
from rclpy.node import Node
from std_msgs.msg import String


class SpeechNode(Node):
    """Speaks every String received on /robot_say using espeak-ng.

    Messages are queued and spoken sequentially in a worker thread so
    long sentences never block the ROS executor. Identical consecutive
    messages within a short window are dropped to avoid alert spam.
    """

    DEDUP_WINDOW_S = 4.0

    def __init__(self):
        super().__init__('speech_node')

        self.declare_parameters('', [
            ('voice', 'en-us'),
            ('speed_wpm', 150),
        ])
        self.voice = self.get_parameter('voice').value
        self.speed = int(self.get_parameter('speed_wpm').value)

        self._queue = queue.Queue()
        self._last_text = None
        self._last_time = 0.0

        self.create_subscription(String, '/robot_say', self._say_cb, 10)

        threading.Thread(target=self._worker, daemon=True).start()
        self.get_logger().info('SpeechNode ready — listening on /robot_say.')

    def _say_cb(self, msg):
        text = msg.data.strip()
        if not text:
            return
        now = self.get_clock().now().nanoseconds / 1e9
        if text == self._last_text and (now - self._last_time) < self.DEDUP_WINDOW_S:
            return
        self._last_text = text
        self._last_time = now
        self._queue.put(text)

    def _worker(self):
        while True:
            text = self._queue.get()
            self.get_logger().info(f'[SAY] {text}')
            try:
                subprocess.run(
                    ['espeak-ng', '-v', self.voice, '-s', str(self.speed), text],
                    check=False, timeout=30,
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            except Exception as e:
                self.get_logger().warn(f'espeak-ng failed: {e}')


def main():
    rclpy.init(args=None)
    node = SpeechNode()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
