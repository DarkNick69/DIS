#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data, QoSReliabilityPolicy

from sensor_msgs.msg import Image, PointCloud2
from sensor_msgs_py import point_cloud2 as pc2
from geometry_msgs.msg import PoseStamped

from visualization_msgs.msg import Marker

from cv_bridge import CvBridge, CvBridgeError
import cv2
import numpy as np
import time

from ultralytics import YOLO

class detect_faces(Node):

	def __init__(self):
		super().__init__('detect_faces')

		self.declare_parameters(
			namespace='',
			parameters=[
				('device', ''),
		])

		marker_topic = "/people_marker"
		people_pose_topic = "/detected_people_pose"

		self.detection_color = (0,0,255)
		self.device = self.get_parameter('device').get_parameter_value().string_value

		self.bridge = CvBridge()
		self.scan = None

		self.rgb_image_sub = self.create_subscription(Image, "/oakd/rgb/preview/image_raw", self.rgb_callback, qos_profile_sensor_data)
		self.pointcloud_sub = self.create_subscription(PointCloud2, "/oakd/rgb/preview/depth/points", self.pointcloud_callback, qos_profile_sensor_data)

		self.marker_pub = self.create_publisher(Marker, marker_topic, QoSReliabilityPolicy.BEST_EFFORT)
		self.people_pose_pub = self.create_publisher(PoseStamped, people_pose_topic, 10)

		self.model = YOLO("yolov8n.pt")

		self.faces = []

		# Deduplication: list of (x, y, z, timestamp) in sensor frame
		self.known_people_positions = []
		self.people_dedup_distance = 0.5  # metres

		self.get_logger().info(
			f"Node has been initialized! Will publish face markers to {marker_topic} and poses to {people_pose_topic}."
		)

	def rgb_callback(self, data):
		self.faces = []

		try:
			cv_image = self.bridge.imgmsg_to_cv2(data, "bgr8")

			self.get_logger().info(f"Running inference on image...")

			res = self.model.predict(cv_image, imgsz=(256, 320), show=False, verbose=False, classes=[0], device=self.device)

			for x in res:
				bbox = x.boxes.xyxy
				if bbox.nelement() == 0:
					continue

				self.get_logger().info(f"Person has been detected!")

				bbox = bbox[0]

				cv_image = cv2.rectangle(cv_image, (int(bbox[0]), int(bbox[1])), (int(bbox[2]), int(bbox[3])), self.detection_color, 3)

				cx = int((bbox[0]+bbox[2])/2)
				cy = int((bbox[1]+bbox[3])/2)

				cv_image = cv2.circle(cv_image, (cx,cy), 5, self.detection_color, -1)

				self.faces.append((cx,cy))

			cv2.imshow("image", cv_image)
			key = cv2.waitKey(1)
			if key==27:
				print("exiting")
				exit()
			
		except CvBridgeError as e:
			print(e)

	def pointcloud_callback(self, data):
		height = data.height
		width = data.width

		if height == 0 or width == 0:
			return

		# XYZ point cloud as (height, width, 3) array
		a = pc2.read_points_numpy(data, field_names=("x", "y", "z"))
		a = a.reshape((height, width, 3))

		for idx, (x, y) in enumerate(self.faces):
			if x < 0 or x >= width or y < 0 or y >= height:
				continue

			d = a[y, x, :]

			if not np.isfinite(d).all():
				continue

			# Deduplicate: skip if too close to a recently published detection
			now = time.time()
			self.known_people_positions = [
				(px, py, pz, t) for px, py, pz, t in self.known_people_positions
				if now - t < 3.0
			]
			if any(
				np.linalg.norm(d - np.array([px, py, pz])) < self.people_dedup_distance
				for px, py, pz, t in self.known_people_positions
			):
				self.get_logger().debug(f'Person {idx} too close to recent detection, skipping.')
				continue
			self.known_people_positions.append((float(d[0]), float(d[1]), float(d[2]), now))

			marker = Marker()

			marker.header.frame_id = data.header.frame_id
			marker.header.stamp = data.header.stamp

			marker.type = 2
			marker.id = idx

			scale = 0.1
			marker.scale.x = scale
			marker.scale.y = scale
			marker.scale.z = scale

			marker.color.r = 1.0
			marker.color.g = 1.0
			marker.color.b = 1.0
			marker.color.a = 1.0

			marker.pose.position.x = float(d[0])
			marker.pose.position.y = float(d[1])
			marker.pose.position.z = float(d[2])

			person_pose = PoseStamped()
			person_pose.header.frame_id = data.header.frame_id
			person_pose.header.stamp = data.header.stamp
			person_pose.pose.position.x = float(d[0])
			person_pose.pose.position.y = float(d[1])
			person_pose.pose.position.z = float(d[2])
			person_pose.pose.orientation.w = 1.0

			self.marker_pub.publish(marker)
			self.people_pose_pub.publish(person_pose)
			self.get_logger().debug(f'Published face {idx} in frame {data.header.frame_id}')

def main():
	print('Face detection node starting.')

	rclpy.init(args=None)
	node = detect_faces()
	rclpy.spin(node)
	node.destroy_node()
	rclpy.shutdown()

if __name__ == '__main__':
	main()