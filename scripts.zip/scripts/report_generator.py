#!/usr/bin/env python3
"""Inspection report (PDF) in the slide-14 layout.

Collects detections during the run and, on `/generate_report`, writes a PDF with
one section per *performed task* (headed "Requested by: <name>"), embedding photos
of leaking barrels and defect tiles + their segmentation masks.

Topics:
    /identified_people  String  name|role|gender|x|y|z
    /ring_detections    String  "[RING] color=C pos=(x,y)"
    /barrel_detections  String  "[BARREL] color=C orientation=O leaking=L pos=(x,y,z) [image=PATH]"
    /tile_results       String  "tile|id|OK|NOK|score|imgpath|maskpath"
    /dialogue_result    String  task_code|name        (who requested which task)
    /generate_report    Empty   → write the PDF
"""

import os
import re
from collections import Counter
from datetime import datetime

import rclpy
from rclpy.node import Node
from std_msgs.msg import String

from pkg_paths import p

REPORTS_DIR = p('reports')
IMAGES_DIR  = p('inspection_images')

# task code (from /generate_report) → report file suffix
TASK_FILE = {
    'ring_count':        'rings',
    'barrel_inspection': 'barrels',
    'anomaly_red':       'red_belt',
    'anomaly_green':     'green_belt',
}

BARREL_RE = re.compile(
    r'color=(\w+)\s+orientation=(\w+)\s+leaking=(\w+)\s+'
    r'pos=\(([-\d.]+),([-\d.]+),([-\d.]+)\)')
BARREL_IMG_RE = re.compile(r'image=(\S+)')
RING_RE = re.compile(r'color=(\w+)\s+pos=\(([-\d.]+),([-\d.]+)\)')

SECTION_OF = {
    'ring_count':        'Ring Counting',
    'barrel_inspection': 'Barrel Inspection',
    'anomaly_red':       'Anomaly Detection',
    'anomaly_green':     'Anomaly Detection',
}


class ReportGenerator(Node):
    def __init__(self):
        super().__init__('report_generator')

        self.people  = []   # (name, role, gender, x, y)
        self.barrels = []   # dict(color, orientation, leaking, x, y, image)
        self.rings   = []   # (color, x, y)
        self.tiles   = []   # dict(id, status, score, img, mask)
        self.assignments = {}   # section title -> [names]

        os.makedirs(IMAGES_DIR, exist_ok=True)
        os.makedirs(REPORTS_DIR, exist_ok=True)

        self.create_subscription(String, '/identified_people', self._person_cb, 10)
        self.create_subscription(String, '/barrel_detections', self._barrel_cb, 10)
        self.create_subscription(String, '/ring_detections',   self._ring_cb,   10)
        self.create_subscription(String, '/tile_results',      self._tile_cb,   10)
        self.create_subscription(String, '/dialogue_result',   self._assign_cb, 10)
        self.create_subscription(String, '/generate_report',   self._trigger_cb, 1)

        self.say_pub = self.create_publisher(String, '/robot_say', 10)
        self.get_logger().info(
            'ReportGenerator ready — trigger per task with: '
            "ros2 topic pub --once /generate_report std_msgs/msg/String "
            "'{data: barrel_inspection}'")

    # ── collectors ────────────────────────────────────────────────────────────

    def _person_cb(self, msg):
        parts = msg.data.split('|')
        if len(parts) != 6:
            return
        name, role, gender = parts[0], parts[1], parts[2]
        if any(pp[0] == name for pp in self.people):
            return
        self.people.append((name, role, gender, parts[3], parts[4]))

    def _barrel_cb(self, msg):
        m = BARREL_RE.search(msg.data)
        if not m:
            return
        img = BARREL_IMG_RE.search(msg.data)
        self.barrels.append({
            'color': m.group(1), 'orientation': m.group(2),
            'leaking': m.group(3).lower() == 'true',
            'x': m.group(4), 'y': m.group(5),
            'image': img.group(1) if img else None,
        })

    def _ring_cb(self, msg):
        m = RING_RE.search(msg.data)
        if m:
            self.rings.append((m.group(1), m.group(2), m.group(3)))

    def _tile_cb(self, msg):
        parts = msg.data.split('|')
        if len(parts) < 6 or parts[0] != 'tile':
            return
        self.tiles.append({
            'id': parts[1], 'status': parts[2], 'score': parts[3],
            'img': parts[4], 'mask': parts[5],
        })

    def _assign_cb(self, msg):
        task, _, name = msg.data.partition('|')
        title = SECTION_OF.get(task.strip())
        if title:
            self.assignments.setdefault(title, [])
            if name and name not in self.assignments[title]:
                self.assignments[title].append(name)

    # ── PDF generation ────────────────────────────────────────────────────────

    def _trigger_cb(self, msg):
        code = msg.data.strip()
        if code not in TASK_FILE:
            self.get_logger().warn(
                f'/generate_report: unknown task code "{code}"; '
                f'expected one of {list(TASK_FILE)}.')
            return
        path = os.path.join(REPORTS_DIR, f'inspection_report_{TASK_FILE[code]}.pdf')
        try:
            self._write_pdf(path, code)
        except Exception as e:
            self.get_logger().error(f'Report generation failed: {e}')
            return
        self.get_logger().info(f'Report written to {path}')
        self.say_pub.publish(String(data='Inspection complete. Here is the report.'))

    def _requested_by(self, title):
        names = self.assignments.get(title, [])
        return ', '.join(n.capitalize() for n in names) if names else '(unspecified)'

    def _write_pdf(self, path, code):
        from fpdf import FPDF

        pdf = FPDF()
        pdf.set_auto_page_break(auto=True, margin=15)
        pdf.add_page()

        def h1(t):
            pdf.set_font('Helvetica', 'B', 16)
            pdf.cell(0, 10, t, align='C', new_x='LMARGIN', new_y='NEXT')

        def h2(t):
            pdf.ln(2)
            pdf.set_font('Helvetica', 'B', 13)
            pdf.cell(0, 8, t, new_x='LMARGIN', new_y='NEXT')
            pdf.set_font('Helvetica', '', 10)

        def line(t, bold=False):
            pdf.set_font('Helvetica', 'B' if bold else '', 10)
            pdf.cell(0, 6, t, new_x='LMARGIN', new_y='NEXT')

        def table(headers, rows, widths, alert_cells=()):
            pdf.set_font('Helvetica', 'B', 10)
            for hdr, cw in zip(headers, widths):
                pdf.cell(cw, 7, hdr, border=1)
            pdf.ln()
            pdf.set_font('Helvetica', '', 10)
            for row in rows:
                for val, cw in zip(row, widths):
                    if str(val) in alert_cells:
                        pdf.set_text_color(200, 0, 0)
                    else:
                        pdf.set_text_color(0, 0, 0)
                    pdf.cell(cw, 7, str(val), border=1)
                pdf.set_text_color(0, 0, 0)
                pdf.ln()
            pdf.ln(2)

        def embed(img_path, w=55, caption=None):
            if img_path and os.path.isfile(img_path):
                try:
                    if caption:
                        line(caption)
                    pdf.image(img_path, w=w)
                    pdf.ln(2)
                except Exception:
                    pass

        # ── header ─────────────────────────────────────────────────────────────
        h1('Inspection Report')
        pdf.set_font('Helvetica', '', 11)
        pdf.cell(0, 6, f'Date: {datetime.now():%Y-%m-%d %H:%M}',
                 new_x='LMARGIN', new_y='NEXT')
        pdf.cell(0, 6, 'Robot: TurtleBot4', new_x='LMARGIN', new_y='NEXT')

        # Only the section for the task that was just performed is written, so
        # each report file (reports/inspection_report_<task>.pdf) is task-specific.

        # ── Task: Ring Counting ─────────────────────────────────────────────────
        if code == 'ring_count':
            h2('Task: Ring Counting')
            line(f'Requested by: {self._requested_by("Ring Counting")}')
            if self.rings:
                counts = Counter(c for c, _, _ in self.rings)
                line(f'Total number of rings detected: {len(self.rings)}')
                line('Detected colours:')
                table(['Colour', 'Count'],
                      [(c.capitalize(), n) for c, n in sorted(counts.items())],
                      [40, 25])
            else:
                line('No rings were detected during the inspection.')

        # ── Task: Barrel Inspection ─────────────────────────────────────────────
        if code == 'barrel_inspection':
            h2('Task: Barrel Inspection')
            line(f'Requested by: {self._requested_by("Barrel Inspection")}')
            if self.barrels:
                line(f'Total number of barrels inspected: {len(self.barrels)}')
                rows = [(i + 1, b['color'].capitalize(), b['orientation'].capitalize(),
                         'Yes' if b['leaking'] else 'No')
                        for i, b in enumerate(self.barrels)]
                table(['Barrel ID', 'Colour', 'Orientation', 'Leak detected'],
                      rows, [25, 35, 35, 35], alert_cells=('Yes',))
                for i, b in enumerate(self.barrels):
                    if b['leaking'] or b['orientation'].lower() == 'horizontal':
                        embed(b['image'], caption=f'ID {i + 1}:')
            else:
                line('No barrels were detected during the inspection.')

        # ── Task: Anomaly Detection ─────────────────────────────────────────────
        if code in ('anomaly_red', 'anomaly_green') and self.tiles:
            h2('Task: Anomaly Detection')
            line(f'Requested by: {self._requested_by("Anomaly Detection")}')
            n_ok = sum(1 for t in self.tiles if t['status'] == 'OK')
            n_nok = sum(1 for t in self.tiles if t['status'] == 'NOK')
            line(f'Total number of tiles inspected: {len(self.tiles)}')
            line(f'OK: {n_ok}    NOK: {n_nok}')
            table(['Tile ID', 'Status'],
                  [(t['id'], t['status']) for t in self.tiles],
                  [25, 35], alert_cells=('NOK',))
            for t in self.tiles:
                if t['status'] == 'NOK':
                    line(f'ID {t["id"]}:')
                    x0 = pdf.get_x()
                    y0 = pdf.get_y()
                    if t['img'] and os.path.isfile(t['img']):
                        try:
                            pdf.image(t['img'], x=x0, y=y0, w=45)
                        except Exception:
                            pass
                    if t['mask'] and os.path.isfile(t['mask']):
                        try:
                            pdf.image(t['mask'], x=x0 + 50, y=y0, w=45)
                        except Exception:
                            pass
                    pdf.ln(48)

        # ── Personnel (extra) ───────────────────────────────────────────────────
        if self.people:
            h2('Personnel encountered')
            table(['Name', 'Role', 'Gender'],
                  [(n.capitalize(), r, g) for n, r, g, _, _ in self.people],
                  [45, 70, 30])

        pdf.output(path)


def main():
    rclpy.init(args=None)
    node = ReportGenerator()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
