#!/usr/bin/env python3
"""Barrel inspection — self-enclosed waypoint sweep.

Drives through every waypoint except the last (the last initialises blue-line
following), scanning at each, while `detect_barrels.py` finds barrels and
publishes them on `/barrel_detections` as:

    [BARREL] color=<color>  orientation=<horizontal|vertical>  leaking=<bool>  pos=(x,y,z) ...

This node collects those during the sweep and reports a count, the orientation
split, and any leaks (which are the report's priority finding).

    subscribe  /inspect_barrels    std_msgs/Empty    → run the sweep
    subscribe  /barrel_detections  std_msgs/String   → findings (collected)
    publish    /barrels_done        std_msgs/Empty    → signal completion
"""

import rclpy

from pkg_paths import p
from sweep_inspector import SweepInspector, spin_inspector


class BarrelInspector(SweepInspector):
    def __init__(self):
        super().__init__('barrel_inspector', '/inspect_barrels', '/barrels_done',
                         'barrel', '/barrel_detections',
                         waypoints_file=p('waypoints_barrels.txt'))

    def describe(self, detection):
        color = self._field(detection, 'color') or 'unknown'
        orient = self._field(detection, 'orientation') or 'unknown'
        pos = self._field(detection, 'pos') or '(?)'
        desc = f'{color}, {orient} at {pos}'
        if self._field(detection, 'leaking') == 'True':
            desc += ', LEAKING'
        return desc

    def summarize(self, detections):
        n = len(detections)
        if n == 0:
            return 'Barrel inspection complete. I did not find any barrels.'

        horizontal = sum(1 for d in detections
                         if self._field(d, 'orientation') == 'horizontal')
        vertical = n - horizontal
        leaks = [self._field(d, 'color') or 'a'
                 for d in detections if self._field(d, 'leaking') == 'True']

        plural = 'barrel' if n == 1 else 'barrels'
        msg = (f'Barrel inspection complete. I found {n} {plural}: '
               f'{horizontal} horizontal and {vertical} vertical.')
        if leaks:
            which = ', '.join(leaks)
            msg += f' Warning: {len(leaks)} leaking — {which}.'
        else:
            msg += ' No leaks detected.'
        return msg


def main(args=None):
    rclpy.init(args=args)
    node = BarrelInspector()
    try:
        spin_inspector(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
