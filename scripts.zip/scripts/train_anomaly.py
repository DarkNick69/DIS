#!/usr/bin/env python3
"""Train the PatchCore-lite anomaly detector on RINS_AD_dataset.

  Build a memory bank from NORMAL ("okay") tiles, choose an image-level threshold
  (max-F1 on a val split of okay vs damaged) and a pixel-level threshold (high
  percentile of normal-map values), then evaluate image AUROC / F1 on held-out
  data and report pixel IoU on damaged tiles using the ground-truth masks.

Run with the GPU venv:
    /opt/ultralytics/bin/python3 scripts/train_anomaly.py
"""

import os
import glob
import random

import cv2
import numpy as np

from pkg_paths import p
from anomaly_infer import AnomalyDetector

DATA      = p('RINS_AD_dataset')
OUT_MODEL = p('models/anomaly/patchcore.pt')
VAL_OKAY  = 120     # held-out normal images for thresholding / eval
SUBSAMPLE = 16000   # memory-bank size


def _load(paths):
    out = []
    for f in paths:
        im = cv2.imread(f)
        if im is not None:
            out.append((f, im))
    return out


def main():
    random.seed(0)
    okay = sorted(glob.glob(f'{DATA}/train/images/okay_*.png'))
    dmg  = sorted(glob.glob(f'{DATA}/train/images/damaged_*.png'))
    random.shuffle(okay)
    random.shuffle(dmg)

    val_okay = okay[:VAL_OKAY]
    train_okay = okay[VAL_OKAY:]
    val_dmg = dmg[:VAL_OKAY]              # balance the val set
    print(f'normals: {len(train_okay)} train / {len(val_okay)} val   damaged val: {len(val_dmg)}')

    det = AnomalyDetector()
    print('Building memory bank...')
    det.build_bank([im for _, im in _load(train_okay)], subsample=SUBSAMPLE)
    print(f'  bank: {tuple(det.bank.shape)}  fmap: {det.fmap}')

    # ── score val images ──────────────────────────────────────────────────────
    def score(bgr):
        return float(det.anomaly_map(bgr).max())

    okay_scores = np.array([score(im) for _, im in _load(val_okay)])
    dmg_scores  = np.array([score(im) for _, im in _load(val_dmg)])

    # image-level threshold: maximise F1 over candidate thresholds
    cand = np.unique(np.concatenate([okay_scores, dmg_scores]))
    best_t, best_f1 = cand[0], -1.0
    for t in cand:
        tp = np.sum(dmg_scores >= t)
        fp = np.sum(okay_scores >= t)
        fn = np.sum(dmg_scores < t)
        prec = tp / (tp + fp + 1e-9)
        rec  = tp / (tp + fn + 1e-9)
        f1 = 2 * prec * rec / (prec + rec + 1e-9)
        if f1 > best_f1:
            best_f1, best_t = f1, float(t)
    det.img_threshold = best_t

    # AUROC (rank-based)
    labels = np.concatenate([np.zeros_like(okay_scores), np.ones_like(dmg_scores)])
    scores = np.concatenate([okay_scores, dmg_scores])
    order = np.argsort(scores)
    ranks = np.empty_like(order, dtype=float)
    ranks[order] = np.arange(1, len(scores) + 1)
    n_pos = labels.sum(); n_neg = len(labels) - n_pos
    auroc = (ranks[labels == 1].sum() - n_pos * (n_pos + 1) / 2) / (n_pos * n_neg + 1e-9)

    # ── pixel threshold: high percentile of normal heatmaps ───────────────────
    pix_vals = []
    for _, im in _load(val_okay[:40]):
        heat = cv2.resize(det.anomaly_map(im), im.shape[1::-1])
        heat = cv2.GaussianBlur(heat, (0, 0), sigmaX=4)
        pix_vals.append(np.percentile(heat, 99.5))
    det.pix_threshold = float(np.mean(pix_vals))

    # ── pixel IoU on damaged val (segmentation sanity) ────────────────────────
    ious = []
    for f, im in _load(val_dmg[:60]):
        gt = cv2.imread(f.replace('/images/', '/gt/'), 0)
        if gt is None:
            continue
        _, _, mask, _ = det.infer(im)
        gt = (cv2.resize(gt, mask.shape[1::-1]) > 127)
        pr = mask > 127
        inter = np.logical_and(gt, pr).sum()
        union = np.logical_or(gt, pr).sum()
        if union > 0:
            ious.append(inter / union)

    det.save(OUT_MODEL)

    print('\n── results ──────────────────────────────────────────')
    print(f'image AUROC      : {auroc:.3f}')
    print(f'image F1 (val)   : {best_f1:.3f}  @ threshold {best_t:.2f}')
    print(f'okay  score mean : {okay_scores.mean():.2f}  (max {okay_scores.max():.2f})')
    print(f'dmg   score mean : {dmg_scores.mean():.2f}  (min {dmg_scores.min():.2f})')
    print(f'pixel threshold  : {det.pix_threshold:.2f}')
    print(f'pixel IoU (dmg)  : {np.mean(ious):.3f}' if ious else 'pixel IoU      : n/a')
    print(f'saved model → {OUT_MODEL}')


if __name__ == '__main__':
    main()
