#!/usr/bin/env python3
"""Build an augmented barrel-detection dataset, mirroring build_people_dataset.py.

Unlike the face dataset (whole-frame labels), barrels carry real YOLO bounding
boxes, so only augmentations that DO NOT move the boxes are applied offline
(brightness, gamma, hue/sat, downscale-for-distance, blur, JPEG, noise), plus a
horizontal flip with a matching box transform. Geometric jitter (rotate/scale/
translate/mosaic) is left to Ultralytics' online augmentation, which transforms
boxes correctly.

Source: barrels_dataset/{train,valid}/{images,labels}   (Roboflow export, nc=2)
Output: barrels_dataset_aug/{train,val}/{images,labels} + data.yaml

Usage:
    /opt/ultralytics/bin/python3 scripts/build_barrels_dataset.py            # 10 variants/image
    /opt/ultralytics/bin/python3 scripts/build_barrels_dataset.py --per 16
"""

import argparse
import os
import random
import shutil

import cv2
import numpy as np

NAMES = ['barrel_horizontal', 'barrel_vertical']


# ── box-preserving photometric augmentations (BGR uint8 in/out) ────────────────

def aug_brightness_contrast(img):
    return cv2.convertScaleAbs(img, alpha=random.uniform(0.7, 1.3),
                               beta=random.uniform(-30, 30))


def aug_gamma(img):
    g = random.uniform(0.6, 1.6)
    lut = np.array([((i / 255.0) ** (1.0 / g)) * 255
                    for i in range(256)]).astype(np.uint8)
    return cv2.LUT(img, lut)


def aug_hue_sat(img):
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV).astype(np.int16)
    hsv[..., 0] = (hsv[..., 0] + random.randint(-8, 8)) % 180
    hsv[..., 1] = np.clip(hsv[..., 1] + random.randint(-25, 25), 0, 255)
    return cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2BGR)


def aug_downscale(img):
    # Simulate a distant / low-res barrel (the live oakd preview is only 320x240).
    # Kept mild: too-aggressive downscaling collapses clean-image recall.
    h, w = img.shape[:2]
    f = random.uniform(0.45, 0.8)
    small = cv2.resize(img, (max(1, int(w * f)), max(1, int(h * f))),
                       interpolation=cv2.INTER_AREA)
    return cv2.resize(small, (w, h), interpolation=cv2.INTER_LINEAR)


def aug_blur(img):
    if random.random() < 0.5:
        k = random.choice([3, 5, 7])
        return cv2.GaussianBlur(img, (k, k), 0)
    k = random.choice([5, 7, 9])
    kernel = np.zeros((k, k))
    if random.random() < 0.5:
        kernel[k // 2, :] = 1.0
    else:
        kernel[:, k // 2] = 1.0
    return cv2.filter2D(img, -1, kernel / k)


def aug_jpeg(img):
    q = random.randint(25, 75)
    ok, enc = cv2.imencode('.jpg', img, [cv2.IMWRITE_JPEG_QUALITY, q])
    return cv2.imdecode(enc, cv2.IMREAD_COLOR) if ok else img


def aug_noise(img):
    noise = np.random.normal(0, random.uniform(4, 14), img.shape)
    return np.clip(img.astype(np.float32) + noise, 0, 255).astype(np.uint8)


# (function, probability) — all box-preserving
PIPELINE = [
    (aug_brightness_contrast, 0.6),
    (aug_gamma,               0.4),
    (aug_hue_sat,             0.4),
    (aug_downscale,           0.35),  # distance / low-res (mild)
    (aug_blur,                0.4),
    (aug_jpeg,                0.5),
    (aug_noise,               0.2),
]


def augment_photometric(img):
    for fn, p in PIPELINE:
        if random.random() < p:
            img = fn(img)
    return img


def read_labels(path):
    """Return list of (cls, xc, yc, w, h) floats; [] if file missing."""
    if not os.path.isfile(path):
        return []
    out = []
    with open(path) as fh:
        for ln in fh:
            parts = ln.split()
            if len(parts) == 5:
                out.append([float(x) for x in parts])
    return out


def flip_labels(labels):
    return [[c, 1.0 - xc, yc, w, h] for (c, xc, yc, w, h) in labels]


def write_labels(path, labels):
    with open(path, 'w') as fh:
        for c, xc, yc, w, h in labels:
            fh.write(f'{int(c)} {xc:.6f} {yc:.6f} {w:.6f} {h:.6f}\n')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--src', default='barrels_dataset')
    ap.add_argument('--out', default='barrels_dataset_aug')
    ap.add_argument('--per', type=int, default=10, help='augmented variants per source image')
    ap.add_argument('--seed', type=int, default=0)
    args = ap.parse_args()

    random.seed(args.seed)
    np.random.seed(args.seed)

    here = os.path.dirname(os.path.abspath(__file__))
    root = os.path.dirname(here)
    src = os.path.join(root, args.src)
    out = os.path.join(root, args.out)

    if os.path.exists(out):
        shutil.rmtree(out)
    for split in ('train', 'val'):
        os.makedirs(os.path.join(out, split, 'images'))
        os.makedirs(os.path.join(out, split, 'labels'))

    # Map the Roboflow split → our split (valid → val).
    split_map = {'train': 'train', 'valid': 'val'}
    total = 0
    for src_split, dst_split in split_map.items():
        img_dir = os.path.join(src, src_split, 'images')
        lbl_dir = os.path.join(src, src_split, 'labels')
        if not os.path.isdir(img_dir):
            continue
        files = sorted(f for f in os.listdir(img_dir)
                       if f.lower().endswith(('.jpg', '.jpeg', '.png')))
        for f in files:
            img0 = cv2.imread(os.path.join(img_dir, f))
            if img0 is None:
                continue
            stem = os.path.splitext(f)[0]
            labels0 = read_labels(os.path.join(lbl_dir, stem + '.txt'))

            def emit(tag, img, labels):
                nonlocal total
                cv2.imwrite(os.path.join(out, dst_split, 'images', f'{stem}_{tag}.jpg'), img)
                write_labels(os.path.join(out, dst_split, 'labels', f'{stem}_{tag}.txt'), labels)
                total += 1

            emit('orig', img0, labels0)                       # keep the clean original
            # Validate on CLEAN images only, so best.pt is selected on real
            # (un-degraded) performance instead of on augmented val images.
            if dst_split == 'val':
                continue
            for i in range(args.per):
                img = img0.copy()
                labels = labels0
                if random.random() < 0.5:                     # box-correct h-flip
                    img = cv2.flip(img, 1)
                    labels = flip_labels(labels0)
                img = augment_photometric(img)
                emit(f'aug{i:02d}', img, labels)
        print(f'  {src_split} -> {dst_split}: {len(files)} sources')

    names_block = '\n'.join(f'  {i}: {n}' for i, n in enumerate(NAMES))
    with open(os.path.join(out, 'data.yaml'), 'w') as fh:
        fh.write(f'train: {os.path.join(out, "train", "images")}\n')
        fh.write(f'val:   {os.path.join(out, "val", "images")}\n\n')
        fh.write(f'nc: {len(NAMES)}\n')
        fh.write(f'names:\n{names_block}\n')

    print(f'\nDone: {total} images -> {out}')
    print('Train with:  /opt/ultralytics/bin/python3 scripts/train_barrels.py')


if __name__ == '__main__':
    main()
