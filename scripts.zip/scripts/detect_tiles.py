#!/usr/bin/env python3
"""Detect tiles in the arm (top) camera, then judge each one damaged vs okay.

Two independent models, run in sequence per frame:
  1. DETECTION  (YOLOv8n)      -- "is there a tile, and where?"
     trained by build_tiles_dataset.py + train_tiles.py
  2. VERDICT    (YOLOv8n-cls)  -- "is that tile damaged or okay?"
     trained by build_tiles_cls_dataset.py + train_tiles_cls.py

The detection stage is unchanged: every accepted detection is still printed as
    [TILE] conf=0.87  box=(x1,y1,x2,y2)  center=(cx,cy)
and, for each detected tile, its cropped region is passed to the classifier:
    [VERDICT] DAMAGED  conf=0.93   (box=...)
The classifier is optional -- if its weights are missing the node still detects
tiles, it just won't print a verdict.

The arm camera looks down at the floor; the same /top_camera topic the line
detector uses.
"""

import os
import time

import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data

from sensor_msgs.msg import Image
from std_msgs.msg import String

from cv_bridge import CvBridge, CvBridgeError
import cv2
from ultralytics import YOLO

from pkg_paths import p

TILE_MODEL     = p('runs/detect/tiles/weights/best.pt')
CLS_MODEL      = p('runs/classify/tiles_cls/weights/best.pt')
IMAGES_DIR     = p('inspection_images')
TILE_CONF      = 0.95   # strict: rejects weak background false positives
IMG_TOPIC      = '/top_camera/rgb/preview/image_raw'
INFER_PERIOD   = 0.2    # run YOLO at most 5 Hz to keep the node responsive


class DetectTiles(Node):
    def __init__(self):
        super().__init__('detect_tiles')

        self.declare_parameters(namespace='', parameters=[('device', 'cpu')])
        device_param = self.get_parameter('device').get_parameter_value().string_value
        self.device = device_param if device_param else 'cpu'

        self.bridge      = CvBridge()
        self.latest_bgr  = None   # newest decoded frame (set in callback)
        self._last_infer = 0.0    # wall-clock time of last YOLO inference

        weights = os.path.realpath(TILE_MODEL)
        if not os.path.exists(weights):
            self.get_logger().error(
                f'Tile model not found at {weights}. Train it first:\n'
                f'  /opt/ultralytics/bin/python3 scripts/build_tiles_dataset.py\n'
                f'  /opt/ultralytics/bin/python3 scripts/train_tiles.py')
            raise SystemExit(1)
        self.get_logger().info(f'Loading tile detection model: {weights}')
        self.model = YOLO(weights)
        self.get_logger().info('Tile detection model loaded.')

        self.cls_model = None
        cls_weights = os.path.realpath(CLS_MODEL)
        if os.path.exists(cls_weights):
            self.get_logger().info(f'Loading tile verdict model: {cls_weights}')
            self.cls_model = YOLO(cls_weights)
            self.get_logger().info('Tile verdict model loaded.')
        else:
            self.get_logger().warn(
                f'Verdict model not found at {cls_weights} — detection only. '
                f'Train it with scripts/build_tiles_cls_dataset.py + '
                f'scripts/train_tiles_cls.py')

        os.makedirs(IMAGES_DIR, exist_ok=True)
        self._tile_count = 0

        self.create_subscription(Image, IMG_TOPIC, self._img_cb,
                                 qos_profile_sensor_data)
        self.tile_pub      = self.create_publisher(String, '/detected_tiles', 10)
        self.results_pub   = self.create_publisher(String, '/tile_results',   10)

        # Timer drives both inference (throttled) and GUI event processing so
        # the window stays responsive even between inference runs.
        self.create_timer(INFER_PERIOD, self._infer_tick)

        cv2.namedWindow('Tile Detection', cv2.WINDOW_NORMAL)
        self.get_logger().info(f'DetectTiles ready on {IMG_TOPIC} '
                               f'(device={self.device}, max {1/INFER_PERIOD:.0f} Hz)')

    # ── image capture (just decode + store, never block here) ─────────────────

    def _img_cb(self, msg):
        try:
            self.latest_bgr = self.bridge.imgmsg_to_cv2(msg, 'bgr8')
        except CvBridgeError as e:
            self.get_logger().error(str(e))

    # ── inference tick (runs on timer, not in image callback) ─────────────────

    def _infer_tick(self):
        cv2.waitKey(1)   # keep the window responsive regardless of inference
        if self.latest_bgr is None:
            return

        bgr     = self.latest_bgr
        display = bgr.copy()

        res   = self.model.predict(bgr, conf=TILE_CONF, verbose=False,
                                   device=self.device)
        count = 0
        for r in res:
            for box in r.boxes:
                conf = float(box.conf[0])
                x1, y1, x2, y2 = map(int, box.xyxy[0])
                cx, cy = (x1 + x2) // 2, (y1 + y2) // 2
                count += 1

                print(f'[TILE] conf={conf:.2f}  box=({x1},{y1},{x2},{y2})  '
                      f'center=({cx},{cy})')

                crop = bgr[y1:y2, x1:x2]
                verdict, vconf = self._classify(crop)
                if verdict is not None:
                    print(f'[VERDICT] {verdict.upper()}  conf={vconf:.2f}  '
                          f'(box=({x1},{y1},{x2},{y2}))')

                self.tile_pub.publish(String(
                    data=f'{conf:.2f}|{x1}|{y1}|{x2}|{y2}|{cx}|{cy}|'
                         f'{verdict or "unknown"}|{vconf:.2f}'))

                self._tile_count += 1
                tid    = self._tile_count
                status = 'NOK' if verdict == 'damaged' else 'OK'
                score  = vconf if verdict is not None else conf
                img_path = os.path.join(IMAGES_DIR, f'tile_{tid}.jpg')
                if crop.size > 0:
                    cv2.imwrite(img_path, crop)
                self.results_pub.publish(String(
                    data=f'tile|{tid}|{status}|{score:.2f}|{img_path}|'))

                damaged = verdict == 'damaged'
                color   = (0, 0, 255) if damaged else (0, 220, 0)
                label   = f'{verdict} {vconf:.2f}' if verdict else f'tile {conf:.2f}'
                cv2.rectangle(display, (x1, y1), (x2, y2), color, 2)
                cv2.putText(display, label, (x1, max(y1 - 8, 12)),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2, cv2.LINE_AA)
                cv2.circle(display, (cx, cy), 4, color, -1)

        if count:
            self.get_logger().info(f'{count} tile(s) in view')

        cv2.imshow('Tile Detection', display)

    def _classify(self, crop):
        """Return (verdict, confidence) or (None, 0.0) if classifier unavailable."""
        if self.cls_model is None or crop.size == 0:
            return None, 0.0
        r       = self.cls_model.predict(crop, verbose=False, device=self.device)[0]
        verdict = r.names[int(r.probs.top1)]
        return verdict, float(r.probs.top1conf)


def main(args=None):
    rclpy.init(args=args)
    node = DetectTiles()
    try:
        rclpy.spin(node)
    finally:
        cv2.destroyAllWindows()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
