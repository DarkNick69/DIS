#!/usr/bin/env python3

import os

import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data, QoSReliabilityPolicy
from rclpy.duration import Duration as rclpyDuration
from rclpy.time import Time as rclpyTime

from sensor_msgs.msg import Image, PointCloud2
from sensor_msgs_py import point_cloud2 as pc2
from geometry_msgs.msg import PoseStamped, PointStamped
from visualization_msgs.msg import Marker
from std_msgs.msg import String

from cv_bridge import CvBridge, CvBridgeError
import cv2
import numpy as np
from ultralytics import YOLO
import tf2_ros
from collections import Counter

from pkg_paths import p

PERSON_MODEL  = p('yolov8n.pt')
# The AUGMENTED model generalises across all the trained faces. The
# non-augmented people_recognition model only recognises one identity reliably
# (everyone else comes back "unknown") — see gaj/branch, which uses this one.
RECOG_MODEL   = p('runs/detect/people_recognition_aug-2/weights/best.pt')

# Recognition runs on an upscaled head crop (see rgb_callback), so the face
# fills the frame like in the portrait training data regardless of distance.
# The threshold is deliberately low because temporal voting (pointcloud_callback)
# filters out the noise this lets through.
RECOG_CONF    = 0.25
RECOG_IMGSZ   = 416     # matches the training imgsz
HEAD_FRAC     = 0.45    # top fraction of the person box treated as the head
HEAD_PAD      = 0.15    # crop padding as a fraction of box size

# Temporal voting: a tracked position must accumulate this many sightings and
# have a clear non-Unknown majority before its identity is announced.
VOTE_MIN      = 3

# Role + gender lookup from personnel filenames (name → (role, gender))
# Gender comes from the pronouns embedded in the personnel photo filenames.
PERSONNEL = {
    'anita':  ('Quality Inspector', 'woman'),
    'anna':   ('Visitor',           'woman'),
    'david':  ('Welder',            'man'),
    'elena':  ('Forklift Driver',   'woman'),
    'felix':  ('Belt Technician',   'man'),
    'fred':   ('Visitor',           'man'),
    'jeff':   ('CTO',               'man'),
    'laura':  ('Middle Manager',    'woman'),
    'luka':   ('Accountant',        'man'),
    'maria':  ('Delivery Driver',   'woman'),
    'robert': ('Line Painter',      'man'),
    'sara':   ('Inventory Manager', 'woman'),
    'sofia':  ('Laser Calibrator',  'woman'),
    'victor': ('PLC Programmer',    'man'),
}


class DetectPeopleRecognition(Node):
    def __init__(self):
        super().__init__('detect_people_recognition')

        self.declare_parameters(namespace='', parameters=[('device', '')])
        self.device = self.get_parameter('device').get_parameter_value().string_value

        self.bridge = CvBridge()
        self.faces  = []

        self.tf_buffer   = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)

        self.person_model = YOLO(PERSON_MODEL)
        self.recog_model  = YOLO(RECOG_MODEL)
        self.get_logger().info(f'Recognition model loaded: {RECOG_MODEL}')

        # The arm stays looking down (robot_commander drives it), so recognition
        # runs on the forward oakd camera, which sees people as the robot drives
        # straight up to them.
        self._arm_ready   = True

        # Forward oakd camera — used for both detection and recognition
        self.rgb_sub = self.create_subscription(
            Image, '/oakd/rgb/preview/image_raw',
            self.rgb_callback, qos_profile_sensor_data)
        self.pc_sub = self.create_subscription(
            PointCloud2, '/oakd/rgb/preview/depth/points',
            self.pointcloud_callback, qos_profile_sensor_data)

        self.marker_pub   = self.create_publisher(Marker,      '/people_marker',        QoSReliabilityPolicy.BEST_EFFORT)
        self.pose_pub     = self.create_publisher(PoseStamped, '/detected_people_pose',  10)
        self.identity_pub = self.create_publisher(String,      '/identified_people',     10)
        # The currently-visible recognised person, published every RGB frame
        # (name|role|gender|conf), independent of depth. Lets a consumer standing
        # in front of the person read the identity even at point-blank range where
        # the depth-based /identified_people never fires.
        self.current_pub  = self.create_publisher(String,      '/recognized_person',     10)

        # Each tracked position accumulates per-frame recognition votes; an
        # identity is only announced once it wins a clear majority over several
        # sightings. Each entry is a dict:
        #   {x, y, z, votes: Counter(name->count), announced: bool}
        self.tracked_people         = []
        self.published_identities   = set()
        self.people_dedup_distance  = 0.5
        self._pc_seq                = 0   # frame counter for "most recent" track

        cv2.namedWindow('People Recognition', cv2.WINDOW_NORMAL)
        self.get_logger().info('DetectPeopleRecognition ready.')

    # ------------------------------------------------------------------
    # RGB callback
    # ------------------------------------------------------------------

    def rgb_callback(self, data):
        if not self._arm_ready:
            return
        self.faces = []
        try:
            bgr     = self.bridge.imgmsg_to_cv2(data, 'bgr8')
            display = bgr.copy()

            # Stage 1: detect people (full body)
            person_res = self.person_model.predict(bgr, imgsz=(256, 320),
                                                   show=False, verbose=False,
                                                   classes=[0], device=self.device)
            yolo_boxes = []
            for r in person_res:
                for box in r.boxes.xyxy:
                    x1, y1, x2, y2 = map(int, box)
                    yolo_boxes.append((x1, y1, x2, y2))

            if not yolo_boxes:
                cv2.imshow('People Recognition', display)
                cv2.waitKey(1)
                return

            H, W = bgr.shape[:2]

            # Stage 2: recognise each detected person individually. The model was
            # trained on portrait crops where the face fills the frame, so we crop
            # the head region, upscale it, and run recognition on that — this makes
            # recognition work at a distance instead of only point-blank.
            best_person = None   # (name, role, gender, conf) — best in this frame
            for (x1, y1, x2, y2) in yolo_boxes:
                cx = (x1 + x2) // 2
                cy = (y1 + y2) // 2

                bw, bh = x2 - x1, y2 - y1
                padx = int(HEAD_PAD * bw)
                pady = int(HEAD_PAD * bh)
                fx1 = max(x1 - padx, 0)
                fy1 = max(y1 - pady, 0)
                fx2 = min(x2 + padx, W)
                fy2 = min(y1 + int(HEAD_FRAC * bh) + pady, H)   # top portion = head
                crop = bgr[fy1:fy2, fx1:fx2]

                matched_name, matched_conf = None, 0.0
                if crop.size:
                    crop_up = cv2.resize(crop, (RECOG_IMGSZ, RECOG_IMGSZ),
                                         interpolation=cv2.INTER_CUBIC)
                    rr = self.recog_model.predict(crop_up, conf=RECOG_CONF,
                                                  imgsz=RECOG_IMGSZ, show=False,
                                                  verbose=False, device=self.device)
                    for r in rr:
                        for box in r.boxes:
                            c = float(box.conf[0])
                            if c > matched_conf:
                                matched_conf = c
                                matched_name = r.names[int(box.cls[0])]

                role, gender = PERSONNEL.get(matched_name, ('', '')) if matched_name \
                    else ('', '')
                self.faces.append((cx, cy, matched_name or 'Unknown', role, gender))

                if matched_name:
                    label = f'{matched_name.capitalize()} ({role})'
                    color = (0, 220, 0)
                    print(f'[PERSON] {label}  conf={matched_conf:.2f}')
                    if best_person is None or matched_conf > best_person[3]:
                        best_person = (matched_name, role, gender, matched_conf)
                else:
                    label = 'Unknown'
                    color = (0, 0, 255)

                cv2.rectangle(display, (x1, y1), (x2, y2), color, 2)
                cv2.putText(display, label, (x1, max(y1 - 8, 10)),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.55, color, 2, cv2.LINE_AA)
                cv2.circle(display, (cx, cy), 5, color, -1)

            # Publish the best recognised person this frame (depth-independent).
            if best_person is not None:
                name, role, gender, conf = best_person
                self.current_pub.publish(
                    String(data=f'{name}|{role}|{gender}|{conf:.2f}'))

            cv2.imshow('People Recognition', display)
            cv2.waitKey(1)

        except CvBridgeError as e:
            self.get_logger().error(str(e))

    # ------------------------------------------------------------------
    # Point cloud callback
    # ------------------------------------------------------------------

    def _to_map(self, d, header):
        """Transform a camera-frame point into the map frame. None on TF failure."""
        pt              = PointStamped()
        pt.header       = header
        pt.header.stamp = rclpyTime().to_msg()
        pt.point.x      = float(d[0])
        pt.point.y      = float(d[1])
        pt.point.z      = float(d[2])
        try:
            pm = self.tf_buffer.transform(pt, 'map',
                                          timeout=rclpyDuration(seconds=0.3))
            return (pm.point.x, pm.point.y, pm.point.z)
        except Exception:
            return None

    def pointcloud_callback(self, data):
        if data.height == 0 or data.width == 0:
            return

        a = pc2.read_points_numpy(data, field_names=('x', 'y', 'z'))
        a = a.reshape((data.height, data.width, 3))
        self._pc_seq += 1

        for (cx, cy, name, role, gender) in self.faces:
            # Map position is best-effort: at very close range the depth camera
            # often returns no valid point (person below its minimum range), so
            # pos_map can be None — but we still want to vote and announce.
            pos_map = None
            if 0 <= cx < data.width and 0 <= cy < data.height:
                d = a[cy, cx, :]
                if np.isfinite(d).all():
                    pos_map = self._to_map(d, data.header)

            # Pick the track for this person. With a position we match by location;
            # without one (too close for depth) we fall back to the most recently
            # updated track — i.e. the person we're standing right in front of.
            track = None
            if pos_map is not None:
                mx, my, mz = pos_map
                for t in self.tracked_people:
                    if np.hypot(mx - t['x'], my - t['y']) < self.people_dedup_distance:
                        track = t
                        break
                if track is None:
                    track = {'x': mx, 'y': my, 'z': mz, 'votes': Counter(),
                             'announced': False, 'seq': self._pc_seq}
                    self.tracked_people.append(track)
                else:
                    track['x'], track['y'], track['z'] = mx, my, mz   # refresh
            elif self.tracked_people:
                track = max(self.tracked_people, key=lambda t: t['seq'])

            if track is None:
                continue   # no depth yet and nothing tracked — can't place them
            track['seq'] = self._pc_seq

            # Vote on EVERY recognised frame, regardless of depth. This is the key
            # fix: recognition only firms up at close range, exactly where depth
            # tends to drop out, so gating votes on depth meant the identity was
            # never announced even though the camera clearly recognised the person.
            if name != 'Unknown':
                track['votes'][name] += 1

            # Majority vote decides the identity; announce once it has a clear,
            # repeated winner (filters single-frame misreads at the low threshold).
            name = 'Unknown'
            if track['votes']:
                win_name, win_count = track['votes'].most_common(1)[0]
                if win_count >= VOTE_MIN:
                    name = win_name
                    role, gender = PERSONNEL.get(name, ('', ''))

            if name != 'Unknown' and not track['announced'] \
                    and name not in self.published_identities:
                track['announced'] = True
                self.published_identities.add(name)
                msg = (f'{name}|{role}|{gender}|'
                       f'{track["x"]:.3f}|{track["y"]:.3f}|{track["z"]:.3f}')
                self.get_logger().info(f'[IDENTIFIED] {name} ({role}, {gender}) '
                                       f'at map ({track["x"]:.2f}, {track["y"]:.2f})')
                self.identity_pub.publish(String(data=msg))

            # Markers and pose need a fresh map position — skip them when too close.
            if pos_map is None:
                continue
            mx, my, mz = track['x'], track['y'], track['z']
            idx = self.tracked_people.index(track)

            marker = Marker()
            marker.header.frame_id    = 'map'
            marker.header.stamp       = data.header.stamp
            marker.type               = Marker.SPHERE
            marker.id                 = idx
            marker.ns                 = 'people'
            marker.scale.x = marker.scale.y = marker.scale.z = 0.3
            marker.color.r = 0.0 if name != 'Unknown' else 1.0
            marker.color.g = 1.0 if name != 'Unknown' else 0.0
            marker.color.b = 0.0
            marker.color.a = 1.0
            marker.pose.position.x = mx
            marker.pose.position.y = my
            marker.pose.position.z = mz
            self.marker_pub.publish(marker)

            if name != 'Unknown':
                label = Marker()
                label.header             = marker.header
                label.ns                 = 'people_label'
                label.id                 = idx
                label.type               = Marker.TEXT_VIEW_FACING
                label.scale.z            = 0.18
                label.color.r = label.color.g = label.color.b = label.color.a = 1.0
                label.pose.position.x    = mx
                label.pose.position.y    = my
                label.pose.position.z    = mz + 0.4
                label.pose.orientation.w = 1.0
                label.text               = f'{name.capitalize()}\n{role}'
                self.marker_pub.publish(label)

            pose = PoseStamped()
            pose.header.frame_id    = 'map'
            pose.header.stamp       = data.header.stamp
            pose.pose.position.x    = mx
            pose.pose.position.y    = my
            pose.pose.position.z    = mz
            pose.pose.orientation.w = 1.0
            self.pose_pub.publish(pose)


def main():
    rclpy.init(args=None)
    node = DetectPeopleRecognition()
    try:
        rclpy.spin(node)
    finally:
        cv2.destroyAllWindows()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
