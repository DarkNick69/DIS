#!/usr/bin/env python3
"""Shared waypoint-sweep inspection engine (base class).

`inspect_rings.py` and `inspect_barrels.py` both drive the robot through every
waypoint *except the last* (the last one initialises blue-line following) while
the always-running detector node (`detect_rings.py` / `detect_barrels.py`)
finds objects and publishes them. This base class:

  * drives the route with its own Nav2 action client,
  * does a slow in-place scan at each waypoint so objects beside the path (not
    just straight ahead) are seen,
  * collects everything the detector publishes on `detection_topic` *during*
    the sweep, and
  * at the end asks the concrete subclass to `summarize()` the findings, which
    it speaks and logs.

It follows the same self-enclosed protocol as the belt tasks, so
`robot_commander` can just trigger it and block until done:

    subscribe  <start_topic>      std_msgs/Empty    → run the sweep
    subscribe  <detection_topic>  std_msgs/String   → findings (collected)
    publish    <done_topic>       std_msgs/Empty    → signal completion

The commander is blocked (only spinning) while the sweep runs, so the two never
send Nav2 goals at the same time.
"""

import math
import time

import rclpy
from rclpy.action import ActionClient
from rclpy.node import Node

from action_msgs.msg import GoalStatus
from geometry_msgs.msg import PoseStamped, Quaternion, TwistStamped
from nav2_msgs.action import NavigateToPose
from std_msgs.msg import Empty, String
from turtle_tf2_py.turtle_tf2_broadcaster import quaternion_from_euler

from robot_commander import load_waypoints, WAYPOINTS_FILE


class SweepInspector(Node):

    SCAN_SPEED  = 0.7    # rad/s — in-place scan rotation speed
    SCAN_ENABLE = True   # rotate 360° at each waypoint to see objects to the side
    SETTLE_TIME = 1.0    # s — extra dwell so the detector can confirm a view

    def __init__(self, name, start_topic, done_topic, label, detection_topic,
                 waypoints_file=WAYPOINTS_FILE):
        super().__init__(name)
        self.label = label
        # Each task drives its own waypoint file (already excludes the final
        # blue-line waypoint), so the route is dedicated to this inspection.
        self.waypoints_file = waypoints_file

        self.done_pub = self.create_publisher(Empty, done_topic, 10)
        self.say_pub  = self.create_publisher(String, '/robot_say', 10)
        self.cmd_pub  = self.create_publisher(TwistStamped, 'cmd_vel', 10)
        self.create_subscription(Empty, start_topic, self._start_cb, 10)
        self.create_subscription(String, detection_topic, self._detection_cb, 10)
        self.nav_client = ActionClient(self, NavigateToPose, 'navigate_to_pose')

        self._busy       = False
        self._pending    = False
        self._collecting = False
        self.detections  = []   # detector strings collected during the sweep

        self.get_logger().info(
            f'{name} ready — waiting for {start_topic} '
            f'(listening on {detection_topic}).')

    # ── task entry point ────────────────────────────────────────────────────

    def _start_cb(self, _msg):
        # Only flag the request. The sweep itself runs from the main loop (see
        # run_pending), NOT here — calling the blocking Nav2 spins from inside a
        # subscription callback raises "Executor is already spinning".
        if self._busy:
            self.get_logger().warn('Sweep already running; ignoring request.')
            return
        self._pending = True

    def run_pending(self):
        """Run a queued sweep, if any. Call this from the main spin loop so the
        blocking navigation does not re-enter the executor."""
        if not self._pending or self._busy:
            return
        self._pending = False
        self._busy = True
        try:
            self._run_sweep()
        except Exception as e:
            self.get_logger().error(f'[{self.label}] sweep failed: {e}')
        finally:
            self._busy = False
            self.done_pub.publish(Empty())   # always release the commander

    def _detection_cb(self, msg):
        # The detector dedups, so every message is a NEW unique detection.
        if self._collecting and msg.data:
            self.detections.append(msg.data)
            self.get_logger().info(
                f'[{self.label}] new {self.label} #{len(self.detections)}: '
                f'{self.describe(msg.data)}')

    def describe(self, detection):
        """One-line description of a single detection (override per task)."""
        return detection

    def _run_sweep(self):
        pts = load_waypoints(self.waypoints_file)
        if not pts:
            self.get_logger().error(f'No waypoints in {self.waypoints_file}.')
            return

        # Make sure Nav2 is actually reachable before we start firing goals —
        # otherwise every goal is rejected and the sweep "finishes" instantly.
        self.get_logger().info(
            f'[{self.label}] sweep starting over {len(pts)} waypoints; '
            'waiting for Nav2 action server...')
        if not self.nav_client.wait_for_server(timeout_sec=20.0):
            self.get_logger().error(
                f'[{self.label}] navigate_to_pose server not available — '
                'aborting sweep (robot will not move).')
            return

        self.detections  = []
        self._collecting = True
        self.say_pub.publish(String(data=f'Starting {self.label} inspection.'))

        n = len(pts)
        reached = 0
        for i, (x, y) in enumerate(pts):
            nx, ny = pts[(i + 1) % n]
            yaw = math.atan2(ny - y, nx - x) if n > 1 else 0.0
            self.get_logger().info(
                f'[{self.label}] waypoint {i + 1}/{n} → ({x:.2f}, {y:.2f})')
            if self._nav_to(x, y, yaw):
                reached += 1
            self._scan()

        self.get_logger().info(
            f'[{self.label}] route done: reached {reached}/{n} waypoints.')
        self._collecting = False
        summary = self.summarize(self.detections)
        self.get_logger().info(f'[{self.label}] {summary}')
        self.say_pub.publish(String(data=summary))

    # ── findings summary (override per task) ──────────────────────────────────

    def summarize(self, detections):
        """Return a spoken-summary string for the findings. Subclasses override
        with task-specific wording; this default just counts."""
        return (f'{self.label.capitalize()} inspection complete. '
                f'Found {len(detections)} detections.')

    @staticmethod
    def _field(text, key):
        """Pull `key=value` from a detector string, else None."""
        for tok in text.replace('  ', ' ').split():
            if tok.startswith(key + '='):
                return tok.split('=', 1)[1]
        return None

    # ── navigation ────────────────────────────────────────────────────────────

    def _nav_to(self, x, y, yaw):
        """Send a blocking NavigateToPose goal. Returns True if it succeeded."""
        if not self.nav_client.wait_for_server(timeout_sec=5.0):
            self.get_logger().warn(
                f'[{self.label}] navigate_to_pose unavailable for '
                f'({x:.2f}, {y:.2f}); skipping.')
            return False

        pose = PoseStamped()
        pose.header.frame_id  = 'map'
        pose.header.stamp     = self.get_clock().now().to_msg()
        pose.pose.position.x  = float(x)
        pose.pose.position.y  = float(y)
        q = quaternion_from_euler(0, 0, yaw)
        pose.pose.orientation = Quaternion(x=q[0], y=q[1], z=q[2], w=q[3])

        goal = NavigateToPose.Goal()
        goal.pose = pose
        send = self.nav_client.send_goal_async(goal)
        rclpy.spin_until_future_complete(self, send)
        handle = send.result()
        if handle is None or not handle.accepted:
            self.get_logger().warn(
                f'[{self.label}] goal ({x:.2f}, {y:.2f}) REJECTED by Nav2.')
            return False

        result_future = handle.get_result_async()
        rclpy.spin_until_future_complete(self, result_future)
        status = result_future.result().status if result_future.result() else None
        if status != GoalStatus.STATUS_SUCCEEDED:
            self.get_logger().warn(
                f'[{self.label}] goal ({x:.2f}, {y:.2f}) ended status={status}.')
            return False
        return True

    def _scan(self):
        """Slow in-place 360° rotation so the forward camera sweeps objects to
        the sides of the path, then a short settle. Detections keep arriving on
        the detection topic while we spin (we keep spinning the node)."""
        if not self.SCAN_ENABLE:
            self._settle(self.SETTLE_TIME)
            return
        end = time.time() + (2 * math.pi / self.SCAN_SPEED)
        while rclpy.ok() and time.time() < end:
            self._rotate(self.SCAN_SPEED)
            rclpy.spin_once(self, timeout_sec=0.05)
        self._rotate(0.0)
        self._settle(self.SETTLE_TIME)

    def _rotate(self, wz):
        msg = TwistStamped()
        msg.header.stamp    = self.get_clock().now().to_msg()
        msg.twist.angular.z = float(wz)
        self.cmd_pub.publish(msg)

    def _settle(self, seconds):
        end = time.time() + seconds
        while rclpy.ok() and time.time() < end:
            rclpy.spin_once(self, timeout_sec=0.05)


def spin_inspector(node):
    """Spin loop for an inspector node. The triggered sweep runs OUTSIDE the
    callback (via run_pending) so its blocking Nav2 calls never nest a spin
    inside the executor."""
    try:
        while rclpy.ok():
            rclpy.spin_once(node, timeout_sec=0.1)
            node.run_pending()
    except KeyboardInterrupt:
        pass
