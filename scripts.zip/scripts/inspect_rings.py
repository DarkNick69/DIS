#!/usr/bin/env python3
"""Ring inspection — self-enclosed waypoint sweep.

Drives through every waypoint except the last (the last initialises blue-line
following), scanning at each, while `detect_rings.py` finds rings and publishes
them on `/ring_detections` as:

    [RING] color=<color>  pos=(x,y)

This node collects those during the sweep and reports a colour breakdown.

    subscribe  /inspect_rings     std_msgs/Empty    → run the sweep
    subscribe  /ring_detections   std_msgs/String   → findings (collected)
    publish    /rings_done         std_msgs/Empty    → signal completion
"""

from collections import Counter

import rclpy

from pkg_paths import p
from sweep_inspector import SweepInspector, spin_inspector


class RingInspector(SweepInspector):
    def __init__(self):
        super().__init__('ring_inspector', '/inspect_rings', '/rings_done',
                         'ring', '/ring_detections',
                         waypoints_file=p('waypoints_rings.txt'))

    def describe(self, detection):
        color = self._field(detection, 'color') or 'unknown'
        pos = self._field(detection, 'pos') or '(?)'
        return f'{color} at {pos}'

    def summarize(self, detections):
        colors = [self._field(d, 'color') or 'unknown' for d in detections]
        n = len(colors)
        if n == 0:
            return 'Ring inspection complete. I did not find any rings.'
        breakdown = ', '.join(f'{cnt} {col}' for col, cnt in
                              Counter(colors).most_common())
        plural = 'ring' if n == 1 else 'rings'
        return f'Ring inspection complete. I found {n} {plural}: {breakdown}.'


def main(args=None):
    rclpy.init(args=args)
    node = RingInspector()
    try:
        spin_inspector(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
