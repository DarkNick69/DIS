#!/usr/bin/env python3
"""Resolve absolute paths inside the task2-new package, wherever scripts run from.

Works with `colcon build --symlink-install` (install scripts symlink back to the
source tree, so __file__ resolves into source) and falls back to the known source
path for a plain (non-symlink) build.
"""

import os

_HERE = os.path.dirname(os.path.realpath(__file__))
PKG_ROOT = os.path.dirname(_HERE)

# If we resolved into install/ (non-symlink build), fall back to the source tree.
if not os.path.isdir(os.path.join(PKG_ROOT, 'scripts')):
    _FALLBACK = '/home/xi/colcon_ws/src/task2-new'
    if os.path.isdir(_FALLBACK):
        PKG_ROOT = _FALLBACK


def p(*parts):
    """Join `parts` onto the package root → absolute path."""
    return os.path.join(PKG_ROOT, *parts)
