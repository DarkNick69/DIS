#!/usr/bin/env python3
"""Train YOLOv8n on the AUGMENTED barrel dataset.

Mirrors the face-recognition recipe (build_people_dataset.py + 120-epoch train):
first run build_barrels_dataset.py to create barrels_dataset_aug, then this.

⚠️  EMPIRICAL NOTE — the augmentation recipe that helped faces HURTS barrels.
    Faces are one upscaled portrait per identity, so synthetic variety helps.
    Barrels already have 122 varied real scene images with correct boxes; heavy
    offline augmentation dilutes the clean-detection signal and collapses recall.
    On the held-out CLEAN test set:
        barrel_run (no aug) : mAP50 0.995 / mAP50-95 0.951 / recall 1.00
        barrels_aug (aug)   : mAP50 0.49  / mAP50-95 0.46  / recall 0.31
    detect_barrels.py therefore stays on barrel_run/weights/best.pt. Keep this
    script for reference / future experiments, not as the active model.

Run with the ultralytics venv:
    /opt/ultralytics/bin/python3 scripts/build_barrels_dataset.py
    /opt/ultralytics/bin/python3 scripts/train_barrels.py
"""

import os
from ultralytics import YOLO

ROOT = '/home/xi/colcon_ws/src/task2-new'
# Prefer the augmented dataset; fall back to the raw Roboflow export.
AUG  = os.path.join(ROOT, 'barrels_dataset_aug', 'data.yaml')
RAW  = os.path.join(ROOT, 'barrels_dataset', 'data.yaml')
DATA = AUG if os.path.isfile(AUG) else RAW
OUT  = os.path.join(ROOT, 'barrels_dataset')

model = YOLO('yolov8n.pt')
results = model.train(
    data=DATA,
    epochs=120,
    imgsz=640,
    batch=16,
    patience=100,
    project=OUT,
    name='barrels_aug',
    exist_ok=True,
    verbose=True,
    # Online augmentation (transforms boxes correctly); offline pass adds
    # photometric/​distance robustness on top.
    degrees=0.0,
    translate=0.1,
    scale=0.5,
    fliplr=0.5,
    mosaic=1.0,
    mixup=0.0,
)

print(f'\nDone — weights: {OUT}/barrels_aug/weights/best.pt')
