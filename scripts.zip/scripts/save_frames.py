#!/usr/bin/env python3
"""
Save camera frames to disk for YOLO training data collection.
Run this while driving the robot around the barrels in room 1.

Usage:
    ros2 run dis_tutorial7 save_frames.py

Images are saved to ~/barrel_frames/ every N frames.
Press Ctrl+C when done.
"""

import os
import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
import cv2

SAVE_DIR    = os.path.expanduser('~/barrel_frames')
EVERY_N     = 8   # save 1 out of every N frames (~3 fps at 25 fps camera)


class FrameSaver(Node):
    def __init__(self):
        super().__init__('frame_saver')
        os.makedirs(SAVE_DIR, exist_ok=True)

        self.bridge   = CvBridge()
        self.counter  = 0
        self.saved    = 0

        self.create_subscription(
            Image, '/oakd/rgb/preview/image_raw',
            self.callback, qos_profile_sensor_data)

        self.get_logger().info(
            f'Saving every {EVERY_N}th frame to {SAVE_DIR}  — drive around the barrels!')

    def callback(self, msg):
        self.counter += 1
        if self.counter % EVERY_N != 0:
            return
        try:
            img = self.bridge.imgmsg_to_cv2(msg, 'bgr8')
        except CvBridgeError as e:
            self.get_logger().error(str(e))
            return

        path = os.path.join(SAVE_DIR, f'frame_{self.saved:05d}.jpg')
        cv2.imwrite(path, img)
        self.saved += 1

        # Preview so you can see what's being captured
        cv2.imshow('Collecting — press Q to quit', img)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            self.get_logger().info(f'Stopped. Saved {self.saved} images to {SAVE_DIR}')
            cv2.destroyAllWindows()
            raise SystemExit

        if self.saved % 20 == 0:
            self.get_logger().info(f'{self.saved} images saved to {SAVE_DIR}')


def main():
    rclpy.init()
    node = FrameSaver()
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, SystemExit):
        pass
    finally:
        cv2.destroyAllWindows()
        node.get_logger().info(
            f'Done. Total saved: {node.saved} images in {SAVE_DIR}')
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
