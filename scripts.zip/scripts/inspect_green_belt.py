#!/usr/bin/env python3
"""Green-belt inspection node.

Protocol with robot_commander (keep these topics):
    subscribe  /inspect_green_belt  std_msgs/Empty   → start inspecting
    publish    /green_belt_done      std_msgs/Empty   → signal completion

Implementation ported from gaj/branch:scripts/task_green.py.
Patrols waypoints_green.txt until the green floor line is found, follows it
end-to-end (including arm raise), then reports done.
"""

COLOR = 'green'

import math
import os
import time
from enum import Enum

from action_msgs.msg import GoalStatus
from geometry_msgs.msg import (Quaternion, PointStamped, PoseStamped,
                               PoseWithCovarianceStamped, TwistStamped)
from visualization_msgs.msg import Marker
from nav2_msgs.action import NavigateToPose
from turtle_tf2_py.turtle_tf2_broadcaster import quaternion_from_euler
from sensor_msgs.msg import JointState
from std_msgs.msg import Bool, Empty, Float64, String

import rclpy
from rclpy.action import ActionClient
from rclpy.node import Node
from rclpy.qos import (
    QoSDurabilityPolicy, QoSHistoryPolicy,
    QoSProfile, QoSReliabilityPolicy, qos_profile_sensor_data,
)

from pkg_paths import p

WAYPOINTS_FILE = p('waypoints_green.txt')

ARM_JOINTS        = ['arm_base_joint', 'arm_shoulder_joint',
                     'arm_elbow_joint', 'arm_wrist_joint']
LOOK_AT_BELT_LEFT = [1.57, 0.9, 0.3, 1.7]

amcl_qos = QoSProfile(
    durability=QoSDurabilityPolicy.TRANSIENT_LOCAL,
    reliability=QoSReliabilityPolicy.RELIABLE,
    history=QoSHistoryPolicy.KEEP_LAST,
    depth=1,
)


class Mode(Enum):
    WAYPOINTS    = 0
    INSPECT_LINE = 1


def load_waypoints(path):
    if not os.path.isfile(path):
        return []
    pts = []
    x = y = None
    in_point = False
    with open(path) as f:
        for line in f:
            s = line.strip()
            if s.startswith('point:'):
                in_point, x, y = True, None, None
            elif in_point and s.startswith('x:'):
                x = float(s.split(':', 1)[1])
            elif in_point and s.startswith('y:'):
                y = float(s.split(':', 1)[1])
            elif in_point and s.startswith('z:'):
                if x is not None and y is not None:
                    pts.append((x, y))
                in_point = False
    return pts


class GreenBeltInspector(Node):

    def __init__(self):
        super().__init__('green_belt_inspector')

        self.pose_frame_id         = 'map'
        self.goal_handle           = None
        self.result_future         = None
        self.status                = None
        self.initial_pose_received = False
        self.current_pose          = None

        self.line_detected   = False
        self.line_cx         = -1.0
        self.yellow_detected = False
        self._log_times      = {}
        self.joint_pos       = {}

        self.create_subscription(PoseWithCovarianceStamped, 'amcl_pose',
                                 self._amcl_cb, amcl_qos)
        self.create_subscription(Bool, f'/{COLOR}_line_detected',
                                 self._line_detected_cb, 10)
        self.create_subscription(Float64, f'/{COLOR}_line_cx',
                                 self._line_cx_cb, 10)
        self.create_subscription(Bool, '/yellow_line_detected',
                                 self._yellow_detected_cb, 10)
        self.create_subscription(JointState, '/joint_states',
                                 self._joint_cb, qos_profile_sensor_data)
        self.create_subscription(String, '/detected_tiles',
                                 self._tile_cb, 10)
        self.tile_detections = []

        self.arm_pub       = self.create_publisher(String, '/arm_command', 10)
        self.cmd_vel_pub   = self.create_publisher(TwistStamped, 'cmd_vel', 10)
        self.say_pub       = self.create_publisher(String, '/robot_say', 10)
        self.end1_pub      = self.create_publisher(PointStamped,
                                                   '/inspection_end1', amcl_qos)
        self.end1_marker_pub = self.create_publisher(Marker,
                                                     '/inspection_end1_marker', amcl_qos)
        self.done_pub      = self.create_publisher(Empty, '/green_belt_done', 10)
        self.nav_client    = ActionClient(self, NavigateToPose, 'navigate_to_pose')

        self._pending = False
        self._busy    = False

        self.create_subscription(Empty, '/inspect_green_belt', self._start_cb, 10)
        self.get_logger().info('GreenBeltInspector ready — waiting for /inspect_green_belt.')

    # ── trigger ───────────────────────────────────────────────────────────────

    def _start_cb(self, _msg):
        if self._busy or self._pending:
            self.warn('Belt inspection already running; ignoring request.')
            return
        self._pending = True

    def run_pending(self):
        if not self._pending or self._busy:
            return
        self._pending = False
        self._busy    = True
        try:
            self._run_mission()
        except Exception as e:
            self.error(f'Belt inspection failed: {e}')
        finally:
            self._busy = False
            self.done_pub.publish(Empty())

    # ── mission ───────────────────────────────────────────────────────────────

    def _run_mission(self):
        self.tile_detections = []
        self.setArm('look_down')

        waypoints_xy = load_waypoints(WAYPOINTS_FILE)
        if not waypoints_xy:
            self.error(f'No waypoints in {WAYPOINTS_FILE}. Aborting.')
            return
        self.info(f'Loaded {len(waypoints_xy)} waypoints from {WAYPOINTS_FILE}.')

        waypoints = []
        n = len(waypoints_xy)
        for i, (x, y) in enumerate(waypoints_xy):
            nx, ny = waypoints_xy[(i + 1) % n]
            yaw = math.atan2(ny - y, nx - x) if n > 1 else 0.0
            waypoints.append(self.buildPose(x, y, yaw))

        TURN_SPEED      = 0.5
        LINE_SIDE_CX    = 0.30
        SIDE_RIGHT_CX   = 0.70
        SIDE_SPEED      = 0.12
        SIDE_KP         = 1.2
        SIDE_MAX_ANG    = 0.6
        YELLOW_GRACE    = 2.0
        CREEP_PAST_TIME = 3.5
        TURN_180_TIME   = (math.pi / TURN_SPEED) + 0.3
        TURN_MIN_TIME   = (math.pi / 2) / TURN_SPEED
        TURN_MAX_TIME   = TURN_180_TIME + 30.0
        LINE_LEFT_LO    = 0.31
        LINE_LEFT_HI    = 0.34
        ARM_SETTLE_TOUT = 10.0
        RETURN_SPEED    = 0.15
        RETURN_YAW_KP   = 1.2
        RETURN_TOL      = 0.35
        RETURN_NEAR     = 1.0
        RETURN_PASS     = 0.15
        RETURN_EXTRA    = 6.0
        SCAN_SPEED      = 0.5                              # rad/s in-place search
        SCAN_TIME       = (2 * math.pi / SCAN_SPEED) + 1.0  # one full turn + margin

        wp_index    = 0
        goal_active = False
        scanning    = False
        scan_end    = 0.0
        mode        = Mode.WAYPOINTS

        inspect_phase         = 'follow_left'
        follow_grace          = 0.0
        line_creep_deadline   = 0.0
        turn_start            = 0.0
        end1_pose             = None
        arm_settle_deadline   = 0.0
        return_best_dist      = float('inf')
        return_creep_deadline = 0.0

        self.info(f'Starting waypoint patrol, looking for a {COLOR.upper()} line.')

        while rclpy.ok():
            rclpy.spin_once(self, timeout_sec=0.05)
            now = time.time()

            if mode == Mode.WAYPOINTS and self.line_detected:
                self.info(f'[LINE] {COLOR.upper()} line detected — following on left.')
                if goal_active:
                    self.cancelTask()
                    self._wait_for_task()
                    goal_active = False
                scanning = False
                self.stopRobot()
                inspect_phase = 'follow_left'
                follow_grace  = now + YELLOW_GRACE
                mode = Mode.INSPECT_LINE
                continue

            if mode == Mode.INSPECT_LINE:
                line_det = self.line_detected
                line_cx  = self.line_cx

                if inspect_phase == 'follow_left':
                    if now > follow_grace and self.yellow_detected:
                        self.info('[LINE] YELLOW reached (end 1) — creeping forward.')
                        inspect_phase       = 'creep1'
                        line_creep_deadline = now + CREEP_PAST_TIME
                        continue
                    if line_det and line_cx >= 0.0:
                        ang = SIDE_KP * (LINE_SIDE_CX - line_cx)
                        ang = max(-SIDE_MAX_ANG, min(SIDE_MAX_ANG, ang))
                        self.info_throttle('side_l',
                                           f'[LINE] Following {COLOR} on left '
                                           f'(cx={line_cx:.2f}).')
                        self.publishVelocity(SIDE_SPEED, ang)
                    else:
                        self.info_throttle('side_l_lost',
                                           '[LINE] Line out of view — creeping straight.')
                        self.publishVelocity(SIDE_SPEED, 0.0)
                    continue

                if inspect_phase == 'creep1':
                    if now < line_creep_deadline:
                        self.info_throttle('creep1', '[LINE] Creeping past end 1...')
                        self.publishVelocity(SIDE_SPEED, 0.0)
                    else:
                        self.stopRobot()
                        if self.current_pose is not None:
                            end1_pose = self.buildPose(
                                self.current_pose.position.x,
                                self.current_pose.position.y,
                                orientation=self.current_pose.orientation)
                            self.publishEnd1(end1_pose.pose.position.x,
                                             end1_pose.pose.position.y)
                            self.info(f'[LINE] End 1 at '
                                      f'({end1_pose.pose.position.x:.2f}, '
                                      f'{end1_pose.pose.position.y:.2f}).')
                        self.info('[LINE] End 1 reached — turning RIGHT.')
                        inspect_phase = 'turn1'
                        turn_start    = now
                    continue

                if inspect_phase == 'turn1':
                    elapsed  = now - turn_start
                    on_right = line_det and line_cx >= SIDE_RIGHT_CX
                    if elapsed > TURN_MIN_TIME and (on_right or elapsed > TURN_MAX_TIME):
                        self.stopRobot()
                        if on_right:
                            self.info(f'[LINE] {COLOR} on right (cx={line_cx:.2f}) — '
                                      f'following to end 2.')
                        else:
                            self.warn('[LINE] Line not on right — timed out; '
                                      'following anyway.')
                        inspect_phase = 'follow_right'
                        follow_grace  = now + YELLOW_GRACE
                    else:
                        self.info_throttle('turn1', '[LINE] Turning right...')
                        self.publishVelocity(0.0, -TURN_SPEED)
                    continue

                if inspect_phase == 'follow_right':
                    if now > follow_grace and self.yellow_detected:
                        self.info('[LINE] YELLOW reached (end 2) — creeping forward.')
                        inspect_phase       = 'creep2'
                        line_creep_deadline = now + CREEP_PAST_TIME
                        continue
                    if line_det and line_cx >= 0.0:
                        ang = SIDE_KP * (SIDE_RIGHT_CX - line_cx)
                        ang = max(-SIDE_MAX_ANG, min(SIDE_MAX_ANG, ang))
                        self.info_throttle('side_r',
                                           f'[LINE] Following {COLOR} on right '
                                           f'(cx={line_cx:.2f}).')
                        self.publishVelocity(SIDE_SPEED, ang)
                    else:
                        self.info_throttle('side_r_lost',
                                           '[LINE] Line out of view — creeping straight.')
                        self.publishVelocity(SIDE_SPEED, 0.0)
                    continue

                if inspect_phase == 'creep2':
                    if now < line_creep_deadline:
                        self.info_throttle('creep2', '[LINE] Creeping past end 2...')
                        self.publishVelocity(SIDE_SPEED, 0.0)
                    else:
                        self.stopRobot()
                        self.info('[LINE] End 2 reached — turning LEFT.')
                        inspect_phase = 'turn2'
                        turn_start    = now
                    continue

                if inspect_phase == 'turn2':
                    elapsed = now - turn_start
                    on_left = line_det and LINE_LEFT_LO <= line_cx <= LINE_LEFT_HI
                    if elapsed > TURN_MIN_TIME and (on_left or elapsed > TURN_MAX_TIME):
                        self.stopRobot()
                        if on_left:
                            self.info(f'[LINE] {COLOR} on left (cx={line_cx:.2f}) — '
                                      f'moving arm.')
                        else:
                            self.warn('[LINE] Line not in target cx band — '
                                      'timed out; moving arm anyway.')
                        self.setArm('look_at_belt_left')
                        inspect_phase       = 'arm_wait'
                        arm_settle_deadline = now + ARM_SETTLE_TOUT
                    else:
                        self.info_throttle('turn2',
                                           f'[LINE] Turning left, waiting for {COLOR} cx '
                                           f'in [{LINE_LEFT_LO:.2f}, {LINE_LEFT_HI:.2f}] '
                                           f'(cx={line_cx:.2f})...')
                        self.publishVelocity(0.0, TURN_SPEED)
                    continue

                if inspect_phase == 'arm_wait':
                    settled = self.armAtTarget(LOOK_AT_BELT_LEFT)
                    if settled or now >= arm_settle_deadline:
                        if not settled:
                            self.warn('[LINE] Arm did not confirm pose in time — '
                                      'continuing anyway.')
                        if end1_pose is not None:
                            self.info('[LINE] Arm moved — driving back to end 1.')
                            inspect_phase    = 'wall_return'
                            return_best_dist = float('inf')
                        else:
                            self.warn('[LINE] No end-1 coordinate — finishing.')
                            inspect_phase = 'done'
                    else:
                        self.info_throttle('arm_wait',
                                           '[LINE] Waiting for arm to move...')
                    continue

                if inspect_phase == 'wall_return':
                    if self.current_pose is None:
                        self.info_throttle('wall_return', '[LINE] Waiting for pose...')
                        self.publishVelocity(0.0, 0.0)
                        continue
                    ex = end1_pose.pose.position.x
                    ey = end1_pose.pose.position.y
                    cx = self.current_pose.position.x
                    cy = self.current_pose.position.y
                    dist = math.hypot(ex - cx, ey - cy)
                    passed = (dist < RETURN_NEAR and
                              dist > return_best_dist + RETURN_PASS)
                    return_best_dist = min(return_best_dist, dist)
                    if dist <= RETURN_TOL or passed:
                        self.info(f'[LINE] Reached end-1 (dist={dist:.2f} m) — '
                                  f'creeping further.')
                        inspect_phase         = 'return_creep'
                        return_creep_deadline = now + RETURN_EXTRA
                        continue
                    yaw     = self._quat_to_yaw(self.current_pose.orientation)
                    bearing = math.atan2(ey - cy, ex - cx)
                    yaw_err = math.atan2(math.sin(bearing - yaw),
                                         math.cos(bearing - yaw))
                    ang = max(-SIDE_MAX_ANG,
                              min(SIDE_MAX_ANG, RETURN_YAW_KP * yaw_err))
                    self.info_throttle('wall_return',
                                       f'[LINE] Along wall to end 1 '
                                       f'(dist={dist:.2f} m).')
                    self.publishVelocity(RETURN_SPEED, ang)
                    continue

                if inspect_phase == 'return_creep':
                    if now < return_creep_deadline:
                        self.info_throttle('return_creep',
                                           '[LINE] Creeping further along wall...')
                        self.publishVelocity(RETURN_SPEED, 0.0)
                    else:
                        self.stopRobot()
                        self.info('[LINE] Reached end 1 — inspection complete.')
                        inspect_phase = 'done'
                    continue

                if inspect_phase == 'done':
                    self.stopRobot()
                    self.setArm('look_down')
                    time.sleep(1.0)
                    n_total = len(self.tile_detections)
                    n_nok   = sum(1 for d in self.tile_detections
                                  if d.split('|')[7] == 'damaged')
                    n_ok    = n_total - n_nok
                    self.say_pub.publish(String(
                        data=f'{COLOR.capitalize()} belt: {n_total} tile'
                             f'{"s" if n_total != 1 else ""} inspected, '
                             f'{n_ok} OK, {n_nok} damaged.'))
                    self.info(f'[LINE] {COLOR.upper()} inspection finished.')
                    break
                continue

            # ── waypoint navigation ────────────────────────────────────────────
            # After reaching a waypoint, rotate in place to sweep the down-camera
            # over the floor and search for the line before moving on / giving up.
            if scanning:
                if now < scan_end:
                    self.info_throttle('scan',
                                       f'[WP] Scanning in place for a {COLOR} line...')
                    self.publishVelocity(0.0, SCAN_SPEED)
                    continue
                self.stopRobot()
                scanning = False
                self.info(f'[WP] No {COLOR} line found at this waypoint.')

            if not goal_active:
                if wp_index >= len(waypoints):
                    self.info(f'Patrol finished without finding a {COLOR} line.')
                    break
                wp = waypoints[wp_index]
                self.info(f'[WP] {wp_index}: '
                          f'({wp.pose.position.x:.2f}, {wp.pose.position.y:.2f})')
                if self.goToPose(wp):
                    goal_active = True
                    wp_index   += 1
                else:
                    self.warn(f'[WP] {wp_index} rejected, skipping.')
                    wp_index += 1
            elif self.isTaskComplete():
                self.info(f'[WP] {wp_index - 1} done ({self.getResult().name}) — '
                          f'scanning for the {COLOR} line.')
                goal_active = False
                scanning    = True
                scan_end    = now + SCAN_TIME

        self.stopRobot()

    # ── nav2 helpers ─────────────────────────────────────────────────────────

    def goToPose(self, pose, behavior_tree=''):
        while not self.nav_client.wait_for_server(timeout_sec=1.0):
            self.info("'NavigateToPose' server not available, waiting...")
        goal = NavigateToPose.Goal()
        goal.pose = pose
        goal.behavior_tree = behavior_tree
        self.info(f'Nav → ({pose.pose.position.x:.2f}, {pose.pose.position.y:.2f})')
        future = self.nav_client.send_goal_async(goal)
        rclpy.spin_until_future_complete(self, future)
        self.goal_handle = future.result()
        if not self.goal_handle.accepted:
            self.error('Goal rejected.')
            return False
        self.result_future = self.goal_handle.get_result_async()
        return True

    def cancelTask(self):
        self.info('Cancelling task.')
        if self.result_future:
            future = self.goal_handle.cancel_goal_async()
            rclpy.spin_until_future_complete(self, future)

    def isTaskComplete(self):
        if not self.result_future:
            return True
        rclpy.spin_until_future_complete(self, self.result_future, timeout_sec=0.10)
        if self.result_future.result():
            self.status = self.result_future.result().status
            return self.status not in (GoalStatus.STATUS_ACCEPTED,
                                       GoalStatus.STATUS_EXECUTING)
        return False

    def getResult(self):
        if self.status == GoalStatus.STATUS_SUCCEEDED:
            return type('R', (), {'name': 'SUCCEEDED'})()
        if self.status == GoalStatus.STATUS_ABORTED:
            return type('R', (), {'name': 'FAILED'})()
        if self.status == GoalStatus.STATUS_CANCELED:
            return type('R', (), {'name': 'CANCELED'})()
        return type('R', (), {'name': 'UNKNOWN'})()

    def _wait_for_task(self):
        while rclpy.ok() and not self.isTaskComplete():
            rclpy.spin_once(self, timeout_sec=0.05)

    # ── velocity / arm / pose ─────────────────────────────────────────────────

    def publishVelocity(self, linear_x, angular_z):
        msg = TwistStamped()
        msg.header.stamp    = self.get_clock().now().to_msg()
        msg.twist.linear.x  = float(linear_x)
        msg.twist.angular.z = float(angular_z)
        self.cmd_vel_pub.publish(msg)

    def stopRobot(self):
        self.publishVelocity(0.0, 0.0)

    def setArm(self, pose_name):
        self.arm_pub.publish(String(data=pose_name))
        self.info(f'[ARM] → {pose_name}')

    def buildPose(self, x, y, yaw=0.0, orientation=None):
        pose = PoseStamped()
        pose.header.frame_id  = self.pose_frame_id
        pose.header.stamp     = self.get_clock().now().to_msg()
        pose.pose.position.x  = float(x)
        pose.pose.position.y  = float(y)
        pose.pose.orientation = (orientation if orientation is not None
                                 else self._yaw_to_quat(yaw))
        return pose

    def _yaw_to_quat(self, yaw):
        q = quaternion_from_euler(0, 0, yaw)
        return Quaternion(x=q[0], y=q[1], z=q[2], w=q[3])

    def _quat_to_yaw(self, q):
        return math.atan2(2.0 * (q.w * q.z + q.x * q.y),
                          1.0 - 2.0 * (q.y * q.y + q.z * q.z))

    def publishEnd1(self, x, y):
        pt = PointStamped()
        pt.header.frame_id = self.pose_frame_id
        pt.header.stamp    = self.get_clock().now().to_msg()
        pt.point.x, pt.point.y = float(x), float(y)
        self.end1_pub.publish(pt)

        m = Marker()
        m.header.frame_id = self.pose_frame_id
        m.header.stamp    = self.get_clock().now().to_msg()
        m.ns   = 'inspection_end1'
        m.id   = 0
        m.type = Marker.SPHERE
        m.action = Marker.ADD
        m.pose.position.x, m.pose.position.y = float(x), float(y)
        m.pose.position.z = 0.1
        m.pose.orientation.w = 1.0
        m.scale.x = m.scale.y = m.scale.z = 0.25
        m.color.r, m.color.g, m.color.b, m.color.a = 1.0, 0.5, 0.0, 1.0
        self.end1_marker_pub.publish(m)

    def armAtTarget(self, target, tol=0.06):
        for name, tgt in zip(ARM_JOINTS, target):
            if name not in self.joint_pos:
                return False
            if abs(self.joint_pos[name] - tgt) > tol:
                return False
        return True

    # ── callbacks ─────────────────────────────────────────────────────────────

    def _amcl_cb(self, msg):
        self.initial_pose_received = True
        self.current_pose = msg.pose.pose

    def _line_detected_cb(self, msg):   self.line_detected   = msg.data
    def _line_cx_cb(self, msg):         self.line_cx         = msg.data
    def _yellow_detected_cb(self, msg): self.yellow_detected = msg.data
    def _tile_cb(self, msg):
        if self._busy:
            self.tile_detections.append(msg.data)

    def _joint_cb(self, msg):
        for name, pos in zip(msg.name, msg.position):
            self.joint_pos[name] = pos

    # ── logging ───────────────────────────────────────────────────────────────

    def info_throttle(self, key, msg, period=1.5):
        now = time.time()
        if key not in self._log_times or now - self._log_times[key] > period:
            self._log_times[key] = now
            self.info(msg)

    def info(self, msg):  self.get_logger().info(msg)
    def warn(self, msg):  self.get_logger().warn(msg)
    def error(self, msg): self.get_logger().error(msg)


def main(args=None):
    rclpy.init(args=args)
    node = GreenBeltInspector()
    try:
        while rclpy.ok():
            rclpy.spin_once(node, timeout_sec=0.1)
            node.run_pending()
    except KeyboardInterrupt:
        pass
    finally:
        node.nav_client.destroy()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
