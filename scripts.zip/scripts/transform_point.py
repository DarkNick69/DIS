#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from rclpy.duration import Duration

from geometry_msgs.msg import PointStamped
from visualization_msgs.msg import Marker, MarkerArray
from std_msgs.msg import ColorRGBA

import tf2_ros
import tf2_geometry_msgs
import tf_transformations
import math


class TransformPoint(Node):
    def __init__(self):
        super().__init__('transform_point')

        self.tf_buffer = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)

        self.breadcrumb_pub = self.create_publisher(MarkerArray, '/breadcrumbs', 10)
        self.arrow_pub = self.create_publisher(Marker, '/robot_orientation', 10)

        self.breadcrumbs: list[Marker] = []
        self.marker_id = 0
        self.timer = self.create_timer(0.5, self._timer_callback)

        self.get_logger().info('transform_point node started – publishing breadcrumbs and orientation arrow.')

    def _timer_callback(self):
        try:
            transform = self.tf_buffer.lookup_transform(
                'map', 'base_link', rclpy.time.Time(), timeout=Duration(seconds=0.5)
            )
        except (tf2_ros.LookupException, tf2_ros.ConnectivityException, tf2_ros.ExtrapolationException) as e:
            self.get_logger().warn(f'TF lookup failed: {e}')
            return

        point_in_base = PointStamped()
        point_in_base.header.frame_id = 'base_link'
        point_in_base.header.stamp = self.get_clock().now().to_msg()
        point_in_base.point.x = -0.5
        point_in_base.point.y = 0.0
        point_in_base.point.z = 0.0

        try:
            point_in_map = self.tf_buffer.transform(point_in_base, 'map', timeout=Duration(seconds=0.5))
        except Exception as e:
            self.get_logger().warn(f'Point transform failed: {e}')
            return

        m = Marker()
        m.header.frame_id = 'map'
        m.header.stamp = self.get_clock().now().to_msg()
        m.ns = 'breadcrumbs'
        m.id = self.marker_id
        self.marker_id += 1
        m.type = Marker.SPHERE
        m.action = Marker.ADD

        m.pose.position.x = point_in_map.point.x
        m.pose.position.y = point_in_map.point.y
        m.pose.position.z = point_in_map.point.z
        m.pose.orientation.w = 1.0

        m.scale.x = 0.08
        m.scale.y = 0.08
        m.scale.z = 0.08

        m.color = ColorRGBA(r=0.2, g=0.6, b=1.0, a=0.8)
        m.lifetime.sec = 0

        self.breadcrumbs.append(m)

        ma = MarkerArray()
        ma.markers = list(self.breadcrumbs)
        self.breadcrumb_pub.publish(ma)

        q = transform.transform.rotation
        _, _, yaw = tf_transformations.euler_from_quaternion([q.x, q.y, q.z, q.w])

        arrow = Marker()
        arrow.header.frame_id = 'map'
        arrow.header.stamp = self.get_clock().now().to_msg()
        arrow.ns = 'orientation'
        arrow.id = 0
        arrow.type = Marker.ARROW
        arrow.action = Marker.ADD

        arrow.pose.position.x = transform.transform.translation.x
        arrow.pose.position.y = transform.transform.translation.y
        arrow.pose.position.z = transform.transform.translation.z + 0.3

        arrow.pose.orientation = transform.transform.rotation

        arrow.scale.x = 0.4
        arrow.scale.y = 0.06
        arrow.scale.z = 0.08

        arrow.color = ColorRGBA(r=1.0, g=0.2, b=0.2, a=1.0)
        arrow.lifetime.sec = 0

        self.arrow_pub.publish(arrow)

        self.get_logger().debug(
            f'Breadcrumb #{m.id} at ({m.pose.position.x:.2f}, {m.pose.position.y:.2f}), '
            f'yaw={math.degrees(yaw):.1f}°'
        )


def main(args=None):
    rclpy.init(args=args)
    node = TransformPoint()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
