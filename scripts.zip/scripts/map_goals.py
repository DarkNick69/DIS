#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSDurabilityPolicy, QoSHistoryPolicy, QoSProfile, QoSReliabilityPolicy

from nav_msgs.msg import OccupancyGrid
from geometry_msgs.msg import PoseStamped, Quaternion
from turtle_tf2_py.turtle_tf2_broadcaster import quaternion_from_euler

from nav2_msgs.action import NavigateToPose
from rclpy.action import ActionClient

import cv2
import numpy as np
import math


map_qos = QoSProfile(
    durability=QoSDurabilityPolicy.TRANSIENT_LOCAL,
    reliability=QoSReliabilityPolicy.RELIABLE,
    history=QoSHistoryPolicy.KEEP_LAST,
    depth=1,
)


class MapGoals(Node):
    def __init__(self):
        super().__init__('map_goals')

        self.map_data = None
        self.map_info = None
        self.map_image = None

        self.create_subscription(OccupancyGrid, '/map', self._map_callback, map_qos)
        self.nav_client = ActionClient(self, NavigateToPose, 'navigate_to_pose')

        self.get_logger().info('map_goals node started – waiting for /map …')

    def _map_callback(self, msg: OccupancyGrid):
        self.map_info = msg.info
        width = msg.info.width
        height = msg.info.height

        grid = np.array(msg.data, dtype=np.int8).reshape((height, width))

        img = np.full((height, width), 127, dtype=np.uint8)
        img[grid == 0] = 255
        img[grid == 100] = 0

        self.map_image = cv2.flip(img, 0)
        self.map_data = cv2.flip(grid, 0)

        self.get_logger().info(
            f'Map received: {width}x{height}, resolution={msg.info.resolution:.3f} m/px'
        )

    def pixel_to_world(self, px, py):
        res = self.map_info.resolution
        origin = self.map_info.origin.position
        height = self.map_info.height

        grid_y = height - 1 - py

        world_x = origin.x + px * res
        world_y = origin.y + grid_y * res
        return world_x, world_y

    def is_free(self, px, py):
        if self.map_data is None:
            return False
        if 0 <= py < self.map_data.shape[0] and 0 <= px < self.map_data.shape[1]:
            return int(self.map_data[py, px]) == 0
        return False

    def send_goal(self, wx, wy, yaw=0.0):
        if not self.nav_client.wait_for_server(timeout_sec=5.0):
            self.get_logger().error('NavigateToPose action server not available')
            return

        goal = NavigateToPose.Goal()
        goal.pose = PoseStamped()
        goal.pose.header.frame_id = 'map'
        goal.pose.header.stamp = self.get_clock().now().to_msg()
        goal.pose.pose.position.x = wx
        goal.pose.pose.position.y = wy
        q = quaternion_from_euler(0.0, 0.0, yaw)
        goal.pose.pose.orientation = Quaternion(x=q[0], y=q[1], z=q[2], w=q[3])

        self.get_logger().info(f'Sending goal → ({wx:.2f}, {wy:.2f})')
        self.nav_client.send_goal_async(goal)

    def run(self):
        cv2.namedWindow('Map', cv2.WINDOW_NORMAL)

        click_pos = [None]

        def on_mouse(event, x, y, flags, param):
            if event == cv2.EVENT_LBUTTONDOWN:
                click_pos[0] = (x, y)

        cv2.setMouseCallback('Map', on_mouse)

        self.get_logger().info('Click on the map to send a navigation goal. Press ESC to exit.')

        while rclpy.ok():
            rclpy.spin_once(self, timeout_sec=0.05)

            if self.map_image is None:
                continue

            display = cv2.cvtColor(self.map_image, cv2.COLOR_GRAY2BGR)

            if click_pos[0] is not None:
                px, py = click_pos[0]
                click_pos[0] = None

                if self.is_free(px, py):
                    wx, wy = self.pixel_to_world(px, py)
                    cv2.circle(display, (px, py), 5, (0, 0, 255), -1)
                    self.send_goal(wx, wy)
                else:
                    self.get_logger().warn(f'Clicked pixel ({px}, {py}) is not free space – ignoring.')

            cv2.imshow('Map', display)
            key = cv2.waitKey(30) & 0xFF
            if key == 27:  # ESC
                break

        cv2.destroyAllWindows()


def main(args=None):
    rclpy.init(args=args)
    node = MapGoals()
    try:
        node.run()
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
