#!/usr/bin/env python3
"""Train YOLOv8n-cls to classify a tile crop as damaged vs okay.

Build the dataset first:
    /opt/ultralytics/bin/python3 scripts/build_tiles_cls_dataset.py

Then train:
    /opt/ultralytics/bin/python3 scripts/train_tiles_cls.py

Output weights: runs/classify/tiles_cls/weights/best.pt
"""

import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pkg_paths import PKG_ROOT

from ultralytics import YOLO

DATA = os.path.join(PKG_ROOT, 'tiles_cls_dataset')
OUT  = os.path.join(PKG_ROOT, 'runs', 'classify')

model = YOLO('yolov8n-cls.pt')
results = model.train(
    data=DATA,
    epochs=40,
    imgsz=224,
    batch=64,
    project=OUT,
    name='tiles_cls',
    exist_ok=True,
    verbose=True,
)

print(f'\nDone — weights: {OUT}/tiles_cls/weights/best.pt')
