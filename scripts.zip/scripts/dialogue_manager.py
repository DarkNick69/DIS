#!/usr/bin/env python3
"""Dialogue manager — asks each person which task to perform and applies the
slide-10 reconsideration logic.

Protocol with mission_control:
    subscribe  /dialogue_request  String  "<gender>|<name>"   (gender: man|woman)
    publish    /dialogue_result   String  "<task_code>|<name>"
        task_code ∈ {ring_count, barrel_inspection, anomaly_red, anomaly_green, nothing}

Input modes (param `input_mode`, default 'asr'):
    asr   → microphone speech via Vosk (offline). Falls back to 'text' if the mic
            or model is unavailable.
    qr    → read a QR code beside the person from the oakd camera (needs libzbar0).
    text  → operator types the person's answer in the console (PDF allows this).

The running transcript is spoken (/robot_say), printed, published on /dialogue,
and drawn in a 'Dialogue' window.
"""

import os
import json
import queue
import threading
import time

import numpy as np

import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from std_msgs.msg import String
from sensor_msgs.msg import Image

import cv2

from pkg_paths import p

VOSK_MODEL = p('models/vosk/vosk-model-small-en-us-0.15')

READABLE = {
    'ring_count':        'count the rings',
    'barrel_inspection': 'inspect the barrels',
    'anomaly_red':       'detect anomalies in the red cell',
    'anomaly_green':     'detect anomalies in the green cell',
    'nothing':           'do nothing',
}


def parse_task(text):
    """Map an utterance to a task code (or None / 'anomaly' if colour unknown)."""
    t = (text or '').lower()
    if not t:
        return None
    if 'ring' in t or 'count' in t:
        return 'ring_count'
    if 'barrel' in t:
        return 'barrel_inspection'
    if any(w in t for w in ('anomal', 'defect', 'tile', 'cell', 'inspect')):
        if 'red' in t:
            return 'anomaly_red'
        if 'green' in t:
            return 'anomaly_green'
        return 'anomaly'      # colour not yet specified
    if 'nothing' in t:
        return 'nothing'
    return None


def is_yes(text):
    t = (text or '').lower()
    return any(w in t for w in ('yes', 'sure', 'correct', 'confirm', 'right'))


class DialogueManager(Node):
    def __init__(self):
        super().__init__('dialogue_manager')

        self.declare_parameters('', [
            ('input_mode', 'asr'),
            ('listen_seconds', 5),
        ])
        self.input_mode = self.get_parameter('input_mode').value
        self.listen_seconds = int(self.get_parameter('listen_seconds').value)

        self.say_pub      = self.create_publisher(String, '/robot_say',       10)
        self.dialogue_pub = self.create_publisher(String, '/dialogue',        10)
        self.result_pub   = self.create_publisher(String, '/dialogue_result', 10)

        self.create_subscription(String, '/dialogue_request', self._request_cb, 10)
        self.create_subscription(Image, '/oakd/rgb/preview/image_raw',
                                 self._img_cb, qos_profile_sensor_data)

        self._busy = False
        self._latest_img = None
        self.transcript = []

        self._asr_model = None
        if self.input_mode == 'asr':
            self._init_asr()

        cv2.namedWindow('Dialogue', cv2.WINDOW_NORMAL)
        self.create_timer(0.2, self._render)
        self.get_logger().info(f'DialogueManager ready (input_mode={self.input_mode}).')

    # ── ASR setup ─────────────────────────────────────────────────────────────

    def _init_asr(self):
        try:
            import vosk
            if not os.path.isdir(VOSK_MODEL):
                raise FileNotFoundError(VOSK_MODEL)
            vosk.SetLogLevel(-1)
            self._asr_model = vosk.Model(VOSK_MODEL)
            import sounddevice  # noqa: F401  (probe the mic backend)
            self.get_logger().info('ASR (Vosk) ready.')
        except Exception as e:
            self.get_logger().warn(
                f'ASR unavailable ({e}); falling back to text input.')
            self.input_mode = 'text'

    # ── callbacks ─────────────────────────────────────────────────────────────

    def _img_cb(self, msg):
        try:
            from cv_bridge import CvBridge
            if not hasattr(self, '_bridge'):
                self._bridge = CvBridge()
            self._latest_img = self._bridge.imgmsg_to_cv2(msg, 'bgr8')
        except Exception:
            pass

    def _request_cb(self, msg):
        if self._busy:
            self.get_logger().warn('Dialogue already in progress, ignoring request.')
            return
        parts = msg.data.split('|')
        gender = parts[0].strip().lower() if parts else 'man'
        name = parts[1].strip() if len(parts) > 1 else ''
        threading.Thread(target=self._run_dialogue, args=(gender, name),
                         daemon=True).start()

    # ── speech + listening ────────────────────────────────────────────────────

    def _robot_say(self, text):
        self.transcript.append(('R', text))
        self.dialogue_pub.publish(String(data=f'R: {text}'))
        self.say_pub.publish(String(data=text))
        self.get_logger().info(f'R: {text}')
        time.sleep(min(1.0 + 0.06 * len(text), 4.0))   # let TTS finish before listening

    def _person_said(self, text):
        self.transcript.append(('P', text))
        self.dialogue_pub.publish(String(data=f'P: {text}'))
        self.get_logger().info(f'P: {text}')

    def _listen(self):
        """Return the person's utterance (lowercased) via the active input mode."""
        if self.input_mode == 'asr' and self._asr_model is not None:
            text = self._listen_asr()
        elif self.input_mode == 'qr':
            text = self._listen_qr()
        else:
            text = self._listen_text()
        self._person_said(text or '(no answer)')
        return text or ''

    def _listen_asr(self):
        try:
            import vosk, sounddevice as sd
            sr = 16000
            rec = vosk.KaldiRecognizer(self._asr_model, sr)
            q = queue.Queue()

            def cb(indata, frames, t, status):
                q.put(bytes(indata))

            words = []
            with sd.RawInputStream(samplerate=sr, blocksize=8000, dtype='int16',
                                   channels=1, callback=cb):
                end = time.time() + self.listen_seconds
                while time.time() < end:
                    try:
                        data = q.get(timeout=0.5)
                    except queue.Empty:
                        continue
                    if rec.AcceptWaveform(data):
                        words.append(json.loads(rec.Result()).get('text', ''))
                words.append(json.loads(rec.FinalResult()).get('text', ''))
            return ' '.join(w for w in words if w).strip().lower()
        except Exception as e:
            self.get_logger().warn(f'ASR failed ({e}); typing instead.')
            return self._listen_text()

    def _listen_qr(self):
        try:
            from pyzbar.pyzbar import decode
            for _ in range(20):
                if self._latest_img is not None:
                    for d in decode(self._latest_img):
                        return d.data.decode('utf-8', 'ignore').strip().lower()
                time.sleep(0.2)
        except Exception as e:
            self.get_logger().warn(f'QR read failed ({e}); typing instead.')
        return self._listen_text()

    def _listen_text(self):
        try:
            return input('   [person answer] > ').strip().lower()
        except EOFError:
            return ''

    # ── dialogue flow ─────────────────────────────────────────────────────────

    def _ask_task(self):
        """Listen once; if anomaly with no colour, ask which cell."""
        task = parse_task(self._listen())
        if task == 'anomaly':
            self._robot_say('Which cell, red or green?')
            t = (self._listen() or '')
            task = 'anomaly_red' if 'red' in t else \
                   'anomaly_green' if 'green' in t else 'anomaly_red'
        return task

    def _finalize(self, task, name):
        if task is None:
            task = 'nothing'
        self._robot_say(f'OK. I will {READABLE.get(task, task)}.')
        self.result_pub.publish(String(data=f'{task}|{name}'))
        self.get_logger().info(f'[DIALOGUE RESULT] {task} (requested by {name})')
        self._busy = False

    def _run_dialogue(self, gender, name):
        self._busy = True
        self.transcript = []
        who = 'woman' if gender == 'woman' else 'man'
        self._robot_say(f'Hi {who}, which task should I perform?')

        task = self._ask_task()

        # Men state the task directly.
        if gender != 'woman':
            self._finalize(task, name)
            return

        # Women may reconsider: repeat until the same task is named twice or 'yes'.
        prev = task
        for _ in range(5):
            self._robot_say('Are you sure?')
            ans = self._listen()
            if is_yes(ans):
                self._finalize(prev, name)
                return
            new = parse_task(ans)
            if new == 'anomaly':
                self._robot_say('Which cell, red or green?')
                t = self._listen() or ''
                new = 'anomaly_red' if 'red' in t else 'anomaly_green'
            if new is not None:
                if new == prev:
                    self._finalize(prev, name)   # same task twice → settled
                    return
                prev = new                       # changed mind → ask again
        self._finalize(prev, name)

    # ── transcript window ─────────────────────────────────────────────────────

    def _render(self):
        img = np.zeros((360, 640, 3), np.uint8)
        cv2.putText(img, 'Dialogue', (12, 28), cv2.FONT_HERSHEY_SIMPLEX,
                    0.8, (255, 255, 255), 2)
        y = 60
        for who, text in self.transcript[-10:]:
            col = (120, 220, 255) if who == 'R' else (180, 255, 180)
            tag = 'R:' if who == 'R' else 'P:'
            cv2.putText(img, f'{tag} {text}'[:70], (12, y),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, col, 1, cv2.LINE_AA)
            y += 26
        cv2.imshow('Dialogue', img)
        cv2.waitKey(1)


def main():
    rclpy.init(args=None)
    node = DialogueManager()
    try:
        rclpy.spin(node)
    finally:
        cv2.destroyAllWindows()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
