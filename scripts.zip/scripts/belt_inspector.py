#!/usr/bin/env python3
"""Belt / tile inspection node.

Driven by mission_control over `/inspect_belt` (String):
    'start'   → activate, load the anomaly model, reset tile ids
    'capture' → detect the tile under the camera, run anomaly detection once,
                save crop + mask, publish a result
    'stop'    → deactivate

Subscribes the **arm (top) camera** (arm at `look_at_belt_right/left`), detects the
light-grey tile on the dark conveyor, classifies OK/NOK with the PatchCore-lite
model and emits a segmentation mask.

Publishes `/tile_results` (String):  tile|<id>|<OK|NOK>|<score>|<imgpath>|<maskpath>
"""

import os

import cv2
import numpy as np

import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data

from sensor_msgs.msg import Image
from std_msgs.msg import String
from cv_bridge import CvBridge, CvBridgeError

from pkg_paths import p
from anomaly_infer import AnomalyDetector

MODEL_PATH = p('models/anomaly/patchcore.pt')
IMAGES_DIR = p('inspection_images')

# Tile-segmentation thresholds (light square on near-black belt)
MIN_TILE_AREA_FRAC = 0.03    # of full image
MIN_ASPECT, MAX_ASPECT = 0.55, 1.8
MIN_EXTENT = 0.55            # contour area / bbox area
CENTER_FRAC = 0.45          # tile centroid must be within this of image centre


class BeltInspector(Node):
    def __init__(self):
        super().__init__('belt_inspector')

        self.bridge = CvBridge()
        self.latest = None
        self.active = False
        self.tile_id = 0

        os.makedirs(IMAGES_DIR, exist_ok=True)

        self.detector = None  # lazily loaded on 'start' (model load is heavy)

        self.create_subscription(
            Image, '/top_camera/rgb/preview/image_raw',
            self._img_cb, qos_profile_sensor_data)
        self.create_subscription(String, '/inspect_belt', self._cmd_cb, 10)

        self.result_pub = self.create_publisher(String, '/tile_results', 10)
        self.say_pub    = self.create_publisher(String, '/robot_say', 10)

        cv2.namedWindow('Belt Inspection', cv2.WINDOW_NORMAL)
        self.get_logger().info('BeltInspector ready — waiting for /inspect_belt.')

    # ── callbacks ─────────────────────────────────────────────────────────────

    def _img_cb(self, msg):
        try:
            self.latest = self.bridge.imgmsg_to_cv2(msg, 'bgr8')
        except CvBridgeError as e:
            self.get_logger().error(str(e))

    def _cmd_cb(self, msg):
        cmd = msg.data.strip().lower()
        if cmd == 'start':
            if self.detector is None:
                self.get_logger().info('Loading anomaly model...')
                self.detector = AnomalyDetector(MODEL_PATH)
                if self.detector.bank is None:
                    self.get_logger().error(
                        f'No anomaly model at {MODEL_PATH} — run train_anomaly.py first.')
            self.active = True
            self.tile_id = 0
            self.get_logger().info('Belt inspection started.')
        elif cmd == 'capture':
            self._inspect_once()
        elif cmd == 'stop':
            self.active = False
            self.get_logger().info('Belt inspection stopped.')

    # ── tile detection ────────────────────────────────────────────────────────

    def _find_tile(self, bgr):
        """Return (x, y, w, h) of the central tile, or None."""
        h, w = bgr.shape[:2]
        gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
        gray = cv2.GaussianBlur(gray, (5, 5), 0)
        _, th = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7))
        th = cv2.morphologyEx(th, cv2.MORPH_OPEN, k, iterations=1)
        th = cv2.morphologyEx(th, cv2.MORPH_CLOSE, k, iterations=2)

        best, best_d = None, 1e9
        for cnt in cv2.findContours(th, cv2.RETR_EXTERNAL,
                                    cv2.CHAIN_APPROX_SIMPLE)[0]:
            area = cv2.contourArea(cnt)
            if area < MIN_TILE_AREA_FRAC * w * h:
                continue
            x, y, bw, bh = cv2.boundingRect(cnt)
            aspect = bw / bh if bh > 0 else 0
            extent = area / (bw * bh) if bw * bh else 0
            if not (MIN_ASPECT <= aspect <= MAX_ASPECT) or extent < MIN_EXTENT:
                continue
            cx, cy = x + bw / 2, y + bh / 2
            d = np.hypot(cx - w / 2, cy - h / 2)
            if d < best_d and d < CENTER_FRAC * np.hypot(w, h):
                best_d, best = d, (x, y, bw, bh)
        return best

    def _inspect_once(self):
        if not self.active or self.latest is None:
            self.get_logger().warn('Capture ignored (inactive or no image).')
            return
        if self.detector is None or self.detector.bank is None:
            self.get_logger().error('Anomaly model not loaded.')
            return

        bgr = self.latest.copy()
        box = self._find_tile(bgr)
        if box is None:
            self.get_logger().warn('No tile under the camera to inspect.')
            return
        x, y, bw, bh = box
        crop = bgr[y:y + bh, x:x + bw]

        is_nok, score, mask, heat = self.detector.infer(crop)
        self.tile_id += 1
        tid = self.tile_id
        status = 'NOK' if is_nok else 'OK'

        img_path  = os.path.join(IMAGES_DIR, f'tile_{tid}.png')
        mask_path = os.path.join(IMAGES_DIR, f'tile_{tid}_mask.png')
        cv2.imwrite(img_path, crop)
        cv2.imwrite(mask_path, mask)

        self.result_pub.publish(String(
            data=f'tile|{tid}|{status}|{score:.2f}|{img_path}|{mask_path}'))
        self.get_logger().info(f'[TILE {tid}] {status}  score={score:.2f}')
        if is_nok:
            self.say_pub.publish(String(data=f'Tile {tid} is defective.'))

        # ── debug overlay ─────────────────────────────────────────────────────
        disp = bgr.copy()
        col = (0, 0, 255) if is_nok else (0, 200, 0)
        cv2.rectangle(disp, (x, y), (x + bw, y + bh), col, 2)
        cv2.putText(disp, f'#{tid} {status} {score:.2f}', (x, max(y - 8, 12)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, col, 2, cv2.LINE_AA)
        if is_nok and mask.any():
            overlay = crop.copy()
            overlay[mask > 0] = (0, 0, 255)
            disp[y:y + bh, x:x + bw] = cv2.addWeighted(crop, 0.6, overlay, 0.4, 0)
        cv2.imshow('Belt Inspection', disp)
        cv2.waitKey(1)


def main():
    rclpy.init(args=None)
    node = BeltInspector()
    try:
        rclpy.spin(node)
    finally:
        cv2.destroyAllWindows()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
