#!/usr/bin/env python3
"""Build a YOLO *classification* dataset: damaged vs okay tiles.

Source: RINS_AD_dataset/train/images/{okay,damaged}_*.png
        (the filename prefix is the label; the gt masks are not needed here)

Output: tiles_cls_dataset/{train,val}/{damaged,okay}/*.jpg
        (the folder-per-class layout YOLOv8-cls expects)

Why composite instead of using the raw crops?
detect_tiles.py runs this classifier on the *bounding-box crop* of a tile it
detected — an axis-aligned box around a tile that is usually seen slightly from
the side, so the crop contains the tile plus a few background corners. To make
training match inference, we reuse the detector's compositing pipeline
(scripts/build_tiles_dataset.composite) and then crop to the tile's bbox, exactly
like detect_tiles.py does. Augmentation is kept mild (no hard downscale/blur) so
the fine cracks that distinguish "damaged" survive.

The source is class-imbalanced (594 okay vs 274 damaged), so we generate more
variants per damaged tile to roughly balance the two classes.

Usage:
    python3 scripts/build_tiles_cls_dataset.py              # ~6000 imgs / class
    python3 scripts/build_tiles_cls_dataset.py --target 8000
"""

import argparse
import os
import random
import shutil

import cv2
import numpy as np

from build_tiles_dataset import composite, CANVAS

CLASSES = ['damaged', 'okay']
OUT_SIZE = 224           # YOLOv8-cls default input size


def label_of(fname):
    return 'damaged' if fname.startswith('damaged') else 'okay'


def crop_bbox(canvas, bbox):
    """Crop the tile region (axis-aligned bbox) like detect_tiles.py does."""
    cx, cy, w, h = bbox
    x1 = int((cx - w / 2) * CANVAS)
    y1 = int((cy - h / 2) * CANVAS)
    x2 = int((cx + w / 2) * CANVAS)
    y2 = int((cy + h / 2) * CANVAS)
    x1, y1 = max(x1, 0), max(y1, 0)
    x2, y2 = min(x2, CANVAS), min(y2, CANVAS)
    crop = canvas[y1:y2, x1:x2]
    return crop if crop.size else canvas


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', default='tiles_cls_dataset')
    ap.add_argument('--target', type=int, default=6000,
                    help='approx images per class')
    ap.add_argument('--val', type=float, default=0.15, help='val fraction')
    ap.add_argument('--seed', type=int, default=0)
    args = ap.parse_args()

    random.seed(args.seed)
    np.random.seed(args.seed)

    here = os.path.dirname(os.path.abspath(__file__))
    root = os.path.dirname(here)
    src_dir = os.path.join(root, 'RINS_AD_dataset', 'train', 'images')
    out = os.path.join(root, args.out)

    files = sorted(f for f in os.listdir(src_dir) if f.lower().endswith('.png'))
    by_cls = {c: [f for f in files if label_of(f) == c] for c in CLASSES}
    print({c: len(v) for c, v in by_cls.items()})

    if os.path.exists(out):
        shutil.rmtree(out)
    for split in ('train', 'val'):
        for c in CLASSES:
            os.makedirs(os.path.join(out, split, c))

    all_paths = [os.path.join(src_dir, f) for f in files]
    total = 0
    for c in CLASSES:
        srcs = by_cls[c]
        per = max(1, round(args.target / len(srcs)))   # balance the classes
        for path_idx, f in enumerate(srcs):
            tile = cv2.imread(os.path.join(src_dir, f))
            if tile is None:
                continue
            for i in range(per):
                distractor = cv2.imread(random.choice(all_paths))
                if distractor is None:
                    distractor = tile
                canvas, bbox = composite(tile, distractor)
                crop = crop_bbox(canvas, bbox)
                crop = cv2.resize(crop, (OUT_SIZE, OUT_SIZE))
                split = 'val' if random.random() < args.val else 'train'
                stem = f'{c}_{path_idx:04d}_{i:02d}.jpg'
                cv2.imwrite(os.path.join(out, split, c, stem), crop)
                total += 1
        print(f'  {c:8s}: {len(srcs)} sources x {per} -> done')

    print(f'\nDone: {total} images -> {out}')
    print('Train with:')
    print('  /opt/ultralytics/bin/python3 scripts/train_tiles_cls.py')


if __name__ == '__main__':
    main()
